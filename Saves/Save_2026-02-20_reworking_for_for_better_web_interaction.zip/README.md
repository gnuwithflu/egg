# PoV Simulator — Web UI

A web interface for the Path of Virtue egg simulator.

## Setup

```bash
# 1. Install dependencies
pip install flask numpy

# 2. Place your project files
# The project expects this structure:
eggsim/
  app.py           ← Flask server
  methods.py       ← from your project
  farm/
    __init__.py
    artifact.py    ← from your project
    farm.py        ← from your project
    prices.py      ← from your project
  simulation/
    __init__.py
    commands.py    ← from your project
    egg_simulation.py ← from your project
    wait.py        ← from your project
  static/
    css/main.css
    js/app.js
  templates/
    index.html

# 3. Run
cd eggsim
python app.py

# 4. Open browser
# http://localhost:5000
```

## Features

- **3-panel layout**: Log | Farm Stats + Tabs | Actions
- **Farm setup modal**: Set TE, SE, PE, habs, eggs layed, artifacts
- **Tab views**: Habitats, Research (CR), Vehicles, Silos, Artifacts
- **Actions**: Simulate egg runs, wait offline/active, shift, buy/buy all
- **Events**: Apply multipliers (2× cash, etc.)
- **Snapshots**: Save farm state mid-run and compare
- **Log replay**: Session log entries are clickable to paste into replay box

## Notes

- The `simulation/` folder files (commands.py, egg_simulation.py, wait.py) contain the CLI simulator logic. The Flask backend reimplements the core simulation directly in `app.py` for the API, so those files are not required to run the web UI, but keep them for reference.
- No accounts or persistent storage — purely in-memory per browser session.
