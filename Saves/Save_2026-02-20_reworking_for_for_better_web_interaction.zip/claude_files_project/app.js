/* ═══════════════════════════════════════════════════════════
   PoV Simulator — Frontend App Logic
═══════════════════════════════════════════════════════════ */

// ─── Global State ─────────────────────────────────────────────

let state = null;
let snapshots = [];
let events = {};
let metadata = null;
let upgradeCosts = null;

const EGG_EMOJI = {
  curiosity: '🔮', kindness: '💚', resilience: '🔵',
  humility: '🟣', integrity: '🟠'
};
const EGG_COLOR = {
  curiosity: 'var(--curiosity)', kindness: 'var(--kindness)',
  resilience: 'var(--resilience)', humility: 'var(--humility)',
  integrity: 'var(--integrity)'
};

// ─── Init ──────────────────────────────────────────────────────

async function init() {
  metadata = await apiFetch('/api/metadata');
  buildArtifactModalHTML();

  const initData = await apiFetch('/api/state/init', 'POST', {});
  state = initData.state;
  renderAll(initData.stats);
  await refreshUpgrades();
}

// ─── API ───────────────────────────────────────────────────────

async function apiFetch(url, method = 'GET', body = null) {
  const opts = { method, headers: { 'Content-Type': 'application/json' } };
  if (body !== null) opts.body = JSON.stringify(body);
  const res = await fetch(url, opts);
  const data = await res.json();
  if (data.error) { showToast(data.error, true); throw new Error(data.error); }
  return data;
}

async function apiAction(url, extra = {}) {
  setLoading(true);
  try {
    const data = await apiFetch(url, 'POST', { state, ...extra });
    state = data.state;
    renderAll(data.stats);
    await refreshUpgrades();
  } catch (e) { /* toast shown */ }
  setLoading(false);
}

async function refreshUpgrades() {
  try {
    upgradeCosts = await apiFetch('/api/upgrade_costs', 'POST', { state });
    renderActiveTab();
  } catch (e) {}
}

function setLoading(v) {
  document.querySelectorAll('.stat-value').forEach(el => {
    el.classList.toggle('updating', v);
  });
}

// ─── Render ────────────────────────────────────────────────────

function renderAll(stats) {
  if (!stats || stats.error) return;

  // Farm header
  const egg = stats.egg || 'curiosity';
  const iconEl = document.getElementById('egg-icon-display');
  iconEl.className = `egg-icon-large ${egg}`;
  iconEl.innerHTML = `<span class="egg-emoji">${EGG_EMOJI[egg] || '🥚'}</span>`;
  document.getElementById('farm-egg-label').textContent = egg.charAt(0).toUpperCase() + egg.slice(1);
  document.getElementById('farm-egg-label').style.color = EGG_COLOR[egg] || 'var(--text)';

  // Stats
  setText('stat-cash', stats.cash || '—');
  setText('stat-time', stats.time || '0s');
  setText('stat-earnings', stats.earnings_away || '—');
  setText('stat-pop', `${stats.pop || '—'} / ${stats.hab_size || '—'}`);
  setText('stat-shipping', stats.shipping || '—');
  setText('stat-laying', stats.laying || '—');
  setText('stat-ihr', stats.ihr || '—');
  setText('stat-rcb', stats.max_rcb || '—');
  setText('stat-eb', stats.eb !== undefined ? `${stats.eb}%` : '—');

  // TE badge
  const tePending = stats.te_pending || 0;
  const teTotal = (stats.te || 0) + tePending;
  document.getElementById('te-display').textContent = `${stats.te || 0}${tePending > 0 ? '+'+tePending : ''} TE`;

  // Virtue rows
  renderVirtueRows(stats);

  // Log
  renderLog();

  // Events display
  renderEventTags();
}

function setText(id, val) {
  const el = document.getElementById(id);
  if (el) el.textContent = val;
}

function renderVirtueRows(stats) {
  if (!stats.virtue_eggs) return;
  const container = document.getElementById('virtue-rows');
  const colors = {
    curiosity: 'var(--curiosity)', kindness: 'var(--kindness)',
    resilience: 'var(--resilience)', humility: 'var(--humility)',
    integrity: 'var(--integrity)'
  };
  container.innerHTML = stats.virtue_eggs.map(v => `
    <div class="virtue-row">
      <div class="virtue-egg-dot" style="background:${colors[v.name]}"></div>
      <div class="virtue-egg-name" style="color:${colors[v.name]}">${v.name}</div>
      <div class="virtue-progress-bar">
        <div class="virtue-progress-fill" style="width:${Math.round(v.progress*100)}%;background:${colors[v.name]}"></div>
      </div>
      <div class="virtue-layed">${v.layed}</div>
      <div class="virtue-te-count">${v.te} TE</div>
    </div>
  `).join('');

  const total = stats.virtue_eggs.reduce((s, v) => s + v.te, 0);
  setText('virtue-te-total', `${(stats.te || 0) + total} TE total`);
  setText('virtue-shifts', `${stats.shifts || 0} shifts`);
}

function renderLog() {
  if (!state) return;
  const list = document.getElementById('log-list');
  const logs = state.log || [];
  list.innerHTML = logs.slice().reverse().map((entry, i) => `
    <div class="log-entry" onclick="copyLogEntry('${escapeHtml(logToCommand(entry))}')">
      <span class="log-time">${entry.time || ''}</span>
      <span class="log-action"><strong>${escapeHtml(entry.action)}</strong> ${escapeHtml(entry.detail || '')}</span>
    </div>
  `).join('');
}

function logToCommand(entry) {
  // Convert log entry back to a simulator command
  const act = entry.action;
  if (act.startsWith('shift →')) return act.replace('shift → ', 'shift ');
  if (act.startsWith('wait ')) return `wait${act.includes('offline') ? '' : 'active'} ${entry.detail.split('→')[0].trim()}`;
  if (act.startsWith('simulate ')) {
    const egg = act.replace('simulate ', '');
    const val = entry.detail.split('→')[0].trim();
    return `${egg} ${val}`;
  }
  if (act.startsWith('buy CR')) return `buy ${act.match(/#(\d+)/)?.[1] || 0}`;
  if (act === 'prestige') return 'prestige';
  return `# ${act}`;
}

function copyLogEntry(cmd) {
  const ta = document.getElementById('custom-input');
  ta.value = (ta.value ? ta.value + '\n' : '') + cmd;
}

function renderEventTags() {
  const container = document.getElementById('active-events');
  container.innerHTML = Object.entries(events).map(([type, mult]) =>
    `<div class="event-tag">${mult}×${type}<button onclick="removeEvent('${type}')">×</button></div>`
  ).join('');
  const label = document.getElementById('farm-event-label');
  const parts = Object.entries(events).map(([t, m]) => `${m}×${t}`);
  label.textContent = parts.join(', ');
}

// ─── Tab System ────────────────────────────────────────────────

let currentTab = 'habs';

function switchTab(tab) {
  currentTab = tab;
  document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
  document.getElementById(`tab-${tab}`).classList.add('active');
  document.querySelectorAll('.tab-pane').forEach(p => p.classList.remove('active'));
  document.getElementById(`tab-${tab}-content`).classList.add('active');
  renderActiveTab();
}

function renderActiveTab() {
  if (!upgradeCosts) return;
  switch(currentTab) {
    case 'habs': renderHabsTab(); break;
    case 'cr': renderCRTab(); break;
    case 'vehicles': renderVehiclesTab(); break;
    case 'silos': renderSilosTab(); break;
    case 'artifacts': renderArtifactsTab(); break;
  }
}

// ─── Habs Tab ──────────────────────────────────────────────────

function renderHabsTab() {
  const habs = upgradeCosts?.habs || [];
  const cash = parseCashVal(state?.cash || 0);
  const el = document.getElementById('tab-habs-content');
  el.innerHTML = `<div class="hab-grid">${habs.map(h => {
    const canAfford = h.maxed ? false : (cash >= h.cost_raw);
    return `
      <div class="hab-card">
        <div class="hab-card-title">Hab ${h.index + 1}</div>
        <div class="hab-card-value">${h.capacity}</div>
        ${h.maxed ? '<div class="hab-card-next" style="color:var(--green)">MAXED</div>' :
          `<div class="hab-card-next">→ ${h.next_capacity}</div>
           <div class="hab-card-cost">${h.cost}</div>
           <button class="btn-upgrade" onclick="buyUpgrade('hab', ${h.index})"
             ${canAfford ? '' : 'disabled'}>upgrade</button>`}
      </div>`;
  }).join('')}</div>
  <div style="margin-top:12px">
    <button class="btn-action" onclick="doBuyAll('hab')">buy all habs</button>
  </div>`;
}

// ─── CR Tab ────────────────────────────────────────────────────

function renderCRTab() {
  const cr = upgradeCosts?.cr || [];
  const cash = parseCashVal(state?.cash || 0);
  const el = document.getElementById('tab-cr-content');
  if (cr.length === 0) {
    el.innerHTML = '<div style="color:var(--text-muted);font-size:12px;padding:20px">No research available on this farm.</div>';
    return;
  }
  el.innerHTML = `<div class="cr-list">${cr.map(r => {
    const canAfford = cash >= r.cost_raw;
    return `
      <div class="cr-item">
        <div class="cr-tier">T${r.tier}</div>
        <div class="cr-name">${r.name}</div>
        <div class="cr-effect">${r.effect}</div>
        <div class="cr-level">${r.level}/${r.max}</div>
        <div class="cr-cost">${r.cost}</div>
        <button class="btn-buy-small" onclick="buyUpgrade('cr', ${r.index})"
          ${canAfford ? '' : 'style="opacity:0.4"'}>buy</button>
      </div>`;
  }).join('')}</div>
  <div style="margin-top:10px;display:flex;gap:8px">
    <button class="btn-action" onclick="doBuyAll('cr')">buy all research</button>
  </div>`;
}

// ─── Vehicles Tab ──────────────────────────────────────────────

function renderVehiclesTab() {
  const vehs = upgradeCosts?.vehicles || [];
  const cash = parseCashVal(state?.cash || 0);
  const el = document.getElementById('tab-vehicles-content');
  el.innerHTML = `<div class="vehicle-grid">${vehs.map(v => {
    const canAfford = cash >= v.cost_raw;
    return `
      <div class="vehicle-card">
        <div class="vehicle-card-label">Veh ${v.index + 1}</div>
        <div class="vehicle-card-level">Lv ${v.level}</div>
        <div class="vehicle-card-cap">${v.capacity}/min</div>
        <div class="vehicle-card-cost">${v.cost}</div>
        <button class="btn-upgrade" onclick="buyUpgrade('vehicle', ${v.index})"
          ${canAfford ? '' : 'disabled'} style="font-size:9px">upgrade</button>
      </div>`;
  }).join('')}</div>
  <div style="margin-top:12px">
    <button class="btn-action" onclick="doBuyAll('vehicle')">buy all vehicles</button>
  </div>`;
}

// ─── Silos Tab ─────────────────────────────────────────────────

function renderSilosTab() {
  const silo = upgradeCosts?.silo;
  if (!silo) return;
  const el = document.getElementById('tab-silos-content');
  const dots = Array.from({length:10}, (_,i) =>
    `<div class="silo-dot ${i < silo.count ? 'owned' : ''}">🏚️</div>`
  ).join('');
  el.innerHTML = `
    <div class="silo-display">${dots}</div>
    <div class="silo-info">
      <p>Silos owned: <span>${silo.count}/10</span></p>
      <p>Max away time: <span>${state ? calcAwayTime(state) : '—'}</span></p>
      ${silo.maxed ? '' : `<p>Upgrade cost: <span>${silo.cost}</span></p>`}
    </div>
    ${silo.maxed ? '' :
      `<button class="btn-upgrade" style="width:120px" onclick="buyUpgrade('silo', 0)">Buy Silo</button>`}
  `;
}

function calcAwayTime(s) {
  const mins = (60 + 6 * (s.er?.[2] || 0)) * (s.silos || 1);
  if (mins < 60) return `${mins}min`;
  return `${(mins/60).toFixed(1)}h`;
}

// ─── Artifacts Tab ─────────────────────────────────────────────

function renderArtifactsTab() {
  if (!state) return;
  const el = document.getElementById('tab-artifacts-content');
  const slots = ['a1','a2','a3','a4'];
  el.innerHTML = `<div class="artifact-display-grid">${slots.map(slot => {
    const art = state.artifact_set?.[slot];
    if (!art || !art.type) return `
      <div class="artifact-display-card empty">
        <span>${slot.toUpperCase()}</span>
        <span>empty</span>
      </div>`;
    const stones = (art.stones || []).filter(s => s.type).map(s =>
      `<div class="stone-chip">${s.type} ${s.level}</div>`
    ).join('');
    return `
      <div class="artifact-display-card">
        <div class="artifact-display-name">${art.type} T${art.level}R${art.rarity}</div>
        <div class="artifact-display-effect">×effect</div>
        ${stones ? `<div class="artifact-display-stones">${stones}</div>` : ''}
      </div>`;
  }).join('')}</div>
  <div style="margin-top:12px">
    <button class="btn-secondary" onclick="openFarmModal()">Edit Artifacts</button>
  </div>`;
}

// ─── Actions ───────────────────────────────────────────────────

async function simulateEgg() {
  const egg = document.getElementById('sim-egg-select').value;
  const mode = document.querySelector('input[name="sim-mode"]:checked').value;
  const value = document.getElementById('sim-value').value.trim();
  await apiAction('/api/action/simulate_egg', { egg, mode, value });
  showToast(`Simulated ${egg} for ${value}`);
}

async function doWait(mode) {
  const waitMode = document.querySelector('input[name="wait-mode"]:checked').value;
  const value = document.getElementById('wait-value').value.trim();
  await apiAction('/api/action/wait', { mode, wait_type: waitMode, value });
  showToast(`Waited ${value} (${mode})`);
}

async function doShift(egg) {
  await apiAction('/api/action/shift', { egg });
  showToast(`Shifted to ${egg}`);
}

async function buyUpgrade(type, index) {
  await apiAction('/api/action/buy', { type, index });
}

async function doBuyAll(type) {
  const t = type || (
    state?.egg === 'curiosity' ? 'cr' :
    state?.egg === 'integrity' ? 'hab' :
    state?.egg === 'kindness' ? 'vehicle' :
    state?.egg === 'resilience' ? 'silo' : 'cr'
  );
  await apiAction('/api/action/buy_all', { type: t });
  showToast(`Bought all ${t}`);
}

async function doPrestige() {
  await apiAction('/api/action/prestige');
  showToast('Prestiged!');
}

function addEvent() {
  const mult = parseFloat(document.getElementById('event-mult').value) || 2;
  const type = document.getElementById('event-type').value;
  events[type] = mult;
  renderEventTags();
  // Apply events to state (stored client-side for now)
  if (state) state._events = events;
  showToast(`Added ${mult}× ${type} event`);
}

function removeEvent(type) {
  delete events[type];
  renderEventTags();
}

function clearEvents() {
  events = {};
  renderEventTags();
  showToast('Events cleared');
}

// ─── Farm Modal ────────────────────────────────────────────────

function openFarmModal() {
  if (state) {
    document.getElementById('modal-egg').value = state.egg || 'curiosity';
    document.getElementById('modal-te').value = state.te || 0;
    document.getElementById('modal-se').value = state.se || 0;
    document.getElementById('modal-pe').value = state.pe || 0;
    document.getElementById('modal-video').value = state.video_doubler ? 'true' : 'false';
    document.getElementById('modal-silos').value = state.silos || 1;
    for (let i = 0; i < 5; i++) {
      document.getElementById(`modal-el-${i}`).value = formatNum(state.eggs_layed?.[i] || 0);
    }
    for (let i = 0; i < 4; i++) {
      document.getElementById(`modal-hab-${i}`).value = state.habs?.[i] || 0;
    }
    // Load artifact slots
    loadArtifactModalValues();
  }
  document.getElementById('farm-modal').style.display = 'flex';
}

function closeFarmModal() {
  document.getElementById('farm-modal').style.display = 'none';
}

async function applyFarmSetup() {
  const elInputs = [];
  for (let i = 0; i < 5; i++) {
    const raw = document.getElementById(`modal-el-${i}`).value;
    elInputs.push(parseEggNum(raw));
  }

  const newFarmData = {
    egg: document.getElementById('modal-egg').value,
    te: parseInt(document.getElementById('modal-te').value) || 0,
    se: parseEggNum(document.getElementById('modal-se').value),
    pe: parseInt(document.getElementById('modal-pe').value) || 0,
    video_doubler: document.getElementById('modal-video').value === 'true',
    silos: parseInt(document.getElementById('modal-silos').value) || 1,
    eggs_layed: elInputs,
    habs: [0,1,2,3].map(i => parseInt(document.getElementById(`modal-hab-${i}`).value) || 0),
    artifact_set: collectArtifactModalValues(),
    cr: state?.cr || Array(56).fill(0),
    er: state?.er || [15,20,20,20,20,10,10,10,20,100,20,12,20,140,20,20,30,10,20,5,60,10],
    vehicles: state?.vehicles || [1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
    pop: 0,
    cash: 0,
    colleggtibles: state?.colleggtibles || Array(11).fill(4),
  };

  closeFarmModal();
  const data = await apiFetch('/api/state/init', 'POST', newFarmData);
  state = data.state;
  renderAll(data.stats);
  await refreshUpgrades();
  showToast('Farm updated!');
}

// ─── Artifact Modal Builder ────────────────────────────────────

const ARTIFACT_TYPES = ['cube','totem','necklace','vial','brooch','ankh','gusset','medallion',
  'lens','beak','rainstick','compass','chalice','feather','metronome','monocle',
  'actuator','ship','deflector','book','light'];
const STONE_TYPES = ['lunar','shell','tachyon','terra','soul','dilithium','quantum','life','clarity','prophecy'];

function buildArtifactModalHTML() {
  const container = document.getElementById('modal-artifacts');
  container.innerHTML = `<div class="artifact-slots">${['a1','a2','a3','a4'].map(slot => `
    <div class="artifact-slot">
      <div class="artifact-slot-title">${slot.toUpperCase()}</div>
      <div class="artifact-row">
        <select id="m-art-${slot}-type" onchange="updateArtifactSlot('${slot}')">
          <option value="">— none —</option>
          ${ARTIFACT_TYPES.map(t => `<option value="${t}">${t}</option>`).join('')}
        </select>
        <select id="m-art-${slot}-level">
          <option value="1">T1</option><option value="2">T2</option>
          <option value="3">T3</option><option value="4">T4</option>
        </select>
        <select id="m-art-${slot}-rarity">
          <option value="0">R0</option><option value="1">R1</option>
          <option value="2">R2</option><option value="3">R3</option>
        </select>
      </div>
      <div class="stone-row" id="m-art-${slot}-stones">
        ${[1,2,3].map(i => `
          <select id="m-stone-${slot}-${i}">
            <option value="">— stone —</option>
            ${STONE_TYPES.map(s => `<option value="${s}">${s}</option>`).join('')}
          </select>
          <select id="m-stone-${slot}-${i}-lv" style="max-width:48px">
            <option value="2">lv2</option><option value="3">lv3</option><option value="4">lv4</option>
          </select>
        `).join('')}
      </div>
    </div>`).join('')}</div>`;
}

function updateArtifactSlot(slot) {
  // Could filter valid combos — for now just a visual hook
}

function loadArtifactModalValues() {
  if (!state?.artifact_set) return;
  ['a1','a2','a3','a4'].forEach(slot => {
    const art = state.artifact_set[slot];
    if (!art) return;
    const typeEl = document.getElementById(`m-art-${slot}-type`);
    if (typeEl) typeEl.value = art.type || '';
    const lvEl = document.getElementById(`m-art-${slot}-level`);
    if (lvEl) lvEl.value = art.level || 1;
    const rarEl = document.getElementById(`m-art-${slot}-rarity`);
    if (rarEl) rarEl.value = art.rarity || 0;
    (art.stones || []).forEach((stone, i) => {
      const si = i + 1;
      const sel = document.getElementById(`m-stone-${slot}-${si}`);
      const slv = document.getElementById(`m-stone-${slot}-${si}-lv`);
      if (sel) sel.value = stone.type || '';
      if (slv) slv.value = stone.level || 2;
    });
  });
}

function collectArtifactModalValues() {
  const result = {};
  ['a1','a2','a3','a4'].forEach(slot => {
    const type = document.getElementById(`m-art-${slot}-type`)?.value || '';
    const level = parseInt(document.getElementById(`m-art-${slot}-level`)?.value) || 1;
    const rarity = parseInt(document.getElementById(`m-art-${slot}-rarity`)?.value) || 0;
    const stones = [1,2,3].map(i => ({
      type: document.getElementById(`m-stone-${slot}-${i}`)?.value || '',
      level: parseInt(document.getElementById(`m-stone-${slot}-${i}-lv`)?.value) || 2
    }));
    result[slot] = { type, level, rarity, stones };
  });
  return result;
}

// ─── Snapshots ─────────────────────────────────────────────────

function saveSnapshot() {
  if (!state) return;
  const label = `Snapshot ${snapshots.length + 1}`;
  const te = (state.te || 0) + (state.eggs_layed || []).reduce((s, e) => {
    return s + teNumbers(e);
  }, 0);
  snapshots.push({ label, state: JSON.parse(JSON.stringify(state)), te, time: state.time_elapsed });
  renderSnapshots();
  showToast(`Saved ${label}`);
}

function renderSnapshots() {
  const el = document.getElementById('snapshots-list');
  el.innerHTML = snapshots.map((snap, i) => `
    <div class="snapshot-item">
      <span class="snapshot-label">${snap.label}</span>
      <span class="snapshot-te">${snap.te} TE</span>
      <button class="snapshot-btn-load" onclick="loadSnapshot(${i})">load</button>
      <button class="snapshot-btn-load" onclick="deleteSnapshot(${i})" style="color:var(--red)">×</button>
    </div>
  `).join('');
}

async function loadSnapshot(i) {
  state = JSON.parse(JSON.stringify(snapshots[i].state));
  const stats = await apiFetch('/api/stats', 'POST', { state });
  renderAll(stats);
  await refreshUpgrades();
  showToast(`Loaded ${snapshots[i].label}`);
}

function deleteSnapshot(i) {
  snapshots.splice(i, 1);
  renderSnapshots();
}

// ─── Replay ────────────────────────────────────────────────────

async function replayInput() {
  const raw = document.getElementById('custom-input').value.trim();
  if (!raw) return;
  const lines = raw.split('\n').filter(l => l.trim() && !l.trim().startsWith('#'));
  for (const line of lines) {
    const parts = line.trim().split(/\s+/);
    const cmd = parts[0];
    const arg = parts.slice(1).join(' ');
    try {
      if (cmd === 'shift') await apiAction('/api/action/shift', { egg: arg });
      else if (cmd === 'wait') await apiAction('/api/action/wait', { mode: 'offline', wait_type: 'time', value: arg });
      else if (cmd === 'waitactive') await apiAction('/api/action/wait', { mode: 'active', wait_type: 'time', value: arg });
      else if (['curiosity','kindness','resilience','humility','integrity'].includes(cmd)) {
        await apiAction('/api/action/simulate_egg', { egg: cmd, mode: 'time', value: arg });
      } else if (cmd === 'buyall') await apiAction('/api/action/buy_all', { type: arg || 'cr' });
      else if (cmd === 'prestige') await apiAction('/api/action/prestige');
    } catch(e) { console.warn('Replay error:', e); }
  }
  showToast('Replay complete');
}

// ─── Helpers ───────────────────────────────────────────────────

function parseCashVal(v) { return typeof v === 'number' ? v : 0; }

function parseEggNum(s) {
  if (!s || s === '0') return 0;
  s = s.toString().trim();
  const units = {'K':1e3,'M':1e6,'B':1e9,'T':1e12,'q':1e15,'Q':1e18,'s':1e21,'S':1e24};
  const match = s.match(/^([0-9]*\.?[0-9]+)([A-Za-z]*)$/);
  if (!match) return parseFloat(s) || 0;
  const num = parseFloat(match[1]);
  const unit = match[2];
  return num * (units[unit] || 1);
}

function formatNum(n) {
  if (!n) return '0';
  const units = ['','K','M','B','T','q','Q','s','S','o','N'];
  const k = Math.max(0, Math.floor(Math.log10(Math.abs(n)) / 3));
  if (k >= units.length) return n.toExponential(2);
  const m = n / Math.pow(10, 3*k);
  return `${m >= 100 ? Math.round(m) : m >= 10 ? m.toFixed(1) : m.toFixed(2)}${units[k]}`;
}

function teNumbers(eggs) {
  const thresholds = [0, 50e6, 1e9, 10e9, 70e9, 500e9, 2e13, 7e12, 20e12, 60e12, 150e12, 500e12, 1.5e15, 4e15, 10e15, 25e15, 50e15, 100e15];
  let i = 0;
  while (i < 18) { if (thresholds[i] > eggs) return i - 1; i++; }
  const a = 0.5, b = 12.5, c = 68 - (eggs - 1e17) / 1e16;
  const d = b*b - 4*a*c;
  if (d < 0) return 17;
  return Math.floor((-b + Math.sqrt(d)) / (2*a)) - 1;
}

function escapeHtml(s) {
  return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}

// ─── Toast ─────────────────────────────────────────────────────

let toastTimer = null;
function showToast(msg, error = false) {
  const el = document.getElementById('toast');
  el.textContent = msg;
  el.className = `toast show ${error ? 'error' : ''}`;
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => el.className = 'toast', 2500);
}

// ─── Boot ──────────────────────────────────────────────────────

window.addEventListener('DOMContentLoaded', init);
