import sys
import os
sys.path.insert(0, os.path.dirname(__file__))

from flask import Flask, jsonify, request, render_template, session
import numpy as np
import json
import copy
import math

from farm.farm import Farm, egg_specs, max_cr, max_er, hab_capacities, vehicle_capacities
from farm.artifact import Artifact, Artifact_set, Stone, artifact_specs, stone_specs
from farm.prices import cr_prices, hab_prices, vehicle_prices, silo_price, cr_names, cr_bounds
from methods import format as fmt, format_time, egg_read, read_time

app = Flask(__name__)
app.secret_key = 'eggsim_secret_key_2024'

# ─── State Management ────────────────────────────────────────────────────────

def default_state():
    return {
        "egg": "curiosity",
        "te": 0,
        "se": 0,
        "pe": 0,
        "cr": [0] * 56,
        "er": [15,20,20,20,20,10,10,10,20,100,20,12,20,140,20,20,30,10,20,5,60,10],
        "silos": 1,
        "habs": [1, 0, 0, 0],
        "vehicles": [1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
        "pop": 0,
        "cash": 0,
        "colleggtibles": [4]*11,
        "video_doubler": True,
        "eggs_layed": [0, 0, 0, 0, 0],
        "time_elapsed": 0,
        "shifts": 0,
        "log": [],
        "artifact_set": {
            "a1": {"type": "", "level": 0, "rarity": 0, "stones": [{"type":"","level":0},{"type":"","level":0},{"type":"","level":0}]},
            "a2": {"type": "", "level": 0, "rarity": 0, "stones": [{"type":"","level":0},{"type":"","level":0},{"type":"","level":0}]},
            "a3": {"type": "", "level": 0, "rarity": 0, "stones": [{"type":"","level":0},{"type":"","level":0},{"type":"","level":0}]},
            "a4": {"type": "", "level": 0, "rarity": 0, "stones": [{"type":"","level":0},{"type":"","level":0},{"type":"","level":0}]},
        }
    }

def build_artifact_set(aset_data):
    def make_stone(s):
        if not s or s.get("type","") == "":
            return Stone()
        return Stone(type=s["type"], level=int(s["level"]))
    def make_artifact(a):
        if not a or a.get("type","") == "":
            return Artifact()
        stones = a.get("stones", [{},{},{}])
        while len(stones) < 3:
            stones.append({"type":"","level":0})
        return Artifact(
            type=a["type"], level=int(a["level"]), rarity=int(a["rarity"]),
            stone1=make_stone(stones[0]),
            stone2=make_stone(stones[1]),
            stone3=make_stone(stones[2])
        )
    return Artifact_set(
        a1=make_artifact(aset_data.get("a1",{})),
        a2=make_artifact(aset_data.get("a2",{})),
        a3=make_artifact(aset_data.get("a3",{})),
        a4=make_artifact(aset_data.get("a4",{})),
    )

def build_farm(state):
    aset = build_artifact_set(state["artifact_set"])
    return Farm(
        egg=state["egg"],
        cr=np.array(state["cr"]),
        er=state["er"],
        silos=state["silos"],
        habs=state["habs"],
        vehicles=state["vehicles"],
        se=state["se"],
        pe=state["pe"],
        te=state["te"],
        colleggtibles=np.array(state["colleggtibles"]),
        pop=state["pop"],
        artifact_set=aset,
        video_doubler=state["video_doubler"],
        cash=state["cash"]
    )

def serialize_state(state):
    s = copy.deepcopy(state)
    if isinstance(s["cr"], np.ndarray):
        s["cr"] = s["cr"].tolist()
    if isinstance(s["colleggtibles"], np.ndarray):
        s["colleggtibles"] = s["colleggtibles"].tolist()
    return s

virtue_egg_index = {"curiosity":0,"kindness":1,"resilience":2,"humility":3,"integrity":4}
te_thresholds_base = [0, 50e6, 1e9, 10e9, 70e9, 500e9, 2e13, 7e12, 20e12, 60e12, 150e12, 500e12, 1.5e15, 4e15, 10e15, 25e15, 50e15, 100e15]

def te_threshold(n):
    if n < 17:
        return te_thresholds_base[n]
    return 1e17 + (n-17)*1e16*(n/2 - 4)

def te_numbers(eggs_layed):
    i = 0
    while i < 18:
        if te_threshold(i) > eggs_layed:
            return i - 1
        i += 1
    a, b, c = 0.5, 12.5, 68-(eggs_layed-1e17)/1e16
    d = b**2 - 4*a*c
    if d < 0: return 0
    r1 = (-b + math.sqrt(d)) / (2*a)
    r2 = (-b - math.sqrt(d)) / (2*a)
    pos = r1 if r1 >= 0 else r2
    return int(math.floor(pos)) - 1

def add_log(state, action, detail=""):
    state["log"].append({"action": action, "detail": detail, "time": fmt_time_log(state["time_elapsed"])})
    if len(state["log"]) > 100:
        state["log"] = state["log"][-100:]

def fmt_time_log(t):
    if t < 60: return f"{t:.0f}s"
    if t < 3600: return f"{t/60:.1f}min"
    if t < 86400: return f"{t/3600:.2f}h"
    return f"{t/86400:.2f}d"

def get_farm_stats(state):
    try:
        f = build_farm(state)
        eggs = state["eggs_layed"]
        te_list = [te_numbers(e) for e in eggs]
        te_total = sum(te_list) + state["te"]
        
        virtue_eggs_info = []
        egg_names = ["curiosity","kindness","resilience","humility","integrity"]
        for i, en in enumerate(egg_names):
            tn = te_numbers(eggs[i])
            next_thresh = te_threshold(tn + 1)
            progress = eggs[i] / next_thresh if next_thresh > 0 else 1.0
            virtue_eggs_info.append({
                "name": en,
                "layed": fmt(eggs[i]),
                "next": fmt(next_thresh),
                "te": tn,
                "progress": min(progress, 1.0)
            })

        return {
            "egg": state["egg"],
            "cash": fmt(f.cash),
            "time": fmt_time_log(state["time_elapsed"]),
            "pop": fmt(f.pop),
            "hab_size": fmt(f.hab_size),
            "shipping": fmt(f.max_shipping * 60),
            "laying": fmt(f.laying_chick * f.pop * 60),
            "earnings_away": fmt(f.earnings_away()),
            "earnings_active": fmt(f.earnings_active()),
            "te": state["te"],
            "te_pending": sum(te_list),
            "shifts": state["shifts"],
            "habs": state["habs"],
            "vehicles": state["vehicles"][:f.max_vehicle_number],
            "max_vehicle_number": f.max_vehicle_number,
            "silos": state["silos"],
            "max_away_time": fmt_time_log(f.max_away_time * 60),
            "cr": state["cr"],
            "farm_value": fmt(f.farm_value()),
            "egg_value": fmt(f.egg_value),
            "ihr": fmt(f.ihr * 60),
            "max_rcb": round(f.max_rcb, 2),
            "virtue_eggs": virtue_eggs_info,
            "eb": round(f.eb, 2),
        }
    except Exception as e:
        return {"error": str(e)}

# ─── Routes ───────────────────────────────────────────────────────────────────

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/api/state/init', methods=['POST'])
def init_state():
    data = request.json or {}
    state = default_state()
    # Apply initial farm data if provided
    for key in ["egg","te","se","pe","cr","er","silos","habs","vehicles","pop","cash","colleggtibles","video_doubler","eggs_layed","artifact_set"]:
        if key in data:
            state[key] = data[key]
    state["log"] = []
    state["time_elapsed"] = 0
    state["shifts"] = 0
    return jsonify({"state": serialize_state(state), "stats": get_farm_stats(state)})

@app.route('/api/stats', methods=['POST'])
def get_stats():
    state = request.json.get("state", default_state())
    return jsonify(get_farm_stats(state))

@app.route('/api/action/wait', methods=['POST'])
def action_wait():
    data = request.json
    state = data["state"]
    mode = data.get("mode", "offline")  # offline / active
    wait_type = data.get("wait_type", "time")  # time / cash
    value = data.get("value", "1h")

    try:
        f = build_farm(state)
        cr_arr = np.array(state["cr"])
        coll_arr = np.array(state["colleggtibles"])
        aset = build_artifact_set(state["artifact_set"])
        f2 = Farm(egg=state["egg"], cr=cr_arr, er=state["er"], silos=state["silos"],
                  habs=state["habs"], vehicles=state["vehicles"], se=state["se"],
                  pe=state["pe"], te=state["te"], colleggtibles=coll_arr,
                  pop=state["pop"], artifact_set=aset, video_doubler=state["video_doubler"],
                  cash=state["cash"])
        apply_events_to_farm(f2, state)
        
        if wait_type == "cash":
            target_cash = egg_read(str(value))
            if mode == "offline":
                t = _time_cash_away(f2, target_cash)
            else:
                t = _time_cash_active(f2, target_cash)
        else:
            t = read_time(str(value))

        if mode == "offline":
            layed, cash_earned, new_pop = _simulate_offline(f2, t)
        else:
            layed, cash_earned, new_pop = _simulate_active(f2, t)

        state["pop"] = new_pop
        state["cash"] = f2.cash + cash_earned
        if state["egg"] in virtue_egg_index:
            state["eggs_layed"][virtue_egg_index[state["egg"]]] += layed
        state["time_elapsed"] += t

        add_log(state, f"wait {mode}", f"{fmt_time_log(t)} → +{fmt(cash_earned)} cash, +{fmt(layed)} eggs")
        return jsonify({"state": serialize_state(state), "stats": get_farm_stats(state)})
    except Exception as e:
        import traceback; traceback.print_exc()
        return jsonify({"error": str(e)}), 400

@app.route('/api/action/simulate_egg', methods=['POST'])
def action_simulate_egg():
    data = request.json
    state = data["state"]
    target_egg = data.get("egg", state["egg"])
    mode = data.get("mode", "time")  # time / te
    value = data.get("value", "1h")

    try:
        # shift if needed
        if target_egg != state["egg"]:
            state["egg"] = target_egg
            state["cash"] = 0
            state["pop"] = 0
            state["shifts"] += 1
            add_log(state, f"shift → {target_egg}", "")

        if mode == "te":
            te_target = int(value)
            lay_target = te_threshold(te_target)
            current_layed = state["eggs_layed"][virtue_egg_index[target_egg]]
            if lay_target <= current_layed:
                return jsonify({"state": serialize_state(state), "stats": get_farm_stats(state)})
            t = _time_to_lay(state, lay_target - current_layed)
        else:
            t = read_time(str(value))

        # run simulation loop with purchases
        state = _simulate_egg_run(state, t, mode, value)
        add_log(state, f"simulate {target_egg}", f"{value} → {fmt(state['eggs_layed'][virtue_egg_index[target_egg]])} eggs")
        return jsonify({"state": serialize_state(state), "stats": get_farm_stats(state)})
    except Exception as e:
        import traceback; traceback.print_exc()
        return jsonify({"error": str(e)}), 400

@app.route('/api/action/shift', methods=['POST'])
def action_shift():
    data = request.json
    state = data["state"]
    new_egg = data.get("egg")
    if new_egg not in virtue_egg_index:
        return jsonify({"error": "Invalid egg"}), 400
    if new_egg == state["egg"]:
        return jsonify({"state": serialize_state(state), "stats": get_farm_stats(state)})
    state["egg"] = new_egg
    state["cash"] = 0
    state["pop"] = 0
    state["shifts"] += 1
    add_log(state, f"shift → {new_egg}", "")
    return jsonify({"state": serialize_state(state), "stats": get_farm_stats(state)})

@app.route('/api/action/buy', methods=['POST'])
def action_buy():
    data = request.json
    state = data["state"]
    buy_type = data.get("type")  # cr, hab, vehicle, silo
    index_val = data.get("index", 0)

    try:
        f = build_farm(state)
        if buy_type == "cr":
            i = int(index_val)
            cost = cr_prices[i][int(state["cr"][i])] * f.artf.cr_cost * (1-0.05*state["er"][7])
            if state["cash"] < cost:
                return jsonify({"error": "Not enough cash"}), 400
            state["cash"] -= cost
            state["cr"][i] += 1
            add_log(state, f"buy CR #{i}", f"{cr_names[i][1]} → lv{int(state['cr'][i])}")

        elif buy_type == "hab":
            i = int(index_val)
            same = sum(1 for j in range(4) if state["habs"][j] == state["habs"][i]+1)
            cost = hab_prices[state["habs"][i]][same] * (1-0.05*state["er"][5])
            if state["cash"] < cost:
                return jsonify({"error": "Not enough cash"}), 400
            state["cash"] -= cost
            state["habs"][i] += 1
            add_log(state, f"buy hab {i}", f"→ lv{state['habs'][i]}")

        elif buy_type == "vehicle":
            i = int(index_val)
            f = build_farm(state)
            veh_level = int(state["vehicles"][i])
            if veh_level > 12:
                cost = vehicle_prices[12][veh_level-12] * (1-0.05*state["er"][6])
            else:
                same = sum(1 for j in range(f.max_vehicle_number) if state["vehicles"][j] == veh_level+1)
                cost = vehicle_prices[veh_level][same] * (1-0.05*state["er"][6])
            if state["cash"] < cost:
                return jsonify({"error": "Not enough cash"}), 400
            state["cash"] -= cost
            state["vehicles"][i] += 1
            add_log(state, f"buy vehicle {i}", f"→ lv{int(state['vehicles'][i])}")

        elif buy_type == "silo":
            cost = silo_price[state["silos"]]
            if state["cash"] < cost:
                return jsonify({"error": "Not enough cash"}), 400
            state["cash"] -= cost
            state["silos"] += 1
            add_log(state, f"buy silo", f"→ {state['silos']} silos")

        return jsonify({"state": serialize_state(state), "stats": get_farm_stats(state)})
    except Exception as e:
        import traceback; traceback.print_exc()
        return jsonify({"error": str(e)}), 400

@app.route('/api/action/buy_all', methods=['POST'])
def action_buy_all():
    data = request.json
    state = data["state"]
    buy_type = data.get("type")
    count = 0
    max_iter = 200
    for _ in range(max_iter):
        f = build_farm(state)
        bought = False
        if buy_type == "cr" and state["egg"] == "curiosity":
            best_i, best_cost = None, None
            research_count = sum(state["cr"])
            for i in range(56):
                if state["cr"][i] >= max_cr[i]: continue
                if cr_bounds[cr_names[i][0]-1] > research_count: continue
                cost = cr_prices[i][int(state["cr"][i])] * f.artf.cr_cost * (1-0.05*state["er"][7])
                if state["cash"] >= cost and (best_cost is None or cost < best_cost):
                    best_cost = cost
                    best_i = i
            if best_i is not None:
                state["cash"] -= best_cost
                state["cr"][best_i] += 1
                count += 1
                bought = True
        elif buy_type == "hab" and state["egg"] == "integrity":
            best_i, best_cost = None, None
            for i in range(4):
                if state["habs"][i] >= 19: continue
                same = sum(1 for j in range(4) if state["habs"][j] == state["habs"][i]+1)
                cost = hab_prices[state["habs"][i]][same] * (1-0.05*state["er"][5])
                if state["cash"] >= cost and (best_cost is None or cost < best_cost):
                    best_cost = cost
                    best_i = i
            if best_i is not None:
                state["cash"] -= best_cost
                state["habs"][best_i] += 1
                count += 1
                bought = True
        elif buy_type == "vehicle" and state["egg"] == "kindness":
            best_i, best_cost = None, None
            for i in range(f.max_vehicle_number):
                vl = int(state["vehicles"][i])
                if vl > 12:
                    cost = vehicle_prices[12][vl-12] * (1-0.05*state["er"][6])
                else:
                    same = sum(1 for j in range(f.max_vehicle_number) if state["vehicles"][j] == vl+1)
                    cost = vehicle_prices[vl][same] * (1-0.05*state["er"][6])
                if state["cash"] >= cost and (best_cost is None or cost < best_cost):
                    best_cost = cost
                    best_i = i
            if best_i is not None:
                state["cash"] -= best_cost
                state["vehicles"][best_i] += 1
                count += 1
                bought = True
        if not bought:
            break
    add_log(state, f"buy all {buy_type}", f"bought {count} items")
    return jsonify({"state": serialize_state(state), "stats": get_farm_stats(state)})

@app.route('/api/action/prestige', methods=['POST'])
def action_prestige():
    data = request.json
    state = data["state"]
    pending_te = int(data.get("pending_te", 0))
    if pending_te == 0:
        # Calculate it server-side
        pending_te = sum(te_numbers(e) for e in state["eggs_layed"])
    
    add_log(state, "prestige", f"Claimed {pending_te} TE. Time: {fmt_time_log(state['time_elapsed'])}")
    
    # Claim pending TE
    state["te"] = state["te"] + pending_te
    
    # Reset farm state (keep ER, artifacts, te; reset everything else)
    state["eggs_layed"] = [0, 0, 0, 0, 0]
    state["habs"] = [1, 0, 0, 0]
    state["vehicles"] = [1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]
    state["cr"] = [0] * 56
    state["silos"] = 1
    state["pop"] = 0
    state["cash"] = 0
    state["time_elapsed"] = 0
    state["shifts"] = 0
    state["egg"] = "curiosity"
    
    return jsonify({"state": serialize_state(state), "stats": get_farm_stats(state)})

@app.route('/api/upgrade_costs', methods=['POST'])
def get_upgrade_costs():
    state = request.json.get("state", default_state())
    try:
        f = build_farm(state)
        research_count = sum(state["cr"])

        cr_list = []
        for i in range(56):
            if state["cr"][i] >= max_cr[i]: continue
            if cr_bounds[cr_names[i][0]-1] > research_count: continue
            cost = cr_prices[i][int(state["cr"][i])] * f.artf.cr_cost * (1-0.05*state["er"][7])
            cr_list.append({
                "index": i, "name": cr_names[i][1], "effect": cr_names[i][2],
                "level": int(state["cr"][i]), "max": max_cr[i],
                "cost": fmt(cost), "cost_raw": cost, "tier": cr_names[i][0]
            })

        hab_list = []
        for i in range(4):
            if state["habs"][i] >= 19:
                hab_list.append({"index": i, "level": state["habs"][i], "maxed": True,
                                  "capacity": fmt(hab_capacities[state["habs"][i]])})
                continue
            same = sum(1 for j in range(4) if state["habs"][j] == state["habs"][i]+1)
            cost = hab_prices[state["habs"][i]][same] * (1-0.05*state["er"][5])
            hab_list.append({
                "index": i, "level": state["habs"][i], "maxed": False,
                "capacity": fmt(hab_capacities[state["habs"][i]]),
                "next_capacity": fmt(hab_capacities[state["habs"][i]+1]),
                "cost": fmt(cost), "cost_raw": cost
            })

        veh_list = []
        for i in range(f.max_vehicle_number):
            vl = int(state["vehicles"][i])
            if vl > 12:
                cost = vehicle_prices[12][min(vl-12, 16)] * (1-0.05*state["er"][6])
            else:
                same = sum(1 for j in range(f.max_vehicle_number) if state["vehicles"][j] == vl+1)
                cost = vehicle_prices[vl][same] * (1-0.05*state["er"][6])
            veh_list.append({
                "index": i, "level": vl,
                "capacity": fmt(vehicle_capacities[min(vl, 21)]),
                "cost": fmt(cost), "cost_raw": cost
            })

        silo_info = {
            "count": state["silos"],
            "maxed": state["silos"] >= 10,
            "cost": fmt(silo_price[state["silos"]]) if state["silos"] < 10 else "maxed"
        }

        return jsonify({"cr": cr_list, "habs": hab_list, "vehicles": veh_list, "silo": silo_info})
    except Exception as e:
        import traceback; traceback.print_exc()
        return jsonify({"error": str(e)}), 400

@app.route('/api/metadata', methods=['GET'])
def get_metadata():
    return jsonify({
        "artifact_types": list(set(k.rstrip('0123456789') for k in artifact_specs.keys() if k != "00")),
        "stone_types": list(set(k.rstrip('0123456789') for k in stone_specs.keys() if k != "0")),
        "artifact_specs": artifact_specs,
        "stone_specs": stone_specs,
        "eggs": list(egg_specs.keys()),
        "virtue_eggs": ["curiosity","kindness","resilience","humility","integrity"],
    })

# ─── Simulation helpers ───────────────────────────────────────────────────────

def _simulate_offline(f, t):
    growth = f.ihr_away
    pop = f.pop
    cash = 0
    layed = 0

    if growth == 0 or pop >= f.hab_size:
        cash = f.earnings_away(pop) * t
        layed = min(pop * f.laying_chick, f.max_shipping) * t
        new_pop = pop
    else:
        t_hab = (f.hab_size - pop) / growth
        t_ship_denom = f.laying_chick * growth
        t_ship = (f.max_shipping - f.laying_chick * pop) / t_ship_denom if t_ship_denom > 0 else float('inf')
        if t_ship < 0: t_ship = 0

        if t_hab >= t and t_ship >= t:
            new_pop = pop + growth * t
            cash = f.earnings_away((new_pop + pop) / 2) * t
            layed = f.laying_chick * (new_pop + pop) / 2 * t
        elif t_hab >= t_ship and t_ship < t:
            mid_pop = pop + growth * t_ship
            cash = f.earnings_away((mid_pop + pop) / 2) * t_ship
            layed = f.laying_chick * (mid_pop + pop) / 2 * t_ship
            cash += f.earnings_away(mid_pop) * (t - t_ship)
            layed += f.max_shipping * (t - t_ship)
            new_pop = min(mid_pop + growth * (t - t_ship), f.hab_size)
        else:
            cash = f.earnings_away((f.hab_size + pop) / 2) * t_hab
            layed = f.laying_chick * (f.hab_size + pop) / 2 * t_hab
            cash += f.earnings_away(f.hab_size) * (t - t_hab)
            layed += f.laying_chick * f.hab_size * (t - t_hab)
            new_pop = f.hab_size

    return layed, cash, new_pop

def apply_events_to_farm(f, state):
    """Apply event multipliers from state._events to farm event_effects"""
    events = state.get("_events", {})
    for e_type, mult in events.items():
        try:
            f.set_event(e_type, float(mult))
        except Exception:
            pass


    growth = f.ihr_away
    pop = f.pop
    cash = 0
    layed = 0

    if growth == 0 or pop >= f.hab_size:
        cash = f.earnings_away(pop) * t
        layed = min(pop * f.laying_chick, f.max_shipping) * t
        new_pop = pop
    else:
        t_hab = (f.hab_size - pop) / growth
        t_ship_denom = f.laying_chick * growth
        t_ship = (f.max_shipping - f.laying_chick * pop) / t_ship_denom if t_ship_denom > 0 else float('inf')
        if t_ship < 0: t_ship = 0

        if t_hab >= t and t_ship >= t:
            new_pop = pop + growth * t
            cash = f.earnings_away((new_pop + pop) / 2) * t
            layed = f.laying_chick * (new_pop + pop) / 2 * t
        elif t_hab >= t_ship and t_ship < t:
            mid_pop = pop + growth * t_ship
            cash = f.earnings_away((mid_pop + pop) / 2) * t_ship
            layed = f.laying_chick * (mid_pop + pop) / 2 * t_ship
            cash += f.earnings_away(mid_pop) * (t - t_ship)
            layed += f.max_shipping * (t - t_ship)
            new_pop = min(mid_pop + growth * (t - t_ship), f.hab_size)
        else:
            cash = f.earnings_away((f.hab_size + pop) / 2) * t_hab
            layed = f.laying_chick * (f.hab_size + pop) / 2 * t_hab
            cash += f.earnings_away(f.hab_size) * (t - t_hab)
            layed += f.laying_chick * f.hab_size * (t - t_hab)
            new_pop = f.hab_size

    return layed, cash, new_pop

def _simulate_active(f, t):
    growth = f.ihr + f.manual_hatchery_rate
    pop = f.pop
    cash = 0
    layed = 0

    if pop >= f.hab_size:
        cash = f.earnings_active(pop) * t
        layed = min(pop * f.laying_chick, f.max_shipping) * t
        new_pop = pop
    else:
        t_hab = (f.hab_size - pop) / growth if growth > 0 else float('inf')
        t_ship = (f.max_shipping - f.laying_chick * pop) / (f.laying_chick * growth) if f.laying_chick * growth > 0 else float('inf')
        if t_ship < 0: t_ship = 0

        if t_hab >= t and t_ship >= t:
            new_pop = pop + growth * t
            cash = f.earnings((new_pop + pop) / 2) * f.effective_rcb * t
            cash += (f.gifts_and_drones(pop) + f.gifts_and_drones(new_pop)) / 2 * t
            layed = f.laying_chick * (new_pop + pop) / 2 * t
        elif t_hab >= t_ship and t_ship < t:
            mid_pop = pop + growth * t_ship
            cash = f.earnings((mid_pop + pop) / 2) * f.effective_rcb * t_ship
            cash += (f.gifts_and_drones(pop) + f.gifts_and_drones(mid_pop)) / 2 * t_ship
            layed = f.laying_chick * (mid_pop + pop) / 2 * t_ship
            cash += f.earnings(mid_pop) * f.effective_rcb * (t - t_ship)
            cash += f.gifts_and_drones(mid_pop) * (t - t_ship)
            layed += f.max_shipping * (t - t_ship)
            new_pop = min(mid_pop + growth * (t - t_ship), f.hab_size)
        else:
            cash = f.earnings((f.hab_size + pop) / 2) * f.effective_rcb * t_hab
            cash += (f.gifts_and_drones(pop) + f.gifts_and_drones(f.hab_size)) / 2 * t_hab
            layed = f.laying_chick * (f.hab_size + pop) / 2 * t_hab
            cash += f.earnings_active(f.hab_size) * (t - t_hab)
            layed += f.laying_chick * f.hab_size * (t - t_hab)
            new_pop = f.hab_size

    return layed, cash, new_pop

def _time_cash_away(f, target_cash):
    from methods import quad_formula
    cash_to_go = target_cash - f.cash
    if cash_to_go <= 0: return 0
    growth = f.ihr_away
    pop = f.pop
    if growth == 0 or pop >= f.hab_size:
        ea = f.earnings_away(pop)
        return cash_to_go / ea if ea > 0 else float('inf')
    t_hab = (f.hab_size - pop) / growth
    t_ship = max(0, (f.max_shipping - f.laying_chick * pop) / (f.laying_chick * growth))
    cash_hab = f.earnings_away(growth * t_hab / 2 + pop) * t_hab
    cash_ship = f.earnings_away(growth * t_ship / 2 + pop) * t_ship
    if cash_hab >= cash_to_go and cash_ship >= cash_to_go:
        return quad_formula(0.5 * growth * f.earnings_away(1), 0.5 * f.earnings_away(pop), -cash_to_go)
    elif cash_hab >= cash_ship and cash_ship < cash_to_go:
        cash_to_go -= cash_ship
        pop2 = pop + growth * t_ship
        ea = f.earnings_away(pop2)
        return cash_to_go / ea + t_ship if ea > 0 else t_ship
    else:
        cash_to_go -= cash_hab
        ea = f.earnings_away(f.hab_size)
        return cash_to_go / ea + t_hab if ea > 0 else t_hab

def _time_cash_active(f, target_cash):
    cash_to_go = target_cash - f.cash
    if cash_to_go <= 0: return 0
    ea = f.earnings_active()
    return cash_to_go / ea if ea > 0 else float('inf')

def _time_to_lay(state, lay_amount):
    f = build_farm(state)
    lay_rate = min(f.laying_chick * f.hab_size, f.max_shipping)
    return lay_amount / lay_rate if lay_rate > 0 else float('inf')

def _simulate_egg_run(state, total_time, mode, value):
    """Simplified egg run simulation with auto-purchases"""
    elapsed = 0
    max_steps = 500
    step = 0

    while elapsed < total_time and step < max_steps:
        step += 1
        f = build_farm(state)
        remaining = total_time - elapsed

        # Find cheapest next upgrade
        min_cost = float('inf')
        min_type = None
        min_index = 0
        research_count = sum(state["cr"])

        egg = state["egg"]
        if egg == "curiosity":
            for i in range(56):
                if state["cr"][i] >= max_cr[i]: continue
                if cr_bounds[cr_names[i][0]-1] > research_count: continue
                cost = cr_prices[i][int(state["cr"][i])] * f.artf.cr_cost * (1-0.05*state["er"][7])
                if cost < min_cost:
                    min_cost = cost
                    min_type = "cr"
                    min_index = i
        elif egg == "integrity":
            for i in range(4):
                if state["habs"][i] >= 19: continue
                same = sum(1 for j in range(4) if state["habs"][j] == state["habs"][i]+1)
                cost = hab_prices[state["habs"][i]][same] * (1-0.05*state["er"][5])
                if cost < min_cost:
                    min_cost = cost
                    min_type = "hab"
                    min_index = i
        elif egg == "kindness":
            for i in range(f.max_vehicle_number):
                vl = int(state["vehicles"][i])
                if vl > 12:
                    cost = vehicle_prices[12][min(vl-12,16)] * (1-0.05*state["er"][6])
                else:
                    same = sum(1 for j in range(f.max_vehicle_number) if state["vehicles"][j] == vl+1)
                    cost = vehicle_prices[vl][same] * (1-0.05*state["er"][6])
                if cost < min_cost:
                    min_cost = cost
                    min_type = "vehicle"
                    min_index = i
        elif egg == "resilience":
            if state["silos"] < 10:
                min_cost = silo_price[state["silos"]]
                min_type = "silo"

        if min_type is None:
            # Nothing to buy, just wait
            layed, cash_earned, new_pop = _simulate_offline(f, remaining)
            state["pop"] = new_pop
            state["cash"] += cash_earned
            state["eggs_layed"][virtue_egg_index[egg]] += layed
            elapsed += remaining
            break

        # Time to earn enough
        if state["cash"] >= min_cost:
            t_wait = 0
        else:
            t_wait = _time_cash_away(f, min_cost)

        if t_wait >= remaining:
            layed, cash_earned, new_pop = _simulate_offline(f, remaining)
            state["pop"] = new_pop
            state["cash"] += cash_earned
            state["eggs_layed"][virtue_egg_index[egg]] += layed
            elapsed += remaining
            break
        else:
            if t_wait > 0:
                layed, cash_earned, new_pop = _simulate_offline(f, t_wait)
                state["pop"] = new_pop
                state["cash"] += cash_earned
                state["eggs_layed"][virtue_egg_index[egg]] += layed
                elapsed += t_wait

            # Buy upgrade
            state["cash"] -= min_cost
            if min_type == "cr":
                state["cr"][min_index] += 1
            elif min_type == "hab":
                state["habs"][min_index] += 1
            elif min_type == "vehicle":
                state["vehicles"][min_index] += 1
            elif min_type == "silo":
                state["silos"] += 1

    state["time_elapsed"] += total_time
    return state

if __name__ == '__main__':
    app.run(debug=True, port=5000)
