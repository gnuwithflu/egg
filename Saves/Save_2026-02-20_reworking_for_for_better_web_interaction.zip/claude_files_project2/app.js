/* ═══════════════════════════════════════════════════════════
   PoV Simulator — Frontend App Logic v2
═══════════════════════════════════════════════════════════ */

// ─── Global State ─────────────────────────────────────────
let state = null;
let snapshots = [];
let events = {};
let metadata = null;
let upgradeCosts = null;
let currentTab = 'habs';

const EGG_EMOJI = {
  curiosity: '🔮', kindness: '💚', resilience: '🔵',
  humility: '🟣', integrity: '🟠'
};
const EGG_COLOR = {
  curiosity: 'var(--curiosity)', kindness: 'var(--kindness)',
  resilience: 'var(--resilience)', humility: 'var(--humility)',
  integrity: 'var(--integrity)'
};

// Which tab is "unlocked" per egg
const EGG_TAB = {
  curiosity:  'cr',
  integrity:  'habs',
  kindness:   'vehicles',
  resilience: 'silos',
  humility:   'artifacts',
};

// Epic research names and max levels
const ER_NAMES = [
  ['Hold to Hatch', 2], ['Hatchery Refill', 20], ['Long Away', 20], ['Accounting Tricks', 20],
  ['Bigger Habs', 20], ['Cheaper Contractors', 10], ['Lightweight Vehicles', 10],
  ['Lab Upgrade', 10], ['Epic Egg Research', 20], ['Graviton Tampering', 100],
  ['Drone Delivery', 20], ['Uber Drone Deliveries', 12], ['Away Research', 20],
  ['Enlightened Chickens', 140], ['Epic Hatchery', 20], ['Epic Int. Hatcheries', 16],
  ['Transport Upgrades', 30], ['Epic Comfy Nests', 10], ['Epic Feed Silo', 20],
  ['Epic Clairvoyance', 5], ['Silo Quality', 60], ['Epic Egg Values', 10]
];
const COLL_NAMES = [
  'Carbon', 'Chocolate', 'Easter', 'Firework', 'Flame',
  'Lithium', 'Pegg', 'Pumpkin', 'Silicon', 'Waterballoon', 'Wood'
];

// Artifact specs — keyed type+level+rarity → [effect, slots]
// We'll derive valid combos from metadata
let ARTIFACT_SPECS = {};
let STONE_SPECS = {};
const ARTIFACT_TYPES = ['cube','totem','necklace','vial','brooch','ankh','gusset','medallion',
  'lens','beak','rainstick','compass','chalice','feather','metronome','monocle',
  'actuator','ship','deflector','book','light'];
const STONE_TYPES = ['lunar','shell','tachyon','terra','soul','dilithium','quantum','life','clarity','prophecy'];

// ─── Init ──────────────────────────────────────────────────

async function init() {
  metadata = await apiFetch('/api/metadata');
  ARTIFACT_SPECS = metadata.artifact_specs || {};
  buildERGrid();
  buildCollGrid();
  buildArtifactModalHTML();

  const initData = await apiFetch('/api/state/init', 'POST', {});
  state = initData.state;
  renderAll(initData.stats);
  await refreshUpgrades();
}

// ─── API ───────────────────────────────────────────────────

async function apiFetch(url, method = 'GET', body = null) {
  const opts = { method, headers: { 'Content-Type': 'application/json' } };
  if (body !== null) opts.body = JSON.stringify(body);
  const res = await fetch(url, opts);
  const data = await res.json();
  if (data.error) { showToast(data.error, true); throw new Error(data.error); }
  return data;
}

async function apiAction(url, extra = {}) {
  setLoading(true);
  try {
    const payload = { state: applyEventsToState(state), ...extra };
    const data = await apiFetch(url, 'POST', payload);
    state = data.state;
    renderAll(data.stats);
    await refreshUpgrades();
  } catch (e) { /* toast shown */ }
  setLoading(false);
}

function applyEventsToState(s) {
  // Pass events into state so server can use them
  const copy = JSON.parse(JSON.stringify(s));
  copy._events = events;
  return copy;
}

async function refreshUpgrades() {
  try {
    upgradeCosts = await apiFetch('/api/upgrade_costs', 'POST', { state });
    updateTabLocks();
    renderActiveTab();
  } catch (e) {}
}

function setLoading(v) {
  document.querySelectorAll('.stat-value').forEach(el => el.classList.toggle('updating', v));
}

// ─── Render ────────────────────────────────────────────────

function renderAll(stats) {
  if (!stats || stats.error) {
    if (stats?.error) showToast('Error: ' + stats.error, true);
    return;
  }

  const egg = stats.egg || 'curiosity';
  const iconEl = document.getElementById('egg-icon-display');
  iconEl.textContent = EGG_EMOJI[egg] || '🥚';
  iconEl.className = `egg-icon-large ${egg}`;
  document.getElementById('farm-egg-label').textContent = egg.charAt(0).toUpperCase() + egg.slice(1);
  document.getElementById('farm-egg-label').style.color = EGG_COLOR[egg] || '';

  setText('stat-cash', stats.cash || '—');
  setText('stat-time', stats.time || '0s');
  setText('stat-earnings', stats.earnings_active || '—');
  setText('stat-away', stats.earnings_away || '—');
  setText('stat-pop', `${stats.pop || '—'} / ${stats.hab_size || '—'}`);
  setText('stat-shipping', stats.shipping || '—');
  setText('stat-laying', stats.laying || '—');
  setText('stat-ihr', stats.ihr || '—');
  setText('stat-rcb', stats.max_rcb || '—');
  setText('stat-eb', stats.eb !== undefined ? `${stats.eb.toFixed(1)}%` : '—');

  // TE display: claimed + pending
  const teClaimed = stats.te || 0;
  const tePending = stats.te_pending || 0;
  document.getElementById('te-display').textContent = `${teClaimed}+${tePending} TE`;

  const teTotal = teClaimed + tePending;
  setText('virtue-te-total', `${teClaimed} claimed`);
  setText('virtue-te-pending', tePending > 0 ? `+${tePending} pending` : '');
  setText('virtue-shifts', `${stats.shifts || 0} shifts`);

  // Highlight active egg shift button
  document.querySelectorAll('.shift-btn').forEach(btn => btn.classList.remove('active-egg'));
  const activeShiftBtn = document.querySelector(`.${egg}-btn`);
  if (activeShiftBtn) activeShiftBtn.classList.add('active-egg');

  renderVirtueRows(stats);
  renderLog();
  renderEventTags();
}

function setText(id, val) {
  const el = document.getElementById(id);
  if (el) el.textContent = val;
}

function renderVirtueRows(stats) {
  if (!stats.virtue_eggs) return;
  const colors = {
    curiosity: 'var(--curiosity)', kindness: 'var(--kindness)',
    resilience: 'var(--resilience)', humility: 'var(--humility)',
    integrity: 'var(--integrity)'
  };
  // Determine pending per egg
  const container = document.getElementById('virtue-rows');
  container.innerHTML = stats.virtue_eggs.map(v => {
    // te count on this farm (pending)
    const teCount = v.te;
    return `
    <div class="virtue-row">
      <div class="virtue-egg-dot" style="background:${colors[v.name]}"></div>
      <div class="virtue-egg-name" style="color:${colors[v.name]}">${v.name}</div>
      <div class="virtue-progress-bar">
        <div class="virtue-progress-fill" style="width:${Math.round(v.progress*100)}%;background:${colors[v.name]}"></div>
      </div>
      <div class="virtue-layed">${v.layed}</div>
      <div class="virtue-te-count" style="color:${colors[v.name]}">${teCount > 0 ? '+'+teCount : '0'} TE</div>
    </div>`;
  }).join('');
}

function renderLog() {
  if (!state) return;
  const list = document.getElementById('log-list');
  const logs = state.log || [];
  list.innerHTML = logs.slice().reverse().map(entry => `
    <div class="log-entry" onclick="copyLogEntry(${JSON.stringify(logToCommand(entry))})">
      <span class="log-time">${entry.time || ''}</span>
      <span class="log-action"><strong>${escapeHtml(entry.action)}</strong> ${escapeHtml(entry.detail || '')}</span>
    </div>
  `).join('');
}

function logToCommand(entry) {
  const act = entry.action;
  if (act.startsWith('shift →')) return act.replace('shift → ', 'shift ');
  if (act.startsWith('wait ')) return `wait ${entry.detail.split('→')[0].trim()}`;
  if (act.startsWith('simulate ')) {
    const egg = act.replace('simulate ', '');
    const val = entry.detail.split('→')[0].trim();
    return `${egg} ${val}`;
  }
  if (act === 'prestige') return 'prestige';
  return `# ${act}`;
}

function copyLogEntry(cmd) {
  const ta = document.getElementById('custom-input');
  ta.value = (ta.value ? ta.value + '\n' : '') + cmd;
}

function renderEventTags() {
  const container = document.getElementById('active-events');
  container.innerHTML = Object.entries(events).map(([type, mult]) =>
    `<div class="event-tag">${mult}×${type}<button onclick="removeEvent('${type}')">×</button></div>`
  ).join('');
  const label = document.getElementById('farm-event-label');
  const parts = Object.entries(events).map(([t, m]) => `${m}×${t}`);
  label.textContent = parts.join(', ');
}

// ─── Tab System ────────────────────────────────────────────

function updateTabLocks() {
  if (!state) return;
  const activeEgg = state.egg;
  const unlockedTab = EGG_TAB[activeEgg];
  const tabs = ['habs', 'cr', 'vehicles', 'silos', 'artifacts'];
  tabs.forEach(tab => {
    const btn = document.getElementById(`tab-${tab}`);
    if (!btn) return;
    if (tab === unlockedTab) {
      btn.classList.remove('locked');
      btn.title = '';
    } else {
      btn.classList.add('locked');
      const eggForTab = Object.entries(EGG_TAB).find(([e,t]) => t===tab)?.[0] || '';
      btn.title = `Only available on ${eggForTab} egg`;
    }
  });
  // If current tab became locked, switch to unlocked one
  if (document.getElementById(`tab-${currentTab}`)?.classList.contains('locked')) {
    switchTab(unlockedTab);
  }
}

function switchTab(tab) {
  const btn = document.getElementById(`tab-${tab}`);
  if (btn?.classList.contains('locked')) {
    showToast(`Switch to ${Object.entries(EGG_TAB).find(([e,t])=>t===tab)?.[0] || ''} egg first`, true);
    return;
  }
  currentTab = tab;
  document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
  document.getElementById(`tab-${tab}`)?.classList.add('active');
  document.querySelectorAll('.tab-pane').forEach(p => p.classList.remove('active'));
  document.getElementById(`tab-${tab}-content`)?.classList.add('active');
  renderActiveTab();
}

function renderActiveTab() {
  if (!upgradeCosts) return;
  switch(currentTab) {
    case 'habs': renderHabsTab(); break;
    case 'cr': renderCRTab(); break;
    case 'vehicles': renderVehiclesTab(); break;
    case 'silos': renderSilosTab(); break;
    case 'artifacts': renderArtifactsTab(); break;
  }
}

// ─── Habs Tab ──────────────────────────────────────────────

function renderHabsTab() {
  const habs = upgradeCosts?.habs || [];
  const cash = state?.cash || 0;
  const locked = state?.egg !== 'integrity';
  const el = document.getElementById('tab-habs-content');
  if (locked) { el.innerHTML = lockedMsg('integrity'); return; }
  el.innerHTML = `<div class="hab-grid">${habs.map(h => {
    const canAfford = !h.maxed && cash >= h.cost_raw;
    return `<div class="hab-card">
      <div class="hab-card-title">Hab ${h.index + 1}</div>
      <div class="hab-card-value">${h.capacity}</div>
      ${h.maxed
        ? '<div class="hab-card-next" style="color:var(--green)">MAXED</div>'
        : `<div class="hab-card-next">→ ${h.next_capacity}</div>
           <div class="hab-card-cost">${h.cost}</div>
           <button class="btn-upgrade" onclick="buyUpgrade('hab',${h.index})" ${canAfford?'':'disabled'}>upgrade</button>`}
    </div>`;
  }).join('')}</div>
  <div style="margin-top:12px">
    <button class="btn-action" onclick="doBuyAll('hab')">buy all habs</button>
  </div>`;
}

// ─── CR Tab ────────────────────────────────────────────────

function renderCRTab() {
  const cr = upgradeCosts?.cr || [];
  const cash = state?.cash || 0;
  const locked = state?.egg !== 'curiosity';
  const el = document.getElementById('tab-cr-content');
  if (locked) { el.innerHTML = lockedMsg('curiosity'); return; }
  if (cr.length === 0) {
    el.innerHTML = '<div class="tab-locked-msg">No research available yet.</div>';
    return;
  }

  // Group by tier
  const tiers = {};
  cr.forEach(r => {
    if (!tiers[r.tier]) tiers[r.tier] = [];
    tiers[r.tier].push(r);
  });

  const tierHtml = Object.entries(tiers).map(([tier, items]) => {
    const tierItems = items.map(r => {
      const canAfford = cash >= r.cost_raw;
      return `<div class="cr-item">
        <div class="cr-tier">T${r.tier}</div>
        <div class="cr-name" title="${escapeHtml(r.name)}">${escapeHtml(r.name)}</div>
        <div class="cr-effect">${escapeHtml(r.effect)}</div>
        <div class="cr-level">${r.level}/${r.max}</div>
        <div class="cr-cost">${r.cost}</div>
        <button class="btn-buy-small" onclick="buyUpgrade('cr',${r.index})" ${canAfford?'':'disabled'}>buy</button>
      </div>`;
    }).join('');
    return `<div class="cr-tier-section">
      <div class="cr-tier-header">
        Tier ${tier}
        <button onclick="buyAllTier(${tier})" title="Buy cheapest in Tier ${tier}">buy tier</button>
      </div>
      <div class="cr-list">${tierItems}</div>
    </div>`;
  }).join('');

  el.innerHTML = `${tierHtml}
  <div style="margin-top:10px">
    <button class="btn-action" onclick="doBuyAll('cr')">buy all research</button>
  </div>`;
}

async function buyAllTier(tier) {
  // Buy all affordable research in a given tier
  if (!upgradeCosts || !state) return;
  const cr = upgradeCosts.cr.filter(r => r.tier === tier && state.cash >= r.cost_raw);
  if (cr.length === 0) { showToast('Nothing affordable in tier ' + tier, true); return; }
  for (const r of cr) {
    await apiAction('/api/action/buy', { type: 'cr', index: r.index });
  }
}

// ─── Vehicles Tab ──────────────────────────────────────────

function renderVehiclesTab() {
  const vehs = upgradeCosts?.vehicles || [];
  const cash = state?.cash || 0;
  const locked = state?.egg !== 'kindness';
  const el = document.getElementById('tab-vehicles-content');
  if (locked) { el.innerHTML = lockedMsg('kindness'); return; }
  el.innerHTML = `<div class="vehicle-grid">${vehs.map(v => {
    const canAfford = cash >= v.cost_raw;
    return `<div class="vehicle-card">
      <div class="vehicle-card-label">Veh ${v.index+1}</div>
      <div class="vehicle-card-level">Lv ${v.level}</div>
      <div class="vehicle-card-cap">${v.capacity}/min</div>
      <div class="vehicle-card-cost">${v.cost}</div>
      <button class="btn-upgrade" onclick="buyUpgrade('vehicle',${v.index})" ${canAfford?'':'disabled'} style="font-size:10px">upgrade</button>
    </div>`;
  }).join('')}</div>
  <div style="margin-top:10px">
    <button class="btn-action" onclick="doBuyAll('vehicle')">buy all vehicles</button>
  </div>`;
}

// ─── Silos Tab ─────────────────────────────────────────────

function renderSilosTab() {
  const silo = upgradeCosts?.silo;
  const locked = state?.egg !== 'resilience';
  const el = document.getElementById('tab-silos-content');
  if (locked) { el.innerHTML = lockedMsg('resilience'); return; }
  if (!silo) return;
  const dots = Array.from({length:10}, (_,i) =>
    `<div class="silo-dot ${i < silo.count ? 'owned' : ''}">🏚️</div>`
  ).join('');
  const awayTime = calcAwayTime(state);
  el.innerHTML = `
    <div class="silo-display">${dots}</div>
    <div class="silo-info">
      <p>Silos owned: <span>${silo.count}/10</span></p>
      <p>Max away time: <span>${awayTime}</span></p>
      ${silo.maxed ? '' : `<p>Upgrade cost: <span>${silo.cost}</span></p>`}
    </div>
    ${silo.maxed ? '<p style="color:var(--green);font-size:13px;margin-top:8px">All silos owned!</p>' :
      `<button class="btn-upgrade" style="width:130px;margin-top:8px" onclick="buyUpgrade('silo',0)">Buy Silo</button>`}`;
}

function calcAwayTime(s) {
  const mins = (60 + 6 * (s?.er?.[2] || 0)) * (s?.silos || 1);
  if (mins < 60) return `${mins.toFixed(0)}min`;
  if (mins < 1440) return `${(mins/60).toFixed(1)}h`;
  return `${(mins/1440).toFixed(1)}d`;
}

// ─── Artifacts Tab ─────────────────────────────────────────

function renderArtifactsTab() {
  const el = document.getElementById('tab-artifacts-content');
  // Artifacts can be viewed from any egg, but editing redirects to modal (humility = edit)
  if (!state) return;
  const slots = ['a1','a2','a3','a4'];
  const isHumility = state.egg === 'humility';

  el.innerHTML = `<div class="artifact-display-grid">${slots.map(slot => {
    const art = state.artifact_set?.[slot];
    if (!art || !art.type) return `
      <div class="artifact-display-card empty">
        <div style="font-size:11px;color:var(--text-subtle)">${slot.toUpperCase()}</div>
        <div style="margin-top:4px">empty</div>
      </div>`;
    const key = `${art.type}${art.level}${art.rarity}`;
    const spec = ARTIFACT_SPECS[key];
    const effect = spec ? spec[0] : '?';
    const slots_count = spec ? spec[1] : 0;
    const stones = (art.stones || []).slice(0, slots_count).filter(s => s.type).map(s =>
      `<div class="stone-chip">${s.type} ${s.level}</div>`
    ).join('');
    return `
      <div class="artifact-display-card">
        <div class="artifact-display-name">${art.type} T${art.level} R${art.rarity}</div>
        <div class="artifact-display-effect">effect: ${effect}${typeof effect === 'number' && effect < 10 ? '×' : ''}</div>
        <div style="font-size:10px;color:var(--text-subtle);">${slots_count} stone slot${slots_count!==1?'s':''}</div>
        ${stones ? `<div class="artifact-display-stones" style="margin-top:4px">${stones}</div>` : ''}
      </div>`;
  }).join('')}</div>
  <div style="margin-top:12px;font-size:12px;color:var(--text-muted)">
    ${isHumility ? '' : '💡 Shift to <strong>Humility</strong> egg to edit artifacts. '}
    <button class="btn-secondary" onclick="openFarmModal()" style="margin-left:4px">Edit in Farm Setup</button>
  </div>`;
}

// ─── Actions ───────────────────────────────────────────────

async function simulateEgg() {
  const egg = document.getElementById('sim-egg-select').value;
  const mode = document.querySelector('input[name="sim-mode"]:checked').value;
  const rawVal = document.getElementById('sim-value').value.trim();
  // For TE mode the value is a number (target TE count)
  const value = mode === 'te' ? parseInt(rawVal) : rawVal;
  if (!value || (mode === 'te' && isNaN(value))) {
    showToast('Enter a valid value (e.g. 1h or 5)', true);
    return;
  }
  await apiAction('/api/action/simulate_egg', { egg, mode, value });
  showToast(`Simulated ${egg} ${mode === 'te' ? 'to TE '+value : rawVal}`);
}

async function doWait(mode) {
  const waitMode = document.querySelector('input[name="wait-mode"]:checked').value;
  const value = document.getElementById('wait-value').value.trim();
  await apiAction('/api/action/wait', { mode, wait_type: waitMode, value });
  showToast(`Waited ${value} (${mode})`);
}

async function doShift(egg) {
  await apiAction('/api/action/shift', { egg });
  showToast(`Shifted to ${egg}`);
}

async function buyUpgrade(type, index) {
  await apiAction('/api/action/buy', { type, index });
}

async function doBuyAll(type) {
  const t = type || (
    state?.egg === 'curiosity' ? 'cr' :
    state?.egg === 'integrity' ? 'hab' :
    state?.egg === 'kindness' ? 'vehicle' :
    state?.egg === 'resilience' ? 'silo' : null
  );
  if (!t) { showToast('Nothing to buy on this egg', true); return; }
  await apiAction('/api/action/buy_all', { type: t });
  showToast(`Bought all ${t}`);
}

async function doPrestige() {
  if (!state) return;
  // Prestige: claim pending TE, reset all farms
  const pendingTE = (state.eggs_layed || []).reduce((sum, e) => sum + teNumbers(e), 0);
  const confirmed = confirm(`Prestige? You will claim ${pendingTE} pending TE and reset all farms.`);
  if (!confirmed) return;
  await apiAction('/api/action/prestige', { pending_te: pendingTE });
  showToast(`Prestiged! +${pendingTE} TE claimed.`);
}

function addEvent() {
  const mult = parseFloat(document.getElementById('event-mult').value) || 2;
  const type = document.getElementById('event-type').value;
  events[type] = mult;
  renderEventTags();
  showToast(`Added ${mult}× ${type} event`);
}

function removeEvent(type) {
  delete events[type];
  renderEventTags();
}

function clearEvents() {
  events = {};
  renderEventTags();
}

// ─── Farm Modal ────────────────────────────────────────────

function openFarmModal() {
  if (state) {
    document.getElementById('modal-egg').value = state.egg || 'curiosity';
    document.getElementById('modal-te').value = state.te || 0;
    document.getElementById('modal-se').value = formatNum(state.se || 0);
    document.getElementById('modal-pe').value = state.pe || 0;
    document.getElementById('modal-video').value = state.video_doubler ? 'true' : 'false';
    document.getElementById('modal-silos').value = state.silos || 1;
    for (let i = 0; i < 5; i++) {
      document.getElementById(`modal-el-${i}`).value = formatNum(state.eggs_layed?.[i] || 0);
    }
    for (let i = 0; i < 4; i++) {
      document.getElementById(`modal-hab-${i}`).value = state.habs?.[i] || 0;
    }
    // Fill ER
    const defaultER = [15,20,20,20,20,10,10,10,20,100,20,12,20,140,20,20,30,10,20,5,60,10];
    ER_NAMES.forEach((_, i) => {
      const el = document.getElementById(`modal-er-${i}`);
      if (el) el.value = state.er?.[i] ?? defaultER[i];
    });
    // Fill Colleggtibles
    COLL_NAMES.forEach((_, i) => {
      const el = document.getElementById(`modal-coll-${i}`);
      if (el) el.value = state.colleggtibles?.[i] ?? 4;
    });
    loadArtifactModalValues();
  }
  document.getElementById('farm-modal').style.display = 'flex';
}

function closeFarmModal() {
  document.getElementById('farm-modal').style.display = 'none';
}

async function applyFarmSetup() {
  const elInputs = [];
  for (let i = 0; i < 5; i++) {
    elInputs.push(parseEggNum(document.getElementById(`modal-el-${i}`).value));
  }
  const erInputs = ER_NAMES.map((_, i) => parseInt(document.getElementById(`modal-er-${i}`)?.value) || 0);
  const collInputs = COLL_NAMES.map((_, i) => parseInt(document.getElementById(`modal-coll-${i}`)?.value) || 4);

  const newFarmData = {
    egg: document.getElementById('modal-egg').value,
    te: parseInt(document.getElementById('modal-te').value) || 0,
    se: parseEggNum(document.getElementById('modal-se').value),
    pe: parseInt(document.getElementById('modal-pe').value) || 0,
    video_doubler: document.getElementById('modal-video').value === 'true',
    silos: parseInt(document.getElementById('modal-silos').value) || 1,
    eggs_layed: elInputs,
    habs: [0,1,2,3].map(i => parseInt(document.getElementById(`modal-hab-${i}`).value) || 0),
    er: erInputs,
    colleggtibles: collInputs,
    artifact_set: collectArtifactModalValues(),
    cr: state?.cr || Array(56).fill(0),
    vehicles: state?.vehicles || [1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
    pop: 0,
    cash: 0,
  };

  closeFarmModal();
  const data = await apiFetch('/api/state/init', 'POST', newFarmData);
  state = data.state;
  renderAll(data.stats);
  await refreshUpgrades();
  showToast('Farm updated!');
}

// ─── ER + Coll Grid builders ───────────────────────────────

function buildERGrid() {
  const defaultER = [15,20,20,20,20,10,10,10,20,100,20,12,20,140,20,20,30,10,20,5,60,10];
  const grid = document.getElementById('modal-er-grid');
  if (!grid) return;
  grid.innerHTML = ER_NAMES.map(([name, maxLv], i) => `
    <div class="er-item">
      <label title="${name} (max ${maxLv})">${name}</label>
      <input type="number" id="modal-er-${i}" value="${defaultER[i]}" min="0" max="${maxLv}">
    </div>
  `).join('');
}

function buildCollGrid() {
  const grid = document.getElementById('modal-coll-grid');
  if (!grid) return;
  grid.innerHTML = COLL_NAMES.map((name, i) => `
    <div class="coll-item">
      <label title="${name}">${name}</label>
      <input type="number" id="modal-coll-${i}" value="4" min="0" max="4">
    </div>
  `).join('');
}

// ─── Artifact Modal ─────────────────────────────────────────

function buildArtifactModalHTML() {
  const container = document.getElementById('modal-artifacts');
  if (!container) return;
  container.innerHTML = `<div class="artifact-slots">${['a1','a2','a3','a4'].map(slot => `
    <div class="artifact-slot">
      <div class="artifact-slot-title">${slot.toUpperCase()}</div>
      <div class="artifact-row">
        <select id="m-art-${slot}-type" onchange="updateArtifactSlot('${slot}')">
          <option value="">— none —</option>
          ${ARTIFACT_TYPES.map(t => `<option value="${t}">${t}</option>`).join('')}
        </select>
        <select id="m-art-${slot}-level" onchange="updateArtifactSlot('${slot}')">
          <option value="1">T1</option><option value="2">T2</option>
          <option value="3">T3</option><option value="4">T4</option>
        </select>
        <select id="m-art-${slot}-rarity" onchange="updateArtifactSlot('${slot}')">
          <option value="0">R0</option><option value="1">R1</option>
          <option value="2">R2</option><option value="3">R3</option>
        </select>
      </div>
      <div class="stone-row" id="m-art-${slot}-stones">
        ${[1,2,3].map(i => `
          <div class="stone-pair" id="m-stone-${slot}-${i}-pair">
            <select id="m-stone-${slot}-${i}">
              <option value="">— stone —</option>
              ${STONE_TYPES.map(s => `<option value="${s}">${s}</option>`).join('')}
            </select>
            <select id="m-stone-${slot}-${i}-lv" style="max-width:52px">
              <option value="2">lv2</option><option value="3">lv3</option><option value="4">lv4</option>
            </select>
          </div>`).join('')}
      </div>
      <div id="m-art-${slot}-info" style="font-size:10px;color:var(--text-muted);margin-top:3px"></div>
    </div>`).join('')}</div>`;
}

function updateArtifactSlot(slot) {
  const type = document.getElementById(`m-art-${slot}-type`)?.value;
  const level = document.getElementById(`m-art-${slot}-level`)?.value;
  const rarity = document.getElementById(`m-art-${slot}-rarity`)?.value;

  if (!type) {
    // Hide all stones
    [1,2,3].forEach(i => {
      const pair = document.getElementById(`m-stone-${slot}-${i}-pair`);
      if (pair) pair.classList.add('hidden');
    });
    setText(`m-art-${slot}-info`, '');
    return;
  }

  // Validate combo exists in artifact_specs
  const key = `${type}${level}${rarity}`;
  const spec = ARTIFACT_SPECS[key];
  const infoEl = document.getElementById(`m-art-${slot}-info`);

  if (!spec) {
    // Try to find a valid rarity for this type+level
    const validRarities = [0,1,2,3].filter(r => ARTIFACT_SPECS[`${type}${level}${r}`]);
    if (infoEl) infoEl.textContent = `⚠ T${level}R${rarity} doesn't exist. Valid: R${validRarities.join(', R')}`;
    [1,2,3].forEach(i => {
      const pair = document.getElementById(`m-stone-${slot}-${i}-pair`);
      if (pair) pair.classList.add('hidden');
    });
    return;
  }

  const slots = spec[1];
  const effect = spec[0];
  if (infoEl) infoEl.textContent = `effect: ${effect} | ${slots} stone slot${slots!==1?'s':''}`;

  // Show/hide stone pairs based on allowed slots
  [1,2,3].forEach(i => {
    const pair = document.getElementById(`m-stone-${slot}-${i}-pair`);
    if (pair) {
      if (i <= slots) pair.classList.remove('hidden');
      else pair.classList.add('hidden');
    }
  });
}

function loadArtifactModalValues() {
  if (!state?.artifact_set) return;
  ['a1','a2','a3','a4'].forEach(slot => {
    const art = state.artifact_set[slot];
    if (!art) return;
    const typeEl = document.getElementById(`m-art-${slot}-type`);
    if (typeEl) typeEl.value = art.type || '';
    const lvEl = document.getElementById(`m-art-${slot}-level`);
    if (lvEl) lvEl.value = art.level || 1;
    const rarEl = document.getElementById(`m-art-${slot}-rarity`);
    if (rarEl) rarEl.value = art.rarity || 0;
    (art.stones || []).forEach((stone, i) => {
      const si = i + 1;
      const sel = document.getElementById(`m-stone-${slot}-${si}`);
      const slv = document.getElementById(`m-stone-${slot}-${si}-lv`);
      if (sel) sel.value = stone.type || '';
      if (slv) slv.value = stone.level || 2;
    });
    updateArtifactSlot(slot);
  });
}

function collectArtifactModalValues() {
  const result = {};
  ['a1','a2','a3','a4'].forEach(slot => {
    const type = document.getElementById(`m-art-${slot}-type`)?.value || '';
    const level = parseInt(document.getElementById(`m-art-${slot}-level`)?.value) || 1;
    const rarity = parseInt(document.getElementById(`m-art-${slot}-rarity`)?.value) || 0;
    const allowedSlots = ARTIFACT_SPECS[`${type}${level}${rarity}`]?.[1] || 0;
    const stones = [1,2,3].map(i => ({
      type: i <= allowedSlots ? (document.getElementById(`m-stone-${slot}-${i}`)?.value || '') : '',
      level: parseInt(document.getElementById(`m-stone-${slot}-${i}-lv`)?.value) || 2
    }));
    result[slot] = { type, level, rarity, stones };
  });
  return result;
}

// ─── Snapshots ─────────────────────────────────────────────

function saveSnapshot() {
  if (!state) return;
  const label = `Snap ${snapshots.length + 1} (${state.egg})`;
  const pending = (state.eggs_layed || []).reduce((s, e) => s + teNumbers(e), 0);
  const te = (state.te || 0) + pending;
  snapshots.push({ label, state: JSON.parse(JSON.stringify(state)), te, pending, time: state.time_elapsed });
  renderSnapshots();
  showToast(`Saved: ${label}`);
}

function renderSnapshots() {
  const el = document.getElementById('snapshots-list');
  el.innerHTML = snapshots.map((snap, i) => `
    <div class="snapshot-item">
      <span class="snapshot-label">${snap.label}</span>
      <span class="snapshot-te">${snap.te} TE</span>
      <button class="snapshot-btn-load" onclick="loadSnapshot(${i})">load</button>
      <button class="snapshot-btn-load" onclick="deleteSnapshot(${i})" style="color:var(--red)">×</button>
    </div>
  `).join('');
}

async function loadSnapshot(i) {
  state = JSON.parse(JSON.stringify(snapshots[i].state));
  const stats = await apiFetch('/api/stats', 'POST', { state });
  renderAll(stats);
  await refreshUpgrades();
  showToast(`Loaded ${snapshots[i].label}`);
}

function deleteSnapshot(i) {
  snapshots.splice(i, 1);
  renderSnapshots();
}

// ─── Replay ────────────────────────────────────────────────

async function replayInput() {
  const raw = document.getElementById('custom-input').value.trim();
  if (!raw) return;
  const lines = raw.split('\n').filter(l => l.trim() && !l.trim().startsWith('#'));
  for (const line of lines) {
    const parts = line.trim().split(/\s+/);
    const cmd = parts[0];
    const arg = parts.slice(1).join(' ');
    try {
      if (cmd === 'shift') await apiAction('/api/action/shift', { egg: arg });
      else if (cmd === 'wait') await apiAction('/api/action/wait', { mode: 'offline', wait_type: 'time', value: arg });
      else if (cmd === 'waitactive') await apiAction('/api/action/wait', { mode: 'active', wait_type: 'time', value: arg });
      else if (['curiosity','kindness','resilience','humility','integrity'].includes(cmd)) {
        await apiAction('/api/action/simulate_egg', { egg: cmd, mode: 'time', value: arg });
      } else if (cmd === 'buyall') await apiAction('/api/action/buy_all', { type: arg || 'cr' });
      else if (cmd === 'prestige') await apiAction('/api/action/prestige', { pending_te: 0 });
    } catch(e) { console.warn('Replay error:', e); }
  }
  showToast('Replay complete');
}

// ─── Helpers ───────────────────────────────────────────────

function lockedMsg(egg) {
  return `<div class="tab-locked-msg">
    🔒 This tab is only available on the <strong>${egg}</strong> egg.<br>
    <span style="font-size:11px;color:var(--text-subtle)">Use the Shift buttons to change eggs.</span>
  </div>`;
}

function parseCashVal(v) { return typeof v === 'number' ? v : 0; }

function parseEggNum(s) {
  if (!s || s === '0') return 0;
  s = s.toString().trim();
  const units = {'K':1e3,'M':1e6,'B':1e9,'T':1e12,'q':1e15,'Q':1e18,'s':1e21,'S':1e24,
    'o':1e27,'N':1e30,'d':1e33,'U':1e36,'D':1e39};
  const match = s.match(/^([0-9]*\.?[0-9]+)([A-Za-z]*)$/);
  if (!match) return parseFloat(s) || 0;
  return parseFloat(match[1]) * (units[match[2]] || 1);
}

function formatNum(n) {
  if (!n && n !== 0) return '0';
  n = parseFloat(n);
  if (n === 0) return '0';
  const units = ['','K','M','B','T','q','Q','s','S','o','N','d','U','D'];
  const k = Math.max(0, Math.min(Math.floor(Math.log10(Math.abs(n)) / 3), units.length - 1));
  const m = n / Math.pow(10, 3*k);
  return `${m >= 100 ? Math.round(m) : m >= 10 ? m.toFixed(1) : m.toFixed(2)}${units[k]}`;
}

function teNumbers(eggs) {
  if (!eggs || eggs <= 0) return 0;
  const thresholds = [0, 50e6, 1e9, 10e9, 70e9, 500e9, 2e13, 7e12, 20e12, 60e12, 150e12, 500e12, 1.5e15, 4e15, 10e15, 25e15, 50e15, 100e15];
  let i = 0;
  while (i < 18) { if (thresholds[i] > eggs) return i - 1; i++; }
  const a = 0.5, b = 12.5, c = 68 - (eggs - 1e17) / 1e16;
  const d = b*b - 4*a*c;
  if (d < 0) return 17;
  return Math.floor((-b + Math.sqrt(d)) / (2*a)) - 1;
}

function escapeHtml(s) {
  return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}

// ─── Toast ─────────────────────────────────────────────────

let toastTimer = null;
function showToast(msg, error = false) {
  const el = document.getElementById('toast');
  el.textContent = msg;
  el.className = `toast show ${error ? 'error' : ''}`;
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => el.className = 'toast', 2800);
}

// ─── Boot ──────────────────────────────────────────────────
window.addEventListener('DOMContentLoaded', init);
