from farm.farm import Farm
from simulation.egg_simulation import *
import re
from simulation.commands import virtue_egg_index
from itertools import product

egg = {
    "c": curiosity,
    "i": integrity,
    "k": kindness,
    "r": resilience,
    "h": humility
    }

egg_index = {
    "c": 0,
    "i": 1,
    "k": 2,
    "r": 3,
    "h": 4
    }

def simulate_asc(order, times, eggs_layed=[0,0,0,0,0]):
    assert(bool(re.fullmatch(r"[cikrh]+", order)))
    te_owned = 0
    for i in range(5):
        te_owned += te_numbers(eggs_layed[i])
    f = Farm(egg=egg[order[0]].__name__, 
                te=te_owned, 
                #artifact_set=Artifact_set(),
                video_doubler=True)
    state = State(f, time_elapsed=0, eggs_layed=eggs_layed, shifts=0)

    for k in range(len(order)):
        egg[order[k]](state, times[k])
    virtue(state)
    with open("analyzer/analyzed.txt", "a") as fi:
        fi.write(f"{order} {times}\n")
        fi.write(f"{format_time(state.time_elapsed)}\n\n")


def test_times(order, te_goal, eggs_layed=[0,0,0,0,0]):
    assert(bool(re.fullmatch(r"[cikrh]+", order)))
    prog = np.ones(len(order))
    te_claimed = [0,0,0,0,0]
    for i in range(5):
        te_claimed[i] = te_numbers(eggs_layed[i])

    n = 5 # must be below 5*te
    for values in product(range(1, n), repeat=len(order)):
        times = []
        te_pending=0
        for i in range(len(values)):
            if order[i] in order[i+1:]:
                times.append(f"{values[i]}h")
            else:
                times.append(f"{values[i]+te_claimed[egg_index[order[i]]]}te")
                te_pending += int(te_goal/values[i])
        
        if te_pending == te_goal:
            simulate_asc(order, times, eggs_layed)
            print("Hi")
        print(f"{te_pending}")

