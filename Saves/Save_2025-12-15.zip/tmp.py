    if cash_to_go <= 0:
        return 0.0

    # helper: compute income generated in `duration` seconds using the same logic as wait_active
    def income_for_duration(farm_copy, duration):
        p = farm_copy.pop
        if p == 0:
            p = 0.001
        growth_rate = farm_copy.ihr/60 + farm_copy.manual_hatchery_rate
        # if no growth, approximate income as active bocks per second for the whole duration
        if growth_rate <= 0 or math.isnan(growth_rate):
            return farm_copy.bocks_per_second_active * duration

        pop_growth = growth_rate * duration
        time_habblocked = (farm_copy.hab_size - p)/growth_rate
        time_shipblocked = (farm_copy.shipping_rate - farm_copy.laying_per_chick*p)/growth_rate

        effective_rcb = min(farm_copy.max_rcb, farm_copy.manual_hatchery_rate * farm_copy.rcb_per_chicken)

        # helper to safely compute no-block income and bocks income
        if time_habblocked > duration and time_shipblocked > duration:
            gifts = farm_copy.no_block_integral(p, p + pop_growth) * farm_copy.gifts_and_drones_multiplier * duration
            bocks = farm_copy.bocks_per_second * effective_rcb * (1 + pop_growth/(2*p)) * duration
            return gifts + bocks

        if time_habblocked > duration and time_shipblocked <= duration:
            # from 0..time_shipblocked: no-block
            gifts = farm_copy.no_block_integral(p, p + time_shipblocked*growth_rate) * farm_copy.gifts_and_drones_multiplier * time_shipblocked
            # from time_shipblocked..duration: shipblocked
            gifts += farm_copy.shipblocked_integral(p + time_shipblocked*growth_rate, p + (duration-time_shipblocked)*growth_rate) * farm_copy.gifts_and_drones_multiplier * (duration-time_shipblocked)
            # bocks income: two parts (before and after shipblock)
            bocks_before = farm_copy.bocks_per_second * effective_rcb * (1 + time_shipblocked*growth_rate/(2*p)) * time_shipblocked
            bocks_after = farm_copy.bocks_per_second * effective_rcb / p * (time_shipblocked*growth_rate) * (duration - time_shipblocked)
            return gifts + bocks_before + bocks_after

        if time_habblocked <= duration and time_shipblocked > time_habblocked:
            # from 0..time_habblocked: no-block
            gifts = farm_copy.no_block_integral(p, p + time_habblocked*growth_rate) * farm_copy.gifts_and_drones_multiplier * time_habblocked
            bocks = farm_copy.bocks_per_second * effective_rcb * (1 + time_habblocked*growth_rate/(2*p)) * time_habblocked
            # after hab blocked, farm at max pop: active bocks
            gifts += 0
            bocks += farm_copy.bocks_per_second_active * (duration - time_habblocked)
            return gifts + bocks

        # time_habblocked <= duration and time_shipblocked <= time_habblocked
        # 0..time_shipblocked: no-block
        gifts = farm_copy.no_block_integral(p, p + time_shipblocked*growth_rate) * farm_copy.gifts_and_drones_multiplier * time_shipblocked
        # time_shipblocked..time_habblocked: shipblocked
        gifts += farm_copy.shipblocked_integral(p + time_shipblocked*growth_rate, p + time_habblocked*growth_rate) * farm_copy.gifts_and_drones_multiplier * (time_habblocked-time_shipblocked)
        # bocks income pieces
        bocks_1 = farm_copy.bocks_per_second * effective_rcb * (1 + time_shipblocked*growth_rate/(2*p)) * time_shipblocked
        bocks_2 = farm_copy.bocks_per_second * effective_rcb / p * (time_shipblocked*growth_rate) * (time_habblocked - time_shipblocked)
        bocks_3 = farm_copy.bocks_per_second_active * (duration - time_habblocked)
        return gifts + bocks_1 + bocks_2 + bocks_3

    import math

    # find an upper bound for duration by doubling until income >= cash_to_go
    low = 0.0
    # start with a conservative lower-rate (active only)
    min_rate = max(1e-12, f.bocks_per_second_active)
    high = max(1.0, cash_to_go / min_rate)
    # double until we bracket or we hit a huge limit
    max_high = 1e14
    while income_for_duration(f, high) < cash_to_go and high < max_high:
        high *= 2

    # binary search for duration where income(duration) ~= cash_to_go
    for _ in range(80):
        mid = (low + high) / 2
        inc = income_for_duration(f, mid)
        if inc >= cash_to_go:
            high = mid
        else:
            low = mid

    return high