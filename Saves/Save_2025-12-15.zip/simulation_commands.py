from farm import *
import re
import os, sys
from methods import *
from prices import *
import copy

virtue_egg_index = {
    "curiosity": 0,
    "kindness": 1,
    "resilience": 2,
    "humility": 3,
    "integrity": 4
}

class State:
    def __init__(self, farm, time_elapsed, eggs_layed, te_claimed, shifts):
        self.farm = farm
        self.time_elapsed = time_elapsed
        self.eggs_layed = eggs_layed
        self.te_claimed = te_claimed
        self.shifts = shifts

def te_treshholds(n):
    treshholds = [0, 50e6, 1e9, 10e9, 70e9, 500e9, 2e13, 7e12, 20e12, 60e12, 150e12, 500e12, 1.5e15, 4e15, 10e15, 25e15, 50e15, 100e15]
    if n<17:
        return treshholds[n]
    return 1e17 + (n-17)*1e16*(n/2 - 4)

def te_numbers(eggs_layed):
    i=0
    while True:
        if te_treshholds(i)>eggs_layed:
            return i-1
        i+=1


def set_egg():
    os.system('clear')
    print("-----------------------------------------")
    print("| GnuWithFlu's Path of Virtue simulator |")
    print("-----------------------------------------")
    print()
    print("\033[34mWhich egg do you start on?\033[0m curiosity, kindness, resilience, humility or integrity?")

    while True:
        s = input()
        if (s=="curiosity" or s=="kindness" or s=="resilience" or s=="humility" or s=="integrity"): return s
        sys.stdout.write("\033[1A\r\033[K")

def set_te():
    os.system('clear')
    print("-----------------------------------------")
    print("| GnuWithFlu's Path of Virtue simulator |")
    print("-----------------------------------------")
    print()
    print("\033[34mHow many TE do you have?\033[0m")
    while True:
        s = input()
        sys.stdout.write("\033[1A\r\033[K")
        try:
            if int(s)<0:
                continue
            return int(s)
        except ValueError:
            continue

def claim_te(state):
    for i in range(5):
        state.te_claimed[i] = te_numbers(state.eggs_layed[i])

def set_eggs_layed():
    os.system('clear')
    print("-----------------------------------------")
    print("| GnuWithFlu's Path of Virtue simulator |")
    print("-----------------------------------------")
    print()
    print("\033[34mHow many eggs have you already layed on each farm?\033[0m")
    print("Please enter 5 numbers separated by spaces for CKRHM, e.g. \"14M 27B 13.2T 150M 0\"")
    while True:
        s = input()
        sys.stdout.write("\033[1A\r\033[K")

        try:
            parts = re.split(" ", s)
            if len(parts)!=5: continue
            return [eggRead(parts[0]), eggRead(parts[1]), eggRead(parts[2]), eggRead(parts[3]), eggRead(parts[4])]
        except ValueError:
            continue

def help():
    print(f"\033[34mYou can enter the following commands:\033[0m")
    print(f"\033[32mhelp\033[0m: Show this list of commands")
    print(f"\033[32mprogress\033[0m: Show eggs shipped and TE claimed")
    print(f"\033[32mcr/hab/veh/silo\033[0m: Show respective status")
    print(f"\033[32mrun <number>\033[0m: Increases your population as if you ran chickens")
    print(f"\033[32mwait <duration>\033[0m: Cash and chickens increase as if you closed the game")
    print(f"\033[32mwait <cash>\033[0m: Wait until you have a certain amount of cash")
    print(f"\033[32mwaitonline <duration>\033[0m: Cash and chickens increase as if you were online, running chickens, catching drones and gifts")
    print(f"\033[32mbuy <something>\033[0m: Buy cr, hab, veh or silo")
    print(f"\033[32mshift <egg>\033[0m: Shift to another egg")
    print(f"\033[32mleave <something>\033[0m: Leave the simulation")
    print()


def research_available(state, cr_index):
    if state.farm.crs[cr_index] == state.farm.max_crs[cr_index]:
        return False
    research_count = 0
    for i in range(len(state.farm.crs)):
        research_count += state.farm.crs[i]
    if cr_bounds[cr_names[cr_index][0]-1] > research_count:
        return False
    return True

def index(state):
    os.system('clear')
    print("-----------------------------------------")
    print("| GnuWithFlu's Path of Virtue simulator |")
    print("-----------------------------------------")
    print()
    print(f"\033[34m{state.farm.egg} egg farm\033[0m") 
    print(f"Time elapsed: \033[32m{format_time(state.time_elapsed)}\033[0m")
    print(f"Population: \033[32m{format(int(state.farm.pop))}/{format(int(state.farm.hab_size))}\033[0m | Shipping: \033[32m{format(state.farm.laying_per_chick*state.farm.pop)}/{format(state.farm.shipping_rate)}\033[0m")
    print(f"Cash: \033[32m{format(state.farm.cash)}\033[0m | Active: \033[32m{format(state.farm.bocks_per_second_active)}/sec\033[0m | Offline: \033[32m{format(state.farm.bocks_per_second_away)}/sec\033[0m")
    print()

def update_index(state, lines):
    sys.stdout.write('\033[H')  # Move cursor to home (line 1, col 1)
    sys.stdout.flush()
    index(state)

def status(state):
    print(f"\033[34m----- Status -----\033[0m")
    print(f"Farm Value: \033[32m{format(state.farm.farm_value)}\033[0m")
    print(f"Egg Value: \033[32m{format(state.farm.egg_value)}\033[0m")
    print(f"IHR: \033[32m{format(state.farm.ihr)}\033[0m")
    print(f"Elite Drone Value: \033[32m{format(state.farm.elite_drone_value)}\033[0m")
    print()
"""
def wait_online(state, duration):
    population = state.farm.pop
    population_growth = state.farm.ihr * duration/60

    if population_growth == 0: 
        state.farm.cash += state.farm.bocks_per_second * duration
        print(f"cash increased from {format(state.farm.cash - state.farm.bocks_per_second * duration)} to {format(state.farm.cash)}")
        print()
        return
    if population_growth + population <= state.farm.hab_size:
        state.farm.pop += population_growth
    else: state.farm.pop = state.farm.hab_size
    print(f"population increased from {format(population)} to {format(state.farm.pop)}")
    
    cash=state.farm.cash

    if state.farm.laying_per_chick*state.farm.pop < state.farm.shipping_rate:
        growth_time = (state.farm.hab_size - population)/(state.farm.ihr/60)
        mean_population = (state.farm.hab_size -population)/2
    else:
        growth_time = (state.farm.shipping_rate - state.farm.laying_per_chick*population)/(state.farm.ihr/60)
        mean_population = (state.farm.shipping_rate/state.farm.laying_per_chick - population)/2
    
    state.farm.cash += state.farm.bocks_per_second_pop(mean_population) * growth_time
    state.farm.cash += state.farm.bocks_per_second * (duration-growth_time)
    state.eggs_layed[virtue_egg_index[state.farm.egg]] += growth_time * state.farm.laying_per_chick * mean_population
    state.eggs_layed[virtue_egg_index[state.farm.egg]] += (duration-growth_time) * state.farm.shipping_rate
    print(f"cash increased from {format(cash)} to {format(state.farm.cash)}")
    print()

def wait_offline(state, duration):
    population = state.farm.pop
    population_growth = state.farm.ihr_away * duration/60

    if population_growth == 0:
        state.farm.cash += state.farm.bocks_per_second_away * duration
        print(f"cash increased from {format(state.farm.cash - state.farm.bocks_per_second_away * duration)} to {format(state.farm.cash)}")
        print()
        return
    if population_growth + population <= state.farm.hab_size:
        state.farm.pop += population_growth
    else: state.farm.pop = state.farm.hab_size
    print(f"population increased from {format(population)} to {format(state.farm.pop)}")   
    
    cash=state.farm.cash

    if state.farm.laying_per_chick*state.farm.pop < state.farm.shipping_rate:
        growth_time = (state.farm.hab_size - population)/(state.farm.ihr/60)
        mean_population = (state.farm.hab_size -population)/2
    else:
        growth_time = (state.farm.shipping_rate - state.farm.laying_per_chick*population)/(state.farm.ihr/60)
        mean_population = (state.farm.shipping_rate/state.farm.laying_per_chick - population)/2
   
    state.farm.cash += state.farm.bocks_per_second_pop_away(mean_population) * growth_time
    state.farm.cash += state.farm.bocks_per_second_away * (duration-growth_time)
    state.eggs_layed[virtue_egg_index[state.farm.egg]] += growth_time * state.farm.laying_per_chick * mean_population
    state.eggs_layed[virtue_egg_index[state.farm.egg]] += (duration-growth_time) * state.farm.shipping_rate
    print(f"cash increased from {format(cash)} to {format(state.farm.cash)}")
    print()
"""

def wait_offline(state, duration):
    if duration<0:
        print(f"Duration must be positive")
        return

    state.time_elapsed += duration
    population = state.farm.pop
    cash = state.farm.cash

    if population == 0: population += 0.001

    population_growth = (state.farm.ihr_away/60) * duration
    growth_rate = state.farm.ihr_away/60

    if population == state.farm.hab_size:
        state.farm.cash += state.farm.bocks_per_second_away * duration
        state.eggs_layed[virtue_egg_index[state.farm.egg]] += min(state.farm.shipping_rate, state.farm.laying_per_chick*population) * duration
        index(state)
        print(f"cash increased from {format(cash)} to {format(state.farm.cash)}")
        return

    time_habblocked = (state.farm.hab_size - population)/growth_rate
    time_shipblocked = (state.farm.shipping_rate - state.farm.laying_per_chick*population)/growth_rate
    
    if time_habblocked > duration and time_shipblocked > duration:
        state.farm.cash += state.farm.no_block_integral(population, population + population_growth) * state.farm.gifts_and_drones_multiplier * duration
        state.farm.cash += state.farm.bocks_per_second_away * (1 + population_growth/(2*population)) * duration
        state.farm.pop += population_growth
        state.eggs_layed[virtue_egg_index[state.farm.egg]] += state.farm.laying_per_chick*(2*population+population_growth)/2 * duration
        index(state)
        print(f"cash increased from {format(cash)} to {format(state.farm.cash)}")
        return

    if time_habblocked > duration and time_shipblocked < duration:
        state.farm.cash += state.farm.no_block_integral(population, population + time_shipblocked*growth_rate) * state.farm.gifts_and_drones_multiplier * time_shipblocked
        state.farm.cash += state.farm.shipblocked_integral(population + time_shipblocked*growth_rate, population + (duration-time_shipblocked)*growth_rate) * state.farm.gifts_and_drones_multiplier * (duration-time_shipblocked)
        state.farm.cash += state.farm.bocks_per_second_away * (1 + time_shipblocked*growth_rate/(2*population))
        state.farm.cash += state.farm.bocks_per_second_away / population * time_shipblocked*growth_rate * (duration - time_shipblocked)
        state.farm.pop += population_growth
        
        state.eggs_layed[virtue_egg_index[state.farm.egg]] += state.farm.laying_per_chick*(2*population+growth_rate*time_shipblocked)/2 * time_shipblocked
        state.eggs_layed[virtue_egg_index[state.farm.egg]] += state.farm.shipping_rate * (duration - time_shipblocked)
        index(state)
        print(f"cash increased from {format(cash)} to {format(state.farm.cash)}")
        return

    if time_habblocked < duration and time_shipblocked > time_habblocked:
        state.farm.cash += state.farm.no_block_integral(population, population + time_habblocked*growth_rate) * state.farm.gifts_and_drones_multiplier * time_habblocked
        state.farm.cash += state.farm.bocks_per_second_away * (1 + time_habblocked*growth_rate/(2*population))
        state.farm.pop = state.farm.hab_size
        state.farm.cash += state.farm.bocks_per_second_away * (duration - time_habblocked)
        
        state.eggs_layed[virtue_egg_index[state.farm.egg]] += state.farm.laying_per_chick*(2*population+growth_rate*time_habblocked)/2 * time_habblocked
        state.eggs_layed[virtue_egg_index[state.farm.egg]] += state.farm.laying_per_chick* state.farm.hab_size * (duration - time_habblocked)        
        index(state)
        print(f"cash increased from {format(cash)} to {format(state.farm.cash)}")
        return

    if time_habblocked < duration and time_shipblocked < time_habblocked:
        state.farm.cash += state.farm.no_block_integral(population, population + time_shipblocked*growth_rate) * state.farm.gifts_and_drones_multiplier * time_shipblocked
        state.farm.cash += state.farm.shipblocked_integral(population + time_shipblocked*growth_rate, population + time_habblocked*growth_rate) * state.farm.gifts_and_drones_multiplier * (time_habblocked-time_shipblocked)
        state.farm.cash += state.farm.bocks_per_second_away * (1 + time_shipblocked*growth_rate/(2*population))
        state.farm.cash += state.farm.bocks_per_second_away / population * time_shipblocked*growth_rate * (time_habblocked - time_shipblocked)
        state.farm.pop = state.farm.hab_size
        state.farm.cash += state.farm.bocks_per_second_away * (duration - time_habblocked)
        
        state.eggs_layed[virtue_egg_index[state.farm.egg]] += state.farm.laying_per_chick*(2*population+growth_rate*time_shipblocked)/2 * time_shipblocked
        state.eggs_layed[virtue_egg_index[state.farm.egg]] += state.farm.laying_per_chick*(2*population+growth_rate*time_shipblocked+growth_rate*time_habblocked)/2 * (time_habblocked-time_shipblocked)
        state.eggs_layed[virtue_egg_index[state.farm.egg]] += state.farm.laying_per_chick* state.farm.hab_size * (duration - time_habblocked -time_shipblocked)                
        index(state)
        print(f"cash increased from {format(cash)} to {format(state.farm.cash)}")
        return 


def wait_offline_cash(f, duration):
    if f.bocks_per_second_away == 0:
        print(f"No offline earnings")
        return -1

    if duration<0:
        return 0
    population = f.pop
    cash = f.cash

    if population == 0: population += 0.001

    population_growth = (f.ihr_away/60) * duration
    growth_rate = f.ihr_away/60

    if population == f.hab_size:
        f.cash += f.bocks_per_second_away * duration
        return f.cash

    time_habblocked = (f.hab_size - population)/growth_rate
    time_shipblocked = (f.shipping_rate - f.laying_per_chick*population)/growth_rate
    
    if time_habblocked > duration and time_shipblocked > duration:
        f.cash += f.no_block_integral(population, population + population_growth) * f.gifts_and_drones_multiplier * duration
        f.cash += f.bocks_per_second_away * (1 + population_growth/(2*population)) * duration
        return f.cash

    if time_habblocked > duration and time_shipblocked < duration:
        f.cash += f.no_block_integral(population, population + time_shipblocked*growth_rate) * f.gifts_and_drones_multiplier * time_shipblocked
        f.cash += f.shipblocked_integral(population + time_shipblocked*growth_rate, population + (duration-time_shipblocked)*growth_rate) * f.gifts_and_drones_multiplier * (duration-time_shipblocked)
        f.cash += f.bocks_per_second_away * (1 + time_shipblocked*growth_rate/(2*population))
        f.cash += f.bocks_per_second_away / population * time_shipblocked*growth_rate * (duration - time_shipblocked)
        return f.cash

    if time_habblocked < duration and time_shipblocked > time_habblocked:
        f.cash += f.no_block_integral(population, population + time_habblocked*growth_rate) * f.gifts_and_drones_multiplier * time_habblocked
        f.cash += f.bocks_per_second_away*(1 + time_habblocked*growth_rate/(2*population))
        f.pop = f.hab_size
        f.cash += f.bocks_per_second_away * (duration - time_habblocked)
        return f.cash

    if time_habblocked < duration and time_shipblocked < time_habblocked:
        f.cash += f.no_block_integral(population, population + time_shipblocked*growth_rate) * f.gifts_and_drones_multiplier * time_shipblocked
        f.cash += f.shipblocked_integral(population + time_shipblocked*growth_rate, population + time_habblocked*growth_rate) * f.gifts_and_drones_multiplier * (time_habblocked-time_shipblocked)
        f.cash += f.bocks_per_second_away * (1 + time_shipblocked*growth_rate/(2*population))
        f.cash += f.bocks_per_second_away / population * time_shipblocked*growth_rate * (time_habblocked - time_shipblocked)
        f.pop = f.hab_size
        f.cash += f.bocks_per_second_away * (duration - time_habblocked)
        return f.cash


def time_away(state, cash):
    if state.farm.pop == state.farm.hab_size:
        return cash/state.farm.bocks_per_second_away

    f = copy.deepcopy(state.farm)
    f.pop += 1
    cash_to_go = cash
    print(format(cash_to_go))


    t_low = 0.0
    t_high = cash_to_go/f.bocks_per_second_away

    # binary search for duration where income(duration) ~= cash_to_go
    for _ in range(80):
        t_mid = (t_low + t_high) / 2
        inc = wait_offline_cash(f, t_mid)
        print(f"Income {inc} for Time {t_mid}")
        if inc >= cash_to_go:
            t_high = t_mid
        else:
            t_low = t_mid
        print(f"{format_time(t_high)} {format_time(t_low)}")
    return t_high


def wait_active(state, duration):
    if duration<0:
        print(f"Duration must be positive")
        return

    state.time_elapsed += duration
    population = state.farm.pop
    cash = state.farm.cash
    effective_rcb = min(state.farm.max_rcb,state.farm.manual_hatchery_rate*state.farm.rcb_per_chicken)

    if population == 0: population += 0.001
    population_growth = (state.farm.ihr/60 + state.farm.manual_hatchery_rate) * duration
    growth_rate = state.farm.ihr/60 + state.farm.manual_hatchery_rate

    if population == state.farm.hab_size:
        state.farm.cash += state.farm.bocks_per_second_active * duration
        state.eggs_layed[virtue_egg_index[state.farm.egg]] += min(state.farm.shipping_rate, state.farm.laying_per_chick*population) * duration
        index(state)
        print(f"cash increased from {format(cash)} to {format(state.farm.cash)}")
        return

    time_habblocked = (state.farm.hab_size - population)/growth_rate
    time_shipblocked = (state.farm.shipping_rate - state.farm.laying_per_chick*population)/growth_rate
    
    if time_habblocked > duration and time_shipblocked > duration:
        state.farm.cash += state.farm.no_block_integral(population, population + population_growth) * state.farm.gifts_and_drones_multiplier * duration
        state.farm.cash += state.farm.bocks_per_second*effective_rcb * (1 + population_growth/(2*population)) * duration
        state.farm.pop += population_growth
        state.eggs_layed[virtue_egg_index[state.farm.egg]] += state.farm.laying_per_chick*(2*population+population_growth)/2 * duration
        index(state)
        print(f"cash increased from {format(cash)} to {format(state.farm.cash)}")
        return

    if time_habblocked > duration and time_shipblocked < duration:
        state.farm.cash += state.farm.no_block_integral(population, population + time_shipblocked*growth_rate) * state.farm.gifts_and_drones_multiplier * time_shipblocked
        state.farm.cash += state.farm.shipblocked_integral(population + time_shipblocked*growth_rate, population + (duration-time_shipblocked)*growth_rate) * state.farm.gifts_and_drones_multiplier * (duration-time_shipblocked)
        state.farm.cash += state.farm.bocks_per_second*effective_rcb * (1 + time_shipblocked*growth_rate/(2*population))
        state.farm.cash += state.farm.bocks_per_second*effective_rcb / population * time_shipblocked*growth_rate * (duration - time_shipblocked)
        state.farm.pop += population_growth
        
        state.eggs_layed[virtue_egg_index[state.farm.egg]] += state.farm.laying_per_chick*(2*population+growth_rate*time_shipblocked)/2 * time_shipblocked
        state.eggs_layed[virtue_egg_index[state.farm.egg]] += state.farm.shipping_rate * (duration - time_shipblocked)
        index(state)
        print(f"cash increased from {format(cash)} to {format(state.farm.cash)}")
        return

    if time_habblocked < duration and time_shipblocked > time_habblocked:
        state.farm.cash += state.farm.no_block_integral(population, population + time_habblocked*growth_rate) * state.farm.gifts_and_drones_multiplier * time_habblocked
        state.farm.cash += state.farm.bocks_per_second*effective_rcb * (1 + time_habblocked*growth_rate/(2*population))
        state.farm.pop = state.farm.hab_size
        state.farm.cash += state.farm.bocks_per_second_active * (duration - time_habblocked)
        
        state.eggs_layed[virtue_egg_index[state.farm.egg]] += state.farm.laying_per_chick*(2*population+growth_rate*time_habblocked)/2 * time_habblocked
        state.eggs_layed[virtue_egg_index[state.farm.egg]] += state.farm.laying_per_chick* state.farm.hab_size * (duration - time_habblocked)        
        index(state)
        print(f"cash increased from {format(cash)} to {format(state.farm.cash)}")
        return

    if time_habblocked < duration and time_shipblocked < time_habblocked:
        state.farm.cash += state.farm.no_block_integral(population, population + time_shipblocked*growth_rate) * state.farm.gifts_and_drones_multiplier * time_shipblocked
        state.farm.cash += state.farm.shipblocked_integral(population + time_shipblocked*growth_rate, population + time_habblocked*growth_rate) * state.farm.gifts_and_drones_multiplier * (time_habblocked-time_shipblocked)
        state.farm.cash += state.farm.bocks_per_second*effective_rcb * (1 + time_shipblocked*growth_rate/(2*population))
        state.farm.cash += state.farm.bocks_per_second*effective_rcb / population * time_shipblocked*growth_rate * (time_habblocked - time_shipblocked)
        state.farm.pop = state.farm.hab_size
        state.farm.cash += state.farm.bocks_per_second_active * (duration - time_habblocked)
        
        state.eggs_layed[virtue_egg_index[state.farm.egg]] += state.farm.laying_per_chick*(2*population+growth_rate*time_shipblocked)/2 * time_shipblocked
        state.eggs_layed[virtue_egg_index[state.farm.egg]] += state.farm.laying_per_chick*(2*population+growth_rate*time_shipblocked+growth_rate*time_habblocked)/2 * (time_habblocked-time_shipblocked)
        state.eggs_layed[virtue_egg_index[state.farm.egg]] += state.farm.laying_per_chick* state.farm.hab_size * (duration - time_habblocked -time_shipblocked)                
        index(state)
        print(f"cash increased from {format(cash)} to {format(state.farm.cash)}")
        return 

def wait_active_cash(f, duration):
    if duration<0:
        return 0
    population = f.pop
    cash = f.cash
    effective_rcb = min(f.max_rcb,f.manual_hatchery_rate*f.rcb_per_chicken)
    if population == 0: population += 0.001
    population_growth = (f.ihr/60 + f.manual_hatchery_rate) * duration
    growth_rate = f.ihr/60 + f.manual_hatchery_rate
    if population == f.hab_size:
        f.cash += f.bocks_per_second_active * duration
        return f.cash
    time_habblocked = (f.hab_size - population)/growth_rate
    time_shipblocked = (f.shipping_rate - f.laying_per_chick*population)/growth_rate
    
    if time_habblocked > duration and time_shipblocked > duration:
        f.cash += f.no_block_integral(population, population + population_growth) * f.gifts_and_drones_multiplier * duration
        f.cash += f.bocks_per_second*effective_rcb * (1 + population_growth/(2*population)) * duration
        return f.cash
    
    if time_habblocked > duration and time_shipblocked < duration:
        f.cash += f.no_block_integral(population, population + time_shipblocked*growth_rate) * f.gifts_and_drones_multiplier * time_shipblocked
        f.cash += f.shipblocked_integral(population + time_shipblocked*growth_rate, population + (duration-time_shipblocked)*growth_rate) * f.gifts_and_drones_multiplier * (duration-time_shipblocked)
        f.cash += f.bocks_per_second*effective_rcb * (1 + time_shipblocked*growth_rate/(2*population))
        f.cash += f.bocks_per_second*effective_rcb / population * time_shipblocked*growth_rate * (duration - time_shipblocked)
        return f.cash
    
    if time_habblocked < duration and time_shipblocked > time_habblocked:
        f.cash += f.no_block_integral(population, population + time_habblocked*growth_rate) * f.gifts_and_drones_multiplier * time_habblocked
        f.cash += f.bocks_per_second*effective_rcb * (1 + time_habblocked*growth_rate/(2*population))
        f.pop = f.hab_size
        f.cash += f.bocks_per_second_active * (duration - time_habblocked)
        return f.cash
    
    if time_habblocked < duration and time_shipblocked < time_habblocked:
        f.cash += f.no_block_integral(population, population + time_shipblocked*growth_rate) * f.gifts_and_drones_multiplier * time_shipblocked
        f.cash += f.shipblocked_integral(population + time_shipblocked*growth_rate, population + time_habblocked*growth_rate) * f.gifts_and_drones_multiplier * (time_habblocked-time_shipblocked)
        f.cash += f.bocks_per_second*effective_rcb * (1 + time_shipblocked*growth_rate/(2*population))
        f.cash += f.bocks_per_second*effective_rcb / population * time_shipblocked*growth_rate * (time_habblocked - time_shipblocked)
        f.pop = f.hab_size
        f.cash += f.bocks_per_second_active * (duration - time_habblocked)
        return f.cash


def time_active(state, cash):
    if state.farm.pop == state.farm.hab_size:
        return cash/state.farm.bocks_per_second_active

    f = copy.deepcopy(state.farm)
    f.pop += 1
    cash_to_go = cash
    print(format(cash_to_go))


    t_low = 0.0
    t_high = cash_to_go/f.bocks_per_second

    # binary search for duration where income(duration) ~= cash_to_go
    for _ in range(80):
        t_mid = (t_low + t_high) / 2
        inc = wait_active_cash(f, t_mid)
        print(f"Income {inc} for Time {t_mid}")
        if inc >= cash_to_go:
            t_high = t_mid
        else:
            t_low = t_mid
        print(f"{format_time(t_high)} {format_time(t_low)}")
    return t_high



"""
def time_active(state, cash):
    f = copy.deepcopy(state.farm)
    cash_to_go = cash
    if cash<0: return 0
    duration = cash_to_go / state.farm.bocks_per_second_active
    print(cash_to_go)
    population = state.farm.pop
    effective_rcb = min(state.farm.max_rcb,state.farm.manual_hatchery_rate*state.farm.rcb_per_chicken)
    
    if population == 0: population += 0.001
    population_growth = (f.ihr/60 + f.manual_hatchery_rate) * duration
    growth_rate = f.ihr/60 + f.manual_hatchery_rate

    if population == f.hab_size: # works
        return duration

    time_habblocked = (f.hab_size - population)/growth_rate
    time_shipblocked = (f.shipping_rate - f.laying_per_chick*population)/growth_rate
    
    if time_habblocked > duration and time_shipblocked > duration: # false but in ooM, always a bit too big
        return cash_to_go / (f.no_block_integral(population, population + population_growth) * f.gifts_and_drones_multiplier + f.bocks_per_second*effective_rcb * (1 + population_growth/(2*population)))


    if time_habblocked > duration and time_shipblocked < duration:
        cash_to_go -= f.no_block_integral(population, population + time_shipblocked*growth_rate) * f.gifts_and_drones_multiplier * time_shipblocked
        cash_to_go -= f.bocks_per_second*effective_rcb * (1 + time_shipblocked*growth_rate/(2*population))
        return cash_to_go / (f.shipblocked_integral(population + time_shipblocked*growth_rate, population + (time_habblocked-time_shipblocked)*growth_rate) * f.gifts_and_drones_multiplier + f.bocks_per_second*effective_rcb / population * time_shipblocked*growth_rate)


    if time_habblocked < duration and time_shipblocked > time_habblocked:
        cash_to_go -= f.no_block_integral(population, population + time_habblocked*growth_rate) * f.gifts_and_drones_multiplier * time_habblocked
        cash_to_go -= f.bocks_per_second*effective_rcb * (1 + time_habblocked*growth_rate/(2*population))
        f.pop = f.hab_size
        return cash_to_go / f.bocks_per_second_active 


    if time_habblocked < duration and time_shipblocked < time_habblocked:
        cash_to_go -= f.no_block_integral(population, population + time_shipblocked*growth_rate) * f.gifts_and_drones_multiplier * time_shipblocked
        cash_to_go -= f.shipblocked_integral(population + time_shipblocked*growth_rate, population + time_habblocked*growth_rate) * f.gifts_and_drones_multiplier * (time_habblocked-time_shipblocked)
        cash_to_go -= f.bocks_per_second*effective_rcb * (1 + time_shipblocked*growth_rate/(2*population))
        cash_to_go -= f.bocks_per_second*effective_rcb / population * time_shipblocked*growth_rate * (time_habblocked - time_shipblocked)
        f.pop = f.hab_size
        return cash_to_go / f.bocks_per_second_active
""" 

def run_chickens(state, number):
    population = state.farm.pop
    if number + population <= state.farm.hab_size:
        state.farm.pop += number
    else: state.farm.pop = state.farm.hab_size
    index(state)
    print(f"population increased from \033[32m{format(population)}\033[0m to \033[32m{format(state.farm.pop)}\033[0m")
    print()

def shift(state, new_egg):
    if new_egg not in virtue_egg_index or new_egg==state.farm.egg:
        print("Invalid egg")
        return
    state.farm.egg = new_egg
    state.farm.cash = 0
    state.farm.pop = 0
    state.shifts += 1
    index(state)
    print(f"Shifted to {new_egg} egg farm")
    print()
    


def silo_status(state):
    print(f"\033[34m----- Silos -----\033[0m")
    print(f"You own \033[32m{state.farm.silos}\033[0m silos")
    print(f"Max away time: \033[32m{state.farm.max_away_time/60}h\033[0m")

    if state.farm.silos == 10:
        print(f"Silos are maxed")
        print()

        return
    print(f"Upgrade cost: \033[32m{format(silo_price[state.farm.silos])}\033[0m")
    print()

def hab_status(state):
    print(f"\033[34m----- Habitats -----\033[0m")
    print(f"Habs: \033[32m{state.farm.habs[0]} {state.farm.habs[1]} {state.farm.habs[2]} {state.farm.habs[3]}\033[0m")
    print(f"Hab size: \033[32m{format(state.farm.hab_size)}\033[0m")

    for i in range (4):
        if state.farm.habs[i] == 19:
            print(f"Hab \033[32m{i}\033[0m is maxed")
        else: 
            same_habs = 0
            for j in range(4):
                if state.farm.habs[j] == state.farm.habs[i]+1: same_habs+=1
            print(f"Upgrade cost {i}: \033[32m{format(hab_prices[state.farm.habs[i]][same_habs] * (1-0.05*state.farm.ers[5]) * state.farm.coll_effects[4][int(state.farm.colleggtibles[4])])}\033[0m")
    print()

def vehicle_status(state):
    print(f"\033[34m----- Vehicles -----\033[0m")
    print(f"Vehicles:", end='')
    for i in range(state.farm.max_vehicle_number):
        print(f" \033[32m{int(state.farm.vehicles[i])}\033[0m", end='')
    print()
    print(f"Shipping capacity: \033[32m{format(state.farm.shipping_rate)}\033[0m")

    for i in range(state.farm.max_vehicle_number):
        if state.farm.vehicles[i] > 12 and state.farm.vehicles[i] < 18 + state.farm.crs[50] :
            print(f"Upgrade cost {i}: \033[32m{format(vehicle_prices[12][state.farm.vehicles[i]-12] * (1-0.05*state.farm.ers[6]) * state.farm.coll_effects[5][int(state.farm.colleggtibles[5])])}\033[0m")
        else: 
            same_vehicles = 0
            for j in range(state.farm.max_vehicle_number):
                if state.farm.vehicles[j] == state.farm.vehicles[i]+1: same_vehicles+=1
            print(f"Upgrade cost {i}: \033[32m{format(vehicle_prices[int(state.farm.vehicles[i])][same_vehicles] * (1-0.05*state.farm.ers[6]) * state.farm.coll_effects[5][int(state.farm.colleggtibles[5])])}\033[0m")
    print()

def cr_status(state):
    print(f"\033[34m----- Research -----\033[0m")
    for i in range(len(state.farm.crs)):
        if research_available(state=state, cr_index=i):
            print(f"{i} \033[31m{cr_names[i][1]}\033[0m ({cr_names[i][2]}) Level \033[32m{int(state.farm.crs[i])}/{state.farm.max_crs[i]}\033[0m costs \033[32m{format(cr_prices[i][int(state.farm.crs[i])] * state.farm.artifact_set.cr_cost * (1-0.05*state.farm.ers[7]) * state.farm.coll_effects[8][int(state.farm.colleggtibles[8])])}\033[0m" )
    research_count = 0
    for i in range(len(state.farm.crs)):
        research_count += state.farm.crs[i]
    for i in range(len(cr_bounds)-1):
        if cr_bounds[i] > research_count:
            print(f"Next tier unlocked in \033[32m{int(cr_bounds[i] - research_count)}\033[0m researches")
            print()
            return
    print()

def buy_silo(state):
    if state.farm.egg != "resilience":
        print(f"You cant buy silos from {state.farm.egg} egg farm!")
        return
    if state.farm.cash<silo_price[state.farm.silos]:
        print(f"Not enough cash!")
        return
    if state.farm.silos == 10:
        print(f"Already maxed silos!")
        return
    
    state.farm.cash -= silo_price[state.farm.silos]
    state.farm.silos += 1
    index(state)
    print(f"Now you own {state.farm.silos} silos!")
    print()


def buy_hab(state, hab, linebreak=True):
    if hab<0 or hab>3:
        print(f"Invalid hab: {hab}")
        return False
    if state.farm.egg != "integrity":
        print(f"You cant buy habs from {state.farm.egg} egg farm!")
        return False
    
    same_habs = 0
    for j in range(4):
        if state.farm.habs[j] == state.farm.habs[hab]+1: same_habs+=1
    upgrade_cost = hab_prices[state.farm.habs[hab]][same_habs] * (1-0.05*state.farm.ers[5]) * state.farm.coll_effects[4][int(state.farm.colleggtibles[4])]
 
    if state.farm.cash<upgrade_cost:
        print(f"Not enough cash!")
        return False
    
    if state.farm.habs[hab] == 19:
        print(f"Hab {hab} is maxed")
        return False
    
    state.farm.cash -= upgrade_cost
    state.farm.habs[hab] += 1
    index(state)
    print(f"Upgraded hab {hab} from {state.farm.habs[hab]-1} to {state.farm.habs[hab]}!")
    if linebreak: print()
    return True

def buy_hab_all(state):
    counter=0
    while True:
        counter+=1
        min_price = 1e34
        min_index = -1

        for i in range(len(state.farm.habs)):
            if state.farm.habs[i]<19:
                same_habs = 0
            for j in range(4):
                if state.farm.habs[j] == state.farm.habs[i]+1: same_habs+=1
                upgrade_cost = hab_prices[state.farm.habs[i]][same_habs] * (1-0.05*state.farm.ers[5]) * state.farm.coll_effects[4][int(state.farm.colleggtibles[4])]
                if upgrade_cost < min_price:
                    min_price = upgrade_cost
                    min_index = i

        if min_index==-1 or state.farm.cash<min_price: 
            if(counter==1):
                print("No hab bought :(")
            else:
                index(state)
                print(f"Bought {counter-1} habs!")
            print()
            break
        if not buy_hab(state, min_index, linebreak=False): break

def buy_vehicle(state, vehicle, linebreak=True):
    if vehicle<0 or vehicle>state.farm.max_vehicle_number:
        print(f"Invalid vehicle: {vehicle}")
        return False
    if state.farm.egg != "kindness":
        print(f"You cant buy vehicles from {state.farm.egg} egg farm!")
        return False

    if state.farm.vehicles[vehicle]>12:
        upgrade_cost = vehicle_prices[12][state.farm.vehicles[vehicle]] * (1-0.05*state.farm.ers[6]) * state.farm.coll_effects[5][int(state.farm.colleggtibles[5])]
    else:
        same_vehicles = 0
        for j in range(state.farm.max_vehicle_number):
            if state.farm.vehicles[j] == state.farm.vehicles[vehicle]+1: same_vehicles+=1
        upgrade_cost = vehicle_prices[int(state.farm.vehicles[vehicle])][same_vehicles] * (1-0.05*state.farm.ers[6]) * state.farm.coll_effects[5][int(state.farm.colleggtibles[5])]

    if state.farm.cash<upgrade_cost:
        print(f"Not enough cash!")
        return False
    
    if state.farm.vehicles[vehicle] == 17 + state.farm.crs[50]:
        print(f"Vehicle {vehicle} is maxed")
        return False
    
    state.farm.cash -= upgrade_cost
    state.farm.vehicles[vehicle] += 1
    index(state)
    print(f"Upgraded vehicle {vehicle} from {int(state.farm.vehicles[vehicle]-1)} to {int(state.farm.vehicles[vehicle])}!")
    if linebreak: print()
    return True

def buy_vehicle_all(state):
    counter=0
    while True:
        counter+=1
        min_price = 1e28
        min_index = -1

        for i in range(state.farm.max_vehicle_number):
            if state.farm.vehicles[i]<22:
                same_vehicles = 0
                for j in range(state.farm.max_vehicle_number):
                    if state.farm.vehicles[j] == state.farm.vehicles[i]+1:
                        same_vehicles += 1
                upgrade_cost = vehicle_prices[int(state.farm.vehicles[i])][same_vehicles] * (1-0.05*state.farm.ers[6]) * state.farm.coll_effects[5][int(state.farm.colleggtibles[5])]
                if upgrade_cost < min_price:
                    min_price = upgrade_cost
                    min_index = i

        if min_index==-1 or state.farm.cash<min_price: 
            if(counter==1):
                print("No vehicle bought :(")
            else:
                index(state)
                print(f"Bought {counter-1} vehicles!")
            print()
            break
        if not buy_vehicle(state, min_index, linebreak=False):
            break

def buy_cr(state, cr_index, printout=True):
    if state.farm.egg != "curiosity":
        print(f"You cant buy research from {state.farm.egg} egg farm!")
        return False
    if not research_available(state=state, cr_index=cr_index):
        print(f"Research not available")
        return False
    upgrade_cost = cr_prices[cr_index][int(state.farm.crs[cr_index])] * state.farm.artifact_set.cr_cost * (1-0.05*state.farm.ers[7]) * state.farm.coll_effects[8][int(state.farm.colleggtibles[8])]

    if state.farm.cash<upgrade_cost:
        print(f"Not enough cash!")
        return False
    
    state.farm.cash -= upgrade_cost
    state.farm.crs[cr_index] += 1
    index(state)
    if printout: print(f"Researched {cr_names[cr_index][1]} to level {int(state.farm.crs[cr_index])}/{state.farm.max_crs[cr_index]}!")
    if printout: print()
    return True

def buy_cr_all(state):
    counter=0
    while True:
        counter+=1
        min_price = 1e55
        min_index = -1
        for i in range(len(state.farm.crs)):
            if research_available(state=state, cr_index=i):
                upgrade_cost = cr_prices[i][int(state.farm.crs[i])] * state.farm.artifact_set.cr_cost * (1-0.05*state.farm.ers[7]) * state.farm.coll_effects[8][int(state.farm.colleggtibles[8])]
                if upgrade_cost < min_price:
                    min_price = upgrade_cost
                    min_index = i

        if min_index==-1 or state.farm.cash<min_price: 
            if(counter==1):
                print("No research bought :(")
            else:
                index(state)
                print(f"Bought {counter-1} researches!")
            print()
            break
        if not buy_cr(state, min_index, printout=False): break

def resilience(state, time=0):
    if state.farm.egg != "resilinence":
        shift(state, "resilience")
        
    time_zero = state.time_elapsed
    while state.time_elapsed-time_zero<time:
        print(f"{state.time_elapsed} + {time_active(state, silo_price[state.farm.silos]-state.farm.cash)} < {time} - {time_zero}")

        if state.time_elapsed - time_zero + time_active(state, silo_price[state.farm.silos]-state.farm.cash) < time:
            wait_active(state, time_active(state, silo_price[state.farm.silos]-state.farm.cash))
            buy_silo(state)
            print(f"{format(state.time_elapsed)} + {format(time_active(state, silo_price[state.farm.silos]-state.farm.cash))} < {format(time)} - {format(time_zero)}")
            continue

        #print(f"{state.time_elapsed} + {time_active(state, silo_price[state.farm.silos])} < {time} - {time_zero}")
        wait_active(state, time - state.time_elapsed + time_zero)
    
    return