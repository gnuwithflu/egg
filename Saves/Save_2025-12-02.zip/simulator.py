from farm import *
import re
from methods import *
from prices import *

virtue_egg_index = {
    "curiosity": 0,
    "kindness": 1,
    "resilience": 2,
    "humility": 3,
    "integrity": 4
}
class State:
    def __init__(self, farm, time_elapsed, eggs_laid, te_claimed, shifts):
        self.farm = farm
        self.time_elapsed = time_elapsed
        self.eggs_laid = eggs_laid
        self.te_claimed = te_claimed
        self.shifts = shifts

def te_treshholds(n):
    treshholds = [0, 50e6, 1e9, 10e9, 70e9, 500e9, 2e13, 7e12, 20e12, 60e12, 150e12, 500e12, 1.5e15, 4e15, 10e15, 25e15, 50e15, 100e15]
    if n<17:
        return treshholds[n]
    return 1e17 + (n-17)*1e16*(n/2 - 4)

def set_egg():
    print("Which egg do you start on?")
    s = input()
    if (s=="curiosity" or s=="kindness" or s=="resilience" or s=="humility" or s=="integrity"): return s
    if s=="help":
        print("Please enter the egg you are on: curiosity, kindness, resilience, humility or integrity")
        return set_egg()
    print("Error 404 Egg not found :/")
    return set_egg()

def set_te():
    print("How many Eggs of Truth do you have?")
    s = input()
    if s=="help":
        print("Input must be a number, like '123'")
        return set_te()
    try:
        if int(s)<0:
            print("TE number must be positive")
            return set_te() 
        return int(s)
    except ValueError:
        print("TE number must be an integer")
        return set_te()

def research_available(state, cr_index):
    if state.farm.crs[cr_index] == state.farm.max_crs[cr_index]:
        return False
    research_count = 0
    for i in range(len(state.farm.crs)):
        research_count += state.farm.crs[i]
    if cr_bounds[cr_names[cr_index][0]-1] > research_count:
        return False
    return True

def status(state):
    print(f"-----{state.farm.egg} egg farm-----")
    print(f"{state.farm.egg} eggs laid: {format(state.eggs_laid[virtue_egg_index[state.farm.egg]])}")
    print(f"Population: {format(state.farm.pop)}/{format(state.farm.hab_size)}")
    print(f"cash: {format(state.farm.cash)}")
    print(f"online earnings: {format(state.farm.bocks_per_second)}/sec")
    print(f"offline earnings: {format(state.farm.bocks_per_second_away)}/sec")
    print()

def wait_online(state, duration):
    state.farm.cash += state.farm.bocks_per_second * duration
    print(f"cash increased from {format(state.farm.cash-state.farm.bocks_per_second * duration)} to {format(state.farm.cash)}")

    population = state.farm.pop
    population_growth = state.farm.ihr * duration/60
    state.eggs_laid[virtue_egg_index[state.farm.egg]] += duration * state.farm.laying_per_chick * (population + 0.5*population_growth)

    if population_growth == 0: 
        print()
        return
    if population_growth + population <= state.farm.hab_size:
        state.farm.pop += population_growth
    else: state.farm.pop = state.farm.hab_size
    print(f"population increased from {format(population)} to {format(state.farm.pop)}")
    print()

def wait_offline(state, duration):
    state.farm.cash += state.farm.bocks_per_second_away * duration
    print(f"cash increased from {format(state.farm.cash-state.farm.bocks_per_second_away * duration)} to {format(state.farm.cash)}")

    population = state.farm.pop
    population_growth = state.farm.ihr_away * duration/60

    state.eggs_laid[virtue_egg_index[state.farm.egg]] += duration * state.farm.laying_per_chick * (population + 0.5*population_growth)

    if population_growth == 0:
        print()
        return
    if population_growth + population <= state.farm.hab_size:
        state.farm.pop += population_growth
    else: state.farm.pop = state.farm.hab_size
    print(f"population increased from {format(population)} to {format(state.farm.pop)}")   
    print()

def run_chickens(state, number):
    population = state.farm.pop
    if number + population <= state.farm.hab_size:
        state.farm.pop += number
    else: state.farm.pop = state.farm.hab_size
    print(f"population increased from {format(population)} to {format(state.farm.pop)}")
    print()

def shift(state, new_egg):
    if new_egg not in virtue_egg_index or new_egg==state.farm.egg:
        print("Invalid egg")
        return
    state.farm.egg = new_egg
    state.farm.cash = 0
    state.farm.pop = 0
    state.shifts += 1
    print(f"Shifted to {new_egg} egg farm")
    print()
    status(state)
    


def silo_status(state):
    print(f"----- Silos -----")
    print(f"You own {state.farm.silos} silos")
    print(f"Max away time: {state.farm.max_away_time}h")

    if state.farm.silos == 10:
        print(f"Silos are maxed")
        print()

        return
    print(f"Upgrade cost: {format(silo_price[state.farm.silos])}")
    print()

def hab_status(state):
    print(f"----- Habitats -----")
    print(f"Habs: {state.farm.habs[0]} {state.farm.habs[1]} {state.farm.habs[2]} {state.farm.habs[3]}")
    print(f"Hab size: {state.farm.hab_size}")

    for i in range (4):
        if state.farm.habs[i] == 19:
            print(f"Hab {i} is maxed")
        else: 
            same_habs = 0
            for j in range(4):
                if state.farm.habs[j] == state.farm.habs[i]+1: same_habs+=1
            print(f"Upgrade cost: {format(hab_prices[state.farm.habs[i]][same_habs] * (1-0.05*state.farm.ers[5]) * state.farm.coll_effects[4][int(state.farm.colleggtibles[4])])}")
    print()

def vehicle_status(state):
    print(f"----- Vehicles -----")
    print(f"Vehicles:", end='')
    for i in range(state.farm.max_vehicle_number):
        print(f" {int(state.farm.vehicles[i])}", end='')
    print()
    print(f"Shipping capacity: {format(state.farm.shipping_rate)}")

    for i in range(state.farm.max_vehicle_number):
        if state.farm.vehicles[i] > 12 and state.farm.vehicles[i] < 18 + state.farm.crs[50] :
            print(f"Upgrade cost {i}: {format(vehicle_prices[12][state.farm.vehicles[i]-12] * (1-0.05*state.farm.ers[6]) * state.farm.coll_effects[5][int(state.farm.colleggtibles[5])])}")
        else: 
            same_vehicles = 0
            for j in range(state.farm.max_vehicle_number):
                if state.farm.vehicles[j] == state.farm.vehicles[i]+1: same_vehicles+=1
            print(f"Upgrade cost {i}: {format(vehicle_prices[int(state.farm.vehicles[i])][same_vehicles] * (1-0.05*state.farm.ers[6]) * state.farm.coll_effects[5][int(state.farm.colleggtibles[5])])}")
    print()

def cr_status(state):
    print(f"----- Research -----")
    for i in range(len(state.farm.crs)):
        if research_available(state=state, cr_index=i):
            print(f"{cr_names[i][1]} ({cr_names[i][2]}) Level {int(state.farm.crs[i])}/{state.farm.max_crs[i]} costs {format(cr_prices[i][int(state.farm.crs[i])] * state.farm.artifact_set.cr_cost * (1-0.05*state.farm.ers[7]) * state.farm.coll_effects[8][int(state.farm.colleggtibles[8])])}" )
    research_count = 0
    for i in range(len(state.farm.crs)):
        research_count += state.farm.crs[i]
    for i in range(len(cr_bounds)-1):
        if cr_bounds[i] > research_count:
            print(f"Next tier unlocked in {int(cr_bounds[i] - research_count)} researches")
            print()
            return
    print()

def buy_silo(state):
    if state.farm.egg != "resilience":
        print(f"You cant buy silos from {state.farm.egg} egg farm!")

        return
    if state.farm.cash<silo_price[state.farm.silos]:
        print(f"Not enough cash!")

        return
    if state.farm.silos == 10:
        print(f"Already maxed silos!")
        return
    
    state.farm.cash -= silo_price[state.farm.silos]
    state.farm.silos += 1
    print(f"Now you own {state.farm.silos} silos!")
    print()


def buy_hab(state, hab, linebreak=True):
    if hab<0 or hab>3:
        print(f"Invalid hab: {hab}")
        return
    if state.farm.egg != "integrity":
        print(f"You cant buy habs from {state.farm.egg} egg farm!")
        return
    
    same_habs = 0
    for j in range(4):
        if state.farm.habs[j] == state.farm.habs[hab]+1: same_habs+=1
    upgrade_cost = hab_prices[state.farm.habs[hab]][same_habs] * (1-0.05*state.farm.ers[5]) * state.farm.coll_effects[4][int(state.farm.colleggtibles[4])]
 
    if state.farm.cash<upgrade_cost:
        print(f"Not enough cash!")
        return
    
    if state.farm.habs[hab] == 19:
        print(f"Hab {hab} is maxed")
        return
    
    state.farm.cash -= upgrade_cost
    state.farm.habs[hab] += 1
    print(f"Upgraded hab {hab} from {state.farm.habs[hab]-1} to {state.farm.habs[hab]}!")
    if linebreak: print()

def buy_hab_all(state):
    counter=0
    while True:
        counter+=1
        min_price = 1e34
        min_index = -1

        for i in range(len(state.farm.habs)):
            if state.farm.habs[i]<19:
                same_habs = 0
            for j in range(4):
                if state.farm.habs[j] == state.farm.habs[i]+1: same_habs+=1
                upgrade_cost = hab_prices[state.farm.habs[i]][same_habs] * (1-0.05*state.farm.ers[5]) * state.farm.coll_effects[4][int(state.farm.colleggtibles[4])]
                if upgrade_cost < min_price:
                    min_price = upgrade_cost
                    min_index = i

        if min_index==-1 or state.farm.cash<min_price: 
            if(counter==1):
                print("No hab bought :(")
            else:
                print(f"Bought {counter-1} habs!")
            print()
            break
        buy_hab(state, min_index, linebreak=False)

def buy_vehicle(state, vehicle, linebreak=True):
    if vehicle<0 or vehicle>state.farm.max_vehicle_number:
        print(f"Invalid vehicle: {vehicle}")
        return
    if state.farm.egg != "kindness":
        print(f"You cant buy vehicles from {state.farm.egg} egg farm!")
        return

    if state.farm.vehicles[vehicle]>12:
        upgrade_cost = vehicle_prices[12][state.farm.vehicles[vehicle]] * (1-0.05*state.farm.ers[6]) * state.farm.coll_effects[5][int(state.farm.colleggtibles[5])]
    else:
        same_vehicles = 0
        for j in range(state.farm.max_vehicle_number):
            if state.farm.vehicles[j] == state.farm.vehicles[vehicle]+1: same_vehicles+=1
        upgrade_cost = vehicle_prices[int(state.farm.vehicles[vehicle])][same_vehicles] * (1-0.05*state.farm.ers[6]) * state.farm.coll_effects[5][int(state.farm.colleggtibles[5])]

    if state.farm.cash<upgrade_cost:
        print(f"Not enough cash!")
        return
    
    if state.farm.vehicles[vehicle] == 17 + state.farm.crs[50]:
        print(f"Vehicle {vehicle} is maxed")
        return
    
    state.farm.cash -= upgrade_cost
    state.farm.vehicles[vehicle] += 1
    print(f"Upgraded vehicle {vehicle} from {int(state.farm.vehicles[vehicle]-1)} to {int(state.farm.vehicles[vehicle])}!")
    if linebreak: print()

def buy_vehicle_all(state):
    counter=0
    while True:
        counter+=1
        min_price = 1e28
        min_index = -1

        for i in range(len(state.farm.vehicles)):
            if state.farm.vehicles[i]<22:
                same_vehicles = 0
            for j in range(state.farm.max_vehicle_number):
                if state.farm.vehicles[j] == state.farm.vehicles[i]+1: same_vehicles+=1
                upgrade_cost = vehicle_prices[int(state.farm.vehicles[i])][same_vehicles] * (1-0.05*state.farm.ers[6]) * state.farm.coll_effects[5][int(state.farm.colleggtibles[5])]
                if upgrade_cost < min_price:
                    min_price = upgrade_cost
                    min_index = i

        if min_index==-1 or state.farm.cash<min_price: 
            if(counter==1):
                print("No vehicle bought :(")
            else:
                print(f"Bought {counter-1} vehicles!")
            print()
            break
        buy_vehicle(state, min_index, linebreak=False)

def buy_cr(state, cr_index, linebreak=True):
    if state.farm.egg != "curiosity":
        print(f"You cant buy research from {state.farm.egg} egg farm!")
        return
    if not research_available(state=state, cr_index=cr_index):
        print(f"Research not available")
        return
    upgrade_cost = cr_prices[cr_index][int(state.farm.crs[cr_index])] * state.farm.artifact_set.cr_cost * (1-0.05*state.farm.ers[7]) * state.farm.coll_effects[8][int(state.farm.colleggtibles[8])]

    if state.farm.cash<upgrade_cost:
        print(f"Not enough cash!")
        return
    
    state.farm.cash -= upgrade_cost
    state.farm.crs[cr_index] += 1
    print(f"Researched {cr_names[cr_index][1]} to level {int(state.farm.crs[cr_index])}/{state.farm.max_crs[cr_index]}!")
    if linebreak: print()

def buy_cr_all(state):
    counter=0
    while True:
        counter+=1
        min_price = 1e55
        min_index = -1
        for i in range(len(state.farm.crs)):
            if research_available(state=state, cr_index=i):
                upgrade_cost = cr_prices[i][int(state.farm.crs[i])] * state.farm.artifact_set.cr_cost * (1-0.05*state.farm.ers[7]) * state.farm.coll_effects[8][int(state.farm.colleggtibles[8])]
                if upgrade_cost < min_price:
                    min_price = upgrade_cost
                    min_index = i

        if min_index==-1 or state.farm.cash<min_price: 
            if(counter==1):
                print("No research bought :(")
            else:
                print(f"Bought {counter-1} researches!")
            print()
            break
        buy_cr(state, min_index, linebreak=False)

def virtue_simul(egg="",te=-1):
    #try:
        print("-----------------------------------------")
        print("| GnuWithFlu's Path of Virtue simulator |")
        print("-----------------------------------------")
        print("There's a difference between knowing The Path, and walking The Path.")
        print()
        print("I hope this little program can assist you a bit for the knowing part,")
        print("the walking you have to do on your own. You can enter 'help' anytime. Enjoy!")
        print()

        if egg=="":
            egg = set_egg()
        if te==-1:
            te = set_te()

        ers = [15,20,20,20,20,10,10,10,20,100,20,12,20,140,20,20,30,10,20,5,60,10]
        coll = np.ones(10)*4
        vehicles = np.zeros(17)
        vehicles[0]=1
        habs = [1,0,0,0]
        f = Farm(egg=egg, ers=ers, colleggtibles=coll, vehicles=vehicles, te=te, silos=1, habs=habs, video_doubler=True)
        state = State(f, time_elapsed=0, eggs_laid=[0,0,0,0,0], te_claimed=[0,0,0,0,0], shifts=0)

        print(f"You are all set!")
        print()

        status(state=state)
        while True:
            s = input()
            if s=="help":
                print(f"You can enter the following commands:")
                print(f"status: Shows your current farm stats")
                print(f"run <number>: Increases you population as if you ran chickens")
                print(f"waitonline <duration in s, min, h or d>: Cash and chickens increase as if you left the game open")
                print(f"wait <duration in s, min, h or d>: Cash and chickens increase as if you closed the game")
                print(f"buy <something>: E.g. silo")
                #print(f"shift <egg name>: Shift to another farm")
                print(f"leave: Leave simulation")
                print()
                continue

            parts = re.split(" ", s)

            if parts[0]=="status":
                status(state)
                continue
            
            if parts[0]=="leave" or parts[0]=="exit":
                break

            if parts[0]=="silo" or parts[0]=="silos":
                silo_status(state=state)
                continue
            if parts[0]=="hab" or parts[0]=="habs" or parts[0]=="habitats":
                hab_status(state=state)
                continue
            if parts[0]=="veh" or parts[0]=="vehicles" or parts[0]=="shipping" or parts[0]=="fleet":
                vehicle_status(state=state)
                continue
            if parts[0]=="cr" or parts[0]=="crs" or parts[0]=="research":
                cr_status(state=state)
                continue

            if len(parts)<2:
                print(f"Invalid command")
                continue

            if parts[0]=="run":
                run_chickens(state=state, number=int(parts[1]))
                continue

            if parts[0]=="waitonline":
                wait_online(state=state, duration=read_time(parts[1]))
                continue

            if parts[0]=="waitoffline" or parts[0]=="wait":
                wait_offline(state=state, duration=read_time(parts[1]))
                continue

            if parts[0]== "shift":
                shift(state=state, new_egg=parts[1])
                continue
            
            if parts[0]== "buy":
                if parts[1]=="silo":
                   buy_silo(state=state)
                   continue

            if len(parts)<3:
                print(f"Invalid command")
                continue

            if parts[0]== "buy":
                if parts[1]=="hab":
                   if parts[2]=="all":
                       buy_hab_all(state=state)
                       continue
                   buy_hab(state=state, hab=int(parts[2]))
                   continue
                if parts[1]=="vehicle" or parts[1]=="veh":
                   if parts[2]=="all":
                       buy_vehicle_all(state=state)
                       continue
                   buy_vehicle(state=state, vehicle=int(parts[2]))
                   continue
                if parts[1]=="cr" or parts[1]=="crs" or parts[1]=="research":
                   if parts[2]=="all":
                       buy_cr_all(state=state)
                       continue
                   buy_cr(state=state, cr_index=int(parts[2]))
                   continue

            print(f"Invalid command")

   # except:
      #  print("An error occured")


