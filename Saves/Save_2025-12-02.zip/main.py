# TODO: how does ihr habs multiplied when internal hatchery sharing is not purchased?
# TODO: find exact laying rate formula. There is probably some rounding going on, but where? Does over 1 per mille FV
# TODO: test earnings when shipping capped
# TODO: enlightment on artifacts
# TODO: drone and box cash

import numpy as np
from farm import Farm
from methods import eggPrint,eggRead
from artifact import *
from simulator import virtue_simul


def main():
    
    virtue_simul(egg="curiosity", te=0)

"""
    crs1 =  [50,40,15,25,8,10,30,10,1,10,30,2,25,50,1,1,50,35,10,10,40,2,15,30,2,50,30,60,2,50,5,30,20,100,250,20,25,7,25,100,5,30,50,150,25,50,3,50,25,100,5,25,500,1,25,10]
    ers1 = [15,20,20,20,20,10,10,10,20,100,20,12,20,140,20,20,30,10,20,5,60,10]
    coll1 = np.ones(10)*4
    vehicles1 = np.ones(17)*21
    habs1 = [1,0,0,0] #[19,19,19,19]
    set = Artifact_set(a2=Artifact(type="totem", level=4, rarity=3, stone1=Stone(type="lunar",level=4), stone2=Stone(type="lunar",level=4),stone3=Stone(type="lunar",level=4)))

    f = Farm(egg="universe", crs=crs1, ers=ers1, colleggtibles=coll1, vehicles=vehicles1, se=504.135e18, pe=171, te=49, silos=1, habs=habs1, artifact_set=set, pop=788)
    #eggPrint(f.farm_value)
"""

if __name__ == "__main__":
    main() 