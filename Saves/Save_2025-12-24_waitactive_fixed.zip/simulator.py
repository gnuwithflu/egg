from farm import *
import re
import os, sys
import traceback
from methods import *
from prices import *
from simulation_commands import*
#TODO ER and Collectible setter

commands = {
    "help": help,
    "status": status,
    "virtue": virtue,

    "shift": shift,
    "prestige": prestige,

    "silo": silo_status,
    "hab": hab_status,
    "veh": vehicle_status,
    "cr": cr_status,

    "run": run_chickens,
    "waitonline": wait_offline,
    "waitoffline": wait_offline,
    "wait": wait_offline,
    "waitactive": wait_active,
    
    "timeaway": time_cash_away,
    "timeactive": time_cash_active,
    
    "buy": buy,
    "buyall": buy_all,

    "curiosity": curiosity,
    "kindness": kindness,
    "integrity": integrity,
    "resilience": resilience,
    "humility": humility,

    "event": event
}


def simulation(egg="", te=-1, eggs_layed=[0,0,0,0,0], shifts=0, artifact_set=Artifact_set()):
    if egg=="":
        egg = set_egg()
    if te==-1:
        te = set_te()
    if te>0 and eggs_layed == [0,0,0,0,0]:
        eggs_layed = set_eggs_layed()

    f = Farm(egg=egg, 
                 ers=[15,20,20,20,20,10,10,10,20,100,20,12,20,140,20,20,30,10,20,5,60,10], 
                 colleggtibles=np.ones(11)*4, 
                 vehicles=[1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0], 
                 te=te, 
                 silos=1, 
                 habs=[1,0,0,0],
                 artifact_set=artifact_set,
                 video_doubler=True)
    state = State(f, time_elapsed=0, eggs_layed=eggs_layed, te_claimed=[0,0,0,0,0], shifts=shifts)
    claim_te(state)

    os.system('clear')
    index(state)

    curiosity(state, '1h')
    integrity(state, '2min')
    shift(state, 'kindness')

    time_cash_active(state, '1T')
    while True:
        try:
            s = input()
            os.system('clear')
            index(state)
            
            
            parts = re.split(" ", s)
            if len(parts)>2:
                print(f"To many arguments: {parts}")
                continue
            if len(parts)==1:
                parts.append("")
            if parts[0] not in commands:
                print(f"Unknown command: {parts}")
                continue
            commands[parts[0]](state, parts[1])
            if parts[0] == "prestige":
                break
                
        except Exception as e:
            traceback.print_exc()
            print(f"Invalid command: {s} (error: {e})")



