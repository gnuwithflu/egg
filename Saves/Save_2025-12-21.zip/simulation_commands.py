from farm import *
import re
import os, sys
from methods import *
from prices import *
import copy

virtue_egg_index = {
    "curiosity": 0,
    "kindness": 1,
    "resilience": 2,
    "humility": 3,
    "integrity": 4
}

class State:
    def __init__(self, farm, time_elapsed, eggs_layed, te_claimed, shifts):
        self.farm = farm
        self.time_elapsed = time_elapsed
        self.eggs_layed = eggs_layed
        self.te_claimed = te_claimed
        self.shifts = shifts

def te_treshholds(n):
    treshholds = [0, 50e6, 1e9, 10e9, 70e9, 500e9, 2e13, 7e12, 20e12, 60e12, 150e12, 500e12, 1.5e15, 4e15, 10e15, 25e15, 50e15, 100e15]
    if n<17:
        return treshholds[n]
    return 1e17 + (n-17)*1e16*(n/2 - 4)

def te_numbers(eggs_layed):
    i=0
    while True:
        if te_treshholds(i)>eggs_layed:
            return i - 1
        i += 1


def set_egg():
    os.system('clear')
    print("-----------------------------------------")
    print("| GnuWithFlu's Path of Virtue simulator |")
    print("-----------------------------------------")
    print()
    print("\033[34mWhich egg do you start on?\033[0m curiosity, kindness, resilience, humility or integrity?")

    while True:
        s = input()
        if (s=="curiosity" or s=="kindness" or s=="resilience" or s=="humility" or s=="integrity"): return s
        sys.stdout.write("\033[1A\r\033[K")

def set_te():
    os.system('clear')
    print("-----------------------------------------")
    print("| GnuWithFlu's Path of Virtue simulator |")
    print("-----------------------------------------")
    print()
    print("\033[34mHow many TE do you have?\033[0m")
    while True:
        s = input()
        sys.stdout.write("\033[1A\r\033[K")
        try:
            if int(s)<0:
                continue
            return int(s)
        except ValueError:
            continue

def claim_te(state):
    for i in range(5):
        state.te_claimed[i] = te_numbers(state.eggs_layed[i])

def set_eggs_layed():
    os.system('clear')
    print("-----------------------------------------")
    print("| GnuWithFlu's Path of Virtue simulator |")
    print("-----------------------------------------")
    print()
    print("\033[34mHow many eggs have you already layed on each farm?\033[0m")
    print("Please enter 5 numbers separated by spaces for CKRHI, e.g. \"14M 27B 13.2T 150M 0\"")
    while True:
        s = input()
        sys.stdout.write("\033[1A\r\033[K")

        try:
            parts = re.split(" ", s)
            if len(parts)!=5: continue
            return [eggRead(parts[0]), eggRead(parts[1]), eggRead(parts[2]), eggRead(parts[3]), eggRead(parts[4])]
        except ValueError:
            continue

def help():
    print(f"\033[34mYou can enter the following commands:\033[0m")
    print(f"\033[32mhelp\033[0m: Show this list of commands")
    print(f"\033[32mprogress\033[0m: Show eggs shipped and TE claimed")
    print(f"\033[32mcr/hab/veh/silo\033[0m: Show respective status")
    print(f"\033[32mrun <number>\033[0m: Increases your population as if you ran chickens")
    print(f"\033[32mwait <duration>\033[0m: Cash and chickens increase as if you closed the game")
    print(f"\033[32mwait <cash>\033[0m: Wait until you have a certain amount of cash")
    print(f"\033[32mwaitonline <duration>\033[0m: Cash and chickens increase as if you were online, running chickens, catching drones and gifts")
    print(f"\033[32mbuy <something>\033[0m: Buy cr, hab, veh or silo")
    print(f"\033[32mshift <egg>\033[0m: Shift to another egg")
    print(f"\033[32mleave <something>\033[0m: Leave the simulation")
    print()


def research_available(state, cr_index):
    if state.farm.crs[cr_index] == max_crs[cr_index]:
        return False
    research_count = 0
    for i in range(len(state.farm.crs)):
        research_count += state.farm.crs[i]
    if cr_bounds[cr_names[cr_index][0]-1] > research_count:
        return False
    return True

def index(state):
    os.system('clear')
    print("-----------------------------------------")
    print("| GnuWithFlu's Path of Virtue simulator |")
    print("-----------------------------------------")
    print()
    print(f"\033[34m{state.farm.egg} egg farm\033[0m") 
    print(f"Time elapsed: \033[32m{format_time(state.time_elapsed)}\033[0m | Layed: \033[32m{format(state.eggs_layed[0])}/{format(te_treshholds(te_numbers(state.eggs_layed[0])+1))}\033[0m")
    print(f"Population: \033[32m{format(int(state.farm.pop))}/{format(int(state.farm.hab_size))}\033[0m | Shipping: \033[32m{format(state.farm.laying_per_chick*state.farm.pop*60)}/{format(state.farm.shipping_rate*60)}\033[0m")
    print(f"Cash: \033[32m{format(state.farm.cash)}\033[0m | Active: \033[32m{format(state.farm.earnings_active)}/sec\033[0m | Offline: \033[32m{format(state.farm.earnings_away)}/sec\033[0m")
    print()
"""
def update_index(state, lines):
    sys.stdout.write('\033[H')  # Move cursor to home (line 1, col 1)
    sys.stdout.flush()
    index(state)
"""
def status(state):
    print(f"\033[34m----- Status -----\033[0m")
    print(f"Farm Value: \033[32m{format(state.farm.farm_value)}\033[0m")
    print(f"Egg Value: \033[32m{format(state.farm.egg_value)}\033[0m")
    print(f"IHR: \033[32m{format(state.farm.ihr*60)}/min\033[0m")
    print(f"Elite Drone Value (max RCB): \033[32m{format(state.farm.elite_drone_value)}\033[0m")
    print()

def virtue(state):
    print(f"\033[34m----- Virtue Stats -----\033[0m")
    print(f"Truth Eggs: \033[32m{format(state.farm.te, True)}\033[0m | Shifts: \033[32m{format(state.shifts, True)}\033[0m")
    print()
    print(f"Egg         Layed   Goal    TE")
    print(f"Curiosity:  \033[32m{format(state.eggs_layed[0]):<9} {format(te_treshholds(te_numbers(state.eggs_layed[0])+1)):<9} {state.te_claimed[0]:<3}+{te_numbers(state.eggs_layed[0])-state.te_claimed[0]}\033[0m")
    print(f"Kindness:   \033[32m{format(state.eggs_layed[1]):<9} {format(te_treshholds(te_numbers(state.eggs_layed[1])+1)):<9} {state.te_claimed[1]:<3}+{te_numbers(state.eggs_layed[1])-state.te_claimed[1]}\033[0m")
    print(f"Resilience: \033[32m{format(state.eggs_layed[2]):<9} {format(te_treshholds(te_numbers(state.eggs_layed[2])+1)):<9} {state.te_claimed[2]:<3}+{te_numbers(state.eggs_layed[2])-state.te_claimed[2]}\033[0m")
    print(f"Humility:   \033[32m{format(state.eggs_layed[3]):<9} {format(te_treshholds(te_numbers(state.eggs_layed[3])+1)):<9} {state.te_claimed[3]:<3}+{te_numbers(state.eggs_layed[3])-state.te_claimed[3]}\033[0m")
    print(f"Integrity:  \033[32m{format(state.eggs_layed[4]):<9} {format(te_treshholds(te_numbers(state.eggs_layed[4])+1)):<9} {state.te_claimed[4]:<3}+{te_numbers(state.eggs_layed[4])-state.te_claimed[4]}\033[0m")
    print()

def wait_online(state, t, printout=True):
    f = state.farm
    if t <= 0:
        if printout: print(f"Duration must be positive")
        return
    state.time_elapsed += t

    growth = f.ihr
    cash = 0
    layed = 0
    pop = f.pop
    pop0 = f.pop

    if growth == 0 or pop == f.hab_size:
        cash += f.earnings * t
        layed += f.pop * f.laying_per_chick * t
    else:
        t_hab = (f.hab_size - pop)/growth
        t_ship = (f.shipping_rate - f.laying_per_chick*pop)/growth
        if t_ship < 0: t_ship = 0

        # farm grows unrestricted
        if t_hab>=t and t_ship>=t: 
            pop += growth * t
            cash += f.earnings_pop((pop + f.pop)/2) * t
            layed += f.laying_per_chick * (pop + f.pop)/2 * t

        # shipblocked
        elif t_hab>=t_ship and t_ship<t:
            pop += growth * t_ship
            cash += f.earnings_pop((pop + f.pop)/2) * t_ship
            layed += f.laying_per_chick * (pop + f.pop)/2 * t_ship
            cash += f.earnings_pop(pop) * (t - t_ship)
            layed += f.laying_per_chick * pop * (t - t_ship)
            pop = min(pop+growth*(t-t_ship), f.hab_size)

        # habblocked
        elif t_hab<t and t_ship>=t_hab:
            pop = f.hab_size
            cash += f.earnings_pop((pop + f.pop)/2) * t_hab
            layed += f.laying_per_chick * (pop + f.pop)/2 * t_hab

            cash += f.earnings_pop(pop) * (t - t_hab)
            layed += f.laying_per_chick * pop * (t - t_hab)

    # update farm stats
    state.eggs_layed[virtue_egg_index[f.egg]] += layed
    f.cash += cash
    f.pop = pop

    if printout:
        index(state)
        print(f"Population: {format(pop0)} -> {format(pop)}")
        print(f"Cash: {format(f.cash-cash)} -> {format(f.cash)}")
        print()
    return    
        
    
def wait_offline(state, t, printout=True):
    f = state.farm
    if t <= 0:
        if printout: print(f"Duration must be positive")
        return 0
    state.time_elapsed += t

    growth = f.ihr_away
    cash = 0
    layed = 0
    pop = f.pop
    pop0 = f.pop

    if growth == 0 or pop == f.hab_size:
        cash += f.earnings_away * t
        layed += f.pop * f.laying_per_chick * t
    else:
        t_hab = (f.hab_size - pop)/growth
        t_ship = (f.shipping_rate - f.laying_per_chick*pop)/(f.laying_per_chick*growth)
        if t_ship < 0: t_ship = 0
        
        # farm grows unrestricted
        if t_hab>=t and t_ship>=t: 
            pop += growth * t
            cash += f.earnings_pop_away((pop + f.pop)/2) * t
            layed += f.laying_per_chick * (pop + f.pop)/2 * t

        # shipblocked
        elif t_hab>=t_ship and t_ship<t:
            pop += growth * t_ship
            cash += f.earnings_pop_away((pop + f.pop)/2) * t_ship
            layed += f.laying_per_chick * (pop + f.pop)/2 * t_ship
            cash += f.earnings_pop_away(pop) * (t - t_ship)
            layed += f.laying_per_chick * pop * (t - t_ship)
            pop = min(pop+growth*(t-t_ship), f.hab_size)

        # habblocked
        elif t_hab<t and t_ship>=t_hab:
            pop = f.hab_size
            cash += f.earnings_pop_away((pop + f.pop)/2) * t_hab
            layed += f.laying_per_chick * (pop + f.pop)/2 * t_hab
            cash += f.earnings_pop_away(pop) * (t - t_hab)
            layed += f.laying_per_chick * pop * (t - t_hab)  
    
    # update farm stats
    state.eggs_layed[virtue_egg_index[f.egg]] += layed
    f.cash += cash
    f.pop = pop

    if printout:
        index(state)
        print(f"Population: {format(pop0)} -> {format(pop)}")
        print(f"Cash: {format(f.cash-cash)} -> {format(f.cash)}")
        print()
    return   



def time_cash_away(state, cash): # leaves state unchanged!
    f = state.farm
    growth = f.ihr_away
    cash_to_go = cash - f.cash
    pop = f.pop

    if cash <= f.cash or (pop == 0 and growth == 0):
        return 0

    if growth == 0 or pop == f.hab_size:
        return cash_to_go / f.earnings_away
    else:
        
        t_hab = (f.hab_size - pop)/growth
        t_ship = (f.shipping_rate - f.laying_per_chick*pop)/(f.laying_per_chick*growth)
        if t_ship < 0: t_ship = 0
        cash_hab = f.earnings_pop_away(growth*t_hab/2) * t_hab
        cash_ship = f.earnings_pop_away(growth*t_ship/2) * t_ship

        # farm grows unrestricted
        if cash_hab>=cash_to_go and cash_ship>=cash_to_go: 
            return quad_formula(a=0.5*growth*f.earnings_pop_away(1), b=0.5*f.earnings_pop_away(f.pop), c=-cash_to_go)
        
        # shipblocked
        elif cash_hab>=cash_ship and cash_ship<cash_to_go:
            cash_to_go -= cash_ship
            pop += growth * t_ship
            return cash_to_go / f.earnings_pop_away(pop) + t_ship

        # habblocked
        elif cash_hab<cash_to_go and cash_ship>=cash_hab:
            cash_to_go -= cash_hab
            pop = f.hab_size
            return cash_to_go / f.earnings_pop_away(pop) + t_hab
        raise ValueError(f"Nothing works :o")




def wait_active(state, t, printout=True):
    f = state.farm
    if t <= 0:
        if printout: print(f"Duration must be positive")
        return
    state.time_elapsed += t

    growth = f.ihr + f.manual_hatchery_rate
    cash = 0
    layed = 0
    pop = f.pop
    pop0 = f.pop
    effective_rcb = min(f.max_rcb,f.manual_hatchery_rate*f.rcb_per_chicken)

    if  pop == f.hab_size:
        cash += f.earnings * t
        layed += f.pop * f.laying_per_chick * t
    else:
        t_hab = (f.hab_size - pop)/growth
        t_ship = (f.shipping_rate - f.laying_per_chick*pop)/growth
        if t_ship < 0: t_ship = 0
        
        # farm grows unrestricted
        if t_hab>=t and t_ship>=t: 
            pop += growth * t
            cash += f.earnings_pop((pop + f.pop)/2) * effective_rcb * t
            cash += (f.gifts_and_drones(pop) + f.gifts_and_drones(f.pop))/2 * t
            layed += f.laying_per_chick * (pop + f.pop)/2 * t

        # shipblocked
        elif t_hab>=t and t_ship<t:
            pop += growth * t_ship
            cash += f.earnings_pop((pop + f.pop)/2) * effective_rcb * t_ship
            cash += (f.gifts_and_drones(pop) + f.gifts_and_drones(f.pop))/2 * t_ship
            layed += f.laying_per_chick * (pop + f.pop)/2 * t_ship

            cash += f.earnings_pop(pop) * effective_rcb* (t - t_ship)
            cash += (f.gifts_and_drones(pop) + f.gifts_and_drones(pop + growth * (t - t_ship)))/2
            layed += f.laying_per_chick * pop * (t - t_ship)
            pop += growth * (t - t_ship)

        # habblocked
        elif t_hab<t and t_ship>=t_hab:
            pop = f.hab_size
            cash += f.earnings_pop((pop + f.pop)/2) * effective_rcb * t_hab
            cash += (f.gifts_and_drones(pop) + f.gifts_and_drones(f.pop-1))/2 * t_hab
            layed += f.laying_per_chick * (pop + f.pop)/2 * t_hab
            
            cash += f.earnings_pop(pop) * (t - t_hab)
            cash += f.gifts_and_drones(pop) * (t - t_hab)
            layed += f.laying_per_chick * pop * (t - t_hab)

        # shipblocked, then habblocked
        elif t_hab<t and t_ship<t_hab:
            pop += growth * t_ship
            cash += f.earnings_pop((pop + f.pop)/2) * effective_rcb * t_ship
            cash += (f.gifts_and_drones(pop) + f.gifts_and_drones(f.pop))/2 * t_ship
            layed += f.laying_per_chick * (pop + f.pop)/2 * t_ship

            cash += f.earnings_pop((pop + f.hab_size)/2) * effective_rcb * (t_hab - t_ship)
            cash += (f.gifts_and_drones(pop) + f.gifts_and_drones(f.hab_size-1))/2 * (t_hab - t_ship)
            layed += f.laying_per_chick * (pop + f.hab_size)/2 * (t_hab - t_ship)
            pop = f.hab_size

            cash += f.earnings_pop(pop) * (t - t_hab - t_ship)
            cash + f.gifts_and_drones(pop) * (t - t_hab - t_ship)
            layed += f.laying_per_chick * pop * (t - t_hab - t_ship)   
    
    # update farm stats
    state.eggs_layed[virtue_egg_index[f.egg]] += layed
    f.cash += cash
    f.pop = pop

    if printout:
        index(state)
        print(f"Population: {format(pop0)} -> {format(pop)}")
        print(f"Cash: {format(f.cash-cash)} -> {format(f.cash)}")
        print()
    return    


def time_cash_active(state, cash): # leaves state unchanged!
    f = state.farm
    growth = f.ihr + f.manual_hatchery_rate
    cash_to_go = cash - f.cash
    pop = f.pop
    effective_rcb = min(f.max_rcb,f.manual_hatchery_rate*f.rcb_per_chicken)

    if cash <= f.cash or (pop == 0 and growth == 0):
        return 0

    if pop == f.hab_size:
        return cash_to_go / f.earnings_active
    else:
        t_hab = (f.hab_size - pop)/growth
        t_ship = (f.shipping_rate - f.laying_per_chick*pop)/(f.laying_per_chick*growth)
        if t_ship < 0: t_ship = 0
        cash_hab = (f.earnings_pop(growth*t_hab/2) * effective_rcb + (f.gifts_and_drones(pop) + f.gifts_and_drones(f.hab_size))/2)  * t_hab
        cash_ship = (f.earnings_pop(growth*t_ship/2) * effective_rcb + (f.gifts_and_drones(pop) + f.gifts_and_drones(min(pop+growth*t_ship,f.hab_size)))/2) * t_ship

        # farm grows unrestricted (works, but overestimates a bit by linearising)
        if cash_hab>=cash_to_go and cash_ship>=cash_to_go: 
            return quad_formula(
                a=0.5*(f.earnings_pop(1)*effective_rcb*growth + f.gifts_and_drones(f.hab_size-1)/f.hab_size*growth),
                b=f.earnings_pop(f.pop)*effective_rcb + 0.5*f.gifts_and_drones(f.pop),
                c=-cash_to_go)
        
        # shipblocked
        elif cash_hab>=cash_to_go and cash_ship<cash_to_go:
            cash_to_go -= cash_ship
            pop += growth * t_ship
            return quad_formula(a=f.gifts_and_drones(f.hab_capacities)/f.hab_capacities*growth,
                b= f.earnings_pop(pop) * effective_rcb + f.gifts_and_drones(pop), c = -cash_to_go) + t_ship

        # habblocked
        elif cash_hab<cash_to_go and cash_ship>=cash_hab:
            cash_to_go -= cash_hab
            pop = f.hab_size
            return cash_to_go / (f.earnings_pop(pop)+f.gifts_and_drones(pop)) + t_hab

        # shipblocked, then habblocked
        elif cash_hab>=t_ship and cash_ship<cash_to_go:
            cash_to_go -= cash_ship
            pop += growth * t_ship
            cash_to_go -= (f.earnings_pop(pop) * effective_rcb + (f.gifts_and_drones(pop) + f.gifts_and_drones(f.hab_size))/2) * (t_hab - t_ship)
            pop = f.hab_size
            return cash_to_go / (f.earnings_pop(pop)+f.gifts_and_drones(pop)) + t_hab
        raise ValueError(f"Nothing works :o")



def run_chickens(state, number):
    population = state.farm.pop
    if number + population <= state.farm.hab_size:
        state.farm.pop += number
    else: state.farm.pop = state.farm.hab_size
    index(state)
    print(f"population increased from \033[32m{format(population)}\033[0m to \033[32m{format(state.farm.pop)}\033[0m")
    print()

def shift(state, new_egg, printout=True):
    if new_egg not in virtue_egg_index or new_egg==state.farm.egg:
        print("Invalid egg")
        return
    state.farm.egg = new_egg
    state.farm.cash = 0
    state.farm.pop = 0
    state.shifts += 1
    if printout:
        index(state)
        print(f"Shifted to {new_egg} egg farm")
        print()
    


def silo_status(state):
    print(f"\033[34m----- Silos -----\033[0m")
    print(f"You own \033[32m{state.farm.silos}\033[0m silos")
    print(f"Max away time: \033[32m{state.farm.max_away_time/60}h\033[0m")

    if state.farm.silos == 10:
        print(f"Silos are maxed")
        print()

        return
    print(f"Upgrade cost: \033[32m{format(silo_price[state.farm.silos])}\033[0m")
    print()

def hab_status(state):
    print(f"\033[34m----- Habitats -----\033[0m")
    print(f"Habs: \033[32m{state.farm.habs[0]} {state.farm.habs[1]} {state.farm.habs[2]} {state.farm.habs[3]}\033[0m")
    print(f"Hab size: \033[32m{format(state.farm.hab_size)}\033[0m")

    for i in range (4):
        if state.farm.habs[i] == 19:
            print(f"Hab \033[32m{i}\033[0m is maxed")
        else: 
            same_habs = 0
            for j in range(4):
                if state.farm.habs[j] == state.farm.habs[i]+1: same_habs+=1
            print(f"Upgrade cost {i}: \033[32m{format(hab_prices[state.farm.habs[i]][same_habs] * (1-0.05*state.farm.ers[5]) * state.farm.coll_effect("flame"))}\033[0m")
    print()

def vehicle_status(state):
    print(f"\033[34m----- Vehicles -----\033[0m")
    print(f"Vehicles:", end='')
    for i in range(state.farm.max_vehicle_number):
        print(f" \033[32m{int(state.farm.vehicles[i])}\033[0m", end='')
    print()
    print(f"Shipping capacity: \033[32m{format(state.farm.shipping_rate*60)}/min\033[0m")

    for i in range(state.farm.max_vehicle_number):
        if state.farm.vehicles[i] > 12 and state.farm.vehicles[i] < 18 + state.farm.crs[50] :
            print(f"Upgrade cost {i}: \033[32m{format(vehicle_prices[12][state.farm.vehicles[i]-12] * (1-0.05*state.farm.ers[6]) * state.farm.coll_effect("lithium"))}\033[0m")
        else: 
            same_vehicles = 0
            for j in range(state.farm.max_vehicle_number):
                if state.farm.vehicles[j] == state.farm.vehicles[i]+1: same_vehicles+=1
            print(f"Upgrade cost {i}: \033[32m{format(vehicle_prices[int(state.farm.vehicles[i])][same_vehicles] * (1-0.05*state.farm.ers[6]) * state.farm.coll_effect("lithium"))}\033[0m")
    print()

def cr_status(state):
    print(f"\033[34m----- Research -----\033[0m")
    for i in range(len(state.farm.crs)):
        if research_available(state=state, cr_index=i):
            print(f"{i} \033[31m{cr_names[i][1]}\033[0m ({cr_names[i][2]}) Level \033[32m{int(state.farm.crs[i])}/{max_crs[i]}\033[0m costs \033[32m{format(cr_prices[i][int(state.farm.crs[i])] * state.farm.artf.cr_cost * (1-0.05*state.farm.ers[7]) * state.farm.coll_effect("waterballoon"))}\033[0m" )
    research_count = 0
    for i in range(len(state.farm.crs)):
        research_count += state.farm.crs[i]
    for i in range(len(cr_bounds)-1):
        if cr_bounds[i] > research_count:
            print(f"Next tier unlocked in \033[32m{int(cr_bounds[i] - research_count)}\033[0m researches")
            print()
            return
    print()


def buy_silo(state, printout=True):
    f = state.farm
    if f.egg != "resilience":
        print(f"You cant buy silos from {f.egg} egg farm!")
        return False
    if f.cash < silo_price[f.silos]:
        print(f"Not enough cash!")
        return False
    if f.silos == 10:
        print(f"Already maxed silos!")
        return False
    
    f.cash -= silo_price[f.silos]
    f.silos += 1
    if printout:
        index(state)
        print(f"Now you own {f.silos} silos!")
        print()
    return True

def buy_hab(state, hab, printout=True):
    f = state.farm
    if hab<0 or hab>3:
        print(f"Invalid hab: {hab}")
        return False
    if f.egg != "integrity":
        print(f"You cant buy habs from {f.egg} egg farm!")
        return False
        
    if f.habs[hab] == 19:
        print(f"Hab {hab} is maxed")
        return False

    same_habs = 0
    for j in range(4):
        if f.habs[j] == f.habs[hab]+1: same_habs+=1
    upgrade_cost = hab_prices[f.habs[hab]][same_habs] * (1-0.05*f.ers[5]) * f.coll_effect("flame")
 
    if f.cash<upgrade_cost:
        print(f"Not enough cash!")
        return False
    
    f.cash -= upgrade_cost
    f.habs[hab] += 1
    if printout:
        index(state)
        print(f"Upgraded hab {hab} from {f.habs[hab]-1} to {f.habs[hab]}!")
        print()
    return True

def buy_hab_all(state):
    f = state.farm
    counter=0
    while True:
        counter+=1
        min_price = 1e34
        min_index = -1

        for i in range(len(f.habs)):
            if f.habs[i]==19:
                continue
            same_habs = 0
            for j in range(4):
                if f.habs[j] == f.habs[i]+1: same_habs+=1
            upgrade_cost = hab_prices[f.habs[i]][same_habs] * (1-0.05*f.ers[5]) * f.coll_effect("flame")
            if upgrade_cost < min_price:
                min_price = upgrade_cost
                min_index = i

        if min_index==-1 or f.cash<min_price: 
            if(counter==1):
                print("No hab bought :(")
            else:
                index(state)
                print(f"Bought {counter-1} habs!")
            print()
            break
        if not buy_hab(state, min_index, printout=False): break

def buy_vehicle(state, vehicle, printout=True):
    f = state.farm
    if vehicle<0 or vehicle>f.max_vehicle_number:
        print(f"Invalid vehicle: {vehicle}")
        return False
    if f.egg != "kindness":
        print(f"You cant buy vehicles from {f.egg} egg farm!")
        return False

    if f.vehicles[vehicle]>12:
        upgrade_cost = vehicle_prices[12][f.vehicles[vehicle]] * (1-0.05*f.ers[6]) * f.coll_effect("lithium")
    else:
        same_vehicles = 0
        for j in range(f.max_vehicle_number):
            if f.vehicles[j] == f.vehicles[vehicle]+1: same_vehicles+=1
        upgrade_cost = vehicle_prices[int(f.vehicles[vehicle])][same_vehicles] * (1-0.05*f.ers[6]) * f.coll_effect("lithium")

    if f.cash<upgrade_cost:
        print(f"Not enough cash!")
        return False
    
    if f.vehicles[vehicle] == 17 + f.crs[50]:
        print(f"Vehicle {vehicle} is maxed")
        return False
    
    f.cash -= upgrade_cost
    f.vehicles[vehicle] += 1
    if printout:
        index(state)
        print(f"Upgraded vehicle {vehicle} from {int(f.vehicles[vehicle]-1)} to {int(f.vehicles[vehicle])}!")
        print()
    return True

def buy_vehicle_all(state):
    f = state.farm
    counter=0
    while True:
        counter+=1
        min_price = 1e28
        min_index = -1

        for i in range(f.max_vehicle_number):
            if f.vehicles[i]<22:
                same_vehicles = 0
                for j in range(f.max_vehicle_number):
                    if f.vehicles[j] == f.vehicles[i]+1:
                        same_vehicles += 1
                upgrade_cost = vehicle_prices[int(f.vehicles[i])][same_vehicles] * (1-0.05*f.ers[6]) * f.coll_effect("lithium")
                if upgrade_cost < min_price:
                    min_price = upgrade_cost
                    min_index = i

        if min_index==-1 or f.cash<min_price: 
            if(counter==1):
                print("No vehicle bought :(")
            else:
                index(state)
                print(f"Bought {counter-1} vehicles!")
            print()
            break
        if not buy_vehicle(state, min_index, printout=False):
            break

def buy_cr(state, cr_index, printout=True):
    f = state.farm
    if f.egg != "curiosity":
        print(f"You cant buy research from {f.egg} egg farm!")
        return False
    if not research_available(state=state, cr_index=cr_index):
        print(f"Research not available")
        return False
    upgrade_cost = cr_prices[cr_index][int(f.crs[cr_index])] * f.artf.cr_cost * (1-0.05*f.ers[7]) * f.coll_effect("waterballoon")

    if f.cash<upgrade_cost:
        print(f"Not enough cash!")
        return False
    
    f.cash -= upgrade_cost
    f.crs[cr_index] += 1
    if printout:
        index(state)
        print(f"Researched {cr_names[cr_index][1]} to level {int(f.crs[cr_index])}/{max_crs[cr_index]}!")
        print()
    return True

def buy_cr_all(state):
    f = state.farm
    counter=0
    while True:
        counter+=1
        min_price = 1e55
        min_index = -1
        for i in range(len(f.crs)):
            if research_available(state=state, cr_index=i):
                upgrade_cost = cr_prices[i][int(f.crs[i])] * f.artf.cr_cost * (1-0.05*f.ers[7]) * f.coll_effect("waterballoon")
                if upgrade_cost < min_price:
                    min_price = upgrade_cost
                    min_index = i

        if min_index==-1 or f.cash<min_price: 
            if(counter==1):
                print("No research bought :(")
            else:
                index(state)
                print(f"Bought {counter-1} researches!")
            print()
            break
        if not buy_cr(state, min_index, printout=False): break


def resilience(state, time=0):
    f = state.farm
    if f.egg != "resilinence":
        shift(state, "resilience")
        
    time_zero = state.time_elapsed
    counter = 0
    layed0 = state.eggs_layed[virtue_egg_index["resilience"]]

    while state.time_elapsed-time_zero<time:
        if f.cash > silo_price[f.silos]:
            buy_silo(state)
            counter += 1
            continue
        if f.pop < f.hab_size and f.ihr == 0:
            wait_active(state, t=min((f.hab_size-f.pop)/(f.ihr + f.manual_hatchery_rate), time/10, time-state.time_elapsed + time_zero), printout=False)      
        if state.time_elapsed - time_zero + time_cash_away(state, silo_price[f.silos]-f.cash) < time:
            wait_offline(state, 1.001*time_cash_away(state, silo_price[f.silos]))
            if not buy_silo(state, printout=false):
                break
            counter += 1
            continue
        wait_offline(state, time - state.time_elapsed + time_zero)
    
    index(state)
    print(f"Spend {format_time(time)} on resilience.")
    print(f"Bought {counter} silos")
    print(f"Eggs layed {format(layed0)} -> {format(state.eggs_layed[virtue_egg_index["resilience"]])}")  
    return

def kindness(state, time=0):
    f = state.farm
    if f.egg != "kindness":
        shift(state, "kindness")
        
    time_zero = state.time_elapsed
    counter = 0
    layed0 = state.eggs_layed[virtue_egg_index["kindness"]]

    while state.time_elapsed-time_zero<time:
        min_price = 1e28
        min_index = -1

        for i in range(f.max_vehicle_number):
            if f.vehicles[i]<22:
                same_vehicles = 0
                for j in range(f.max_vehicle_number):
                    if f.vehicles[j] == f.vehicles[i]+1:
                        same_vehicles += 1
                upgrade_cost = vehicle_prices[int(f.vehicles[i])][same_vehicles] * (1-0.05*f.ers[6]) * f.coll_effect("lithium")
                if upgrade_cost < min_price:
                    min_price = upgrade_cost
                    min_index = i

        if f.cash > upgrade_cost:
            if not buy_vehicle(state, min_index, linebreak=False):
                print(f"You should not see this")
                break
            counter += 1
            continue
        
        if f.pop < f.hab_size and f.ihr == 0:
            wait_active(state, t=min((f.hab_size-f.pop)/(f.ihr + f.manual_hatchery_rate), time/10, time-state.time_elapsed + time_zero), printout=False)      
            continue  
      
        if state.time_elapsed - time_zero + time_cash_away(state, min_price-f.cash) < time:
            wait_offline(state, 1.001*time_cash_away(state, min_price))
            if not buy_vehicle(state, min_index, linebreak=False):
                print(f"You should not see this at all")
                break            
            counter += 1
            continue
        wait_offline(state, time - state.time_elapsed + time_zero)
    
    index(state)
    print(f"Spend {format_time(time)} on kindness.")
    print(f"Bought {counter} vehicles")
    print(f"Eggs layed {format(layed0)} -> {format(state.eggs_layed[virtue_egg_index["kindness"]])}")  
    return


def integrity(state, time=0):
    f = state.farm
    if f.egg != "integrity":
        shift(state, "integrity")
        
    time_zero = state.time_elapsed
    counter = 0
    layed0 = state.eggs_layed[virtue_egg_index["integrity"]]

    while state.time_elapsed-time_zero<time:
        min_price = 1e28
        min_index = -1

        for i in range(len(f.habs)):
            if f.habs[i]==19:
                continue
            same_habs = 0
            for j in range(4):
                if f.habs[j] == f.habs[i]+1: same_habs+=1
            upgrade_cost = hab_prices[f.habs[i]][same_habs] * (1-0.05*f.ers[5]) * f.coll_effect("flame")
            if upgrade_cost < min_price:
                min_price = upgrade_cost
                min_index = i

        if f.cash > min_price:
            if not buy_hab(state, min_index, printout=False):
                print(f"You should not see this")
                break
            counter += 1
            continue
        
        if f.pop < f.hab_size and f.ihr == 0:
            wait_active(state, t=min((f.hab_size-f.pop)/(f.ihr + f.manual_hatchery_rate), time/10, time-state.time_elapsed + time_zero), printout=False)      
            continue  
      
        if state.time_elapsed - time_zero + time_cash_away(state, min_price-f.cash) < time:
            treb = 1.001*time_cash_away(state, min_price)
            wait_offline(state, 1.001*time_cash_away(state, min_price), printout=False)
            hab_status(state)
            if not buy_hab(state, min_index, printout=False):
                print(f"You should not see this at all")
                break            
            counter += 1
            continue
        wait_offline(state, time - state.time_elapsed + time_zero)
    
    index(state)
    print(f"Spend {format_time(time)} on integrity.")
    print(f"Bought {counter} habs")
    print(f"Eggs layed {format(layed0)} -> {format(state.eggs_layed[virtue_egg_index["integrity"]])}")    
    return


def curiosity(state, time=0):
    f = state.farm
    if f.egg != "curiosity":
        shift(state, "curiosity")
        
    time_zero = state.time_elapsed
    counter = 0
    layed0 = state.eggs_layed[virtue_egg_index["curiosity"]]

    while state.time_elapsed-time_zero<time:
        min_price = 1e28
        min_index = -1

        for i in range(len(f.crs)):
            if research_available(state=state, cr_index=i):
                upgrade_cost = cr_prices[i][int(f.crs[i])] * f.artf.cr_cost * (1-0.05*f.ers[7]) * f.coll_effect("waterballoon")
                if upgrade_cost < min_price:
                    min_price = upgrade_cost
                    min_index = i

        if f.cash >= min_price:
            if not buy_cr(state, min_index, printout=False):
                print(f"You should not see this")
                break
            counter += 1
            continue
        
        if f.pop < f.hab_size and f.ihr == 0:
            wait_active(state, t=min((f.hab_size-f.pop)/(f.ihr + f.manual_hatchery_rate), time/10, time-state.time_elapsed + time_zero), printout=False)      
            continue  
      
        if state.time_elapsed - time_zero + time_cash_away(state, min_price-f.cash) < time:
            wait_offline(state, 1.001*time_cash_away(state, min_price), printout=False)
            if not buy_cr(state, min_index, printout=False):
                print(f"You should not see this at all")
                break            
            counter += 1
            continue
        wait_offline(state, time - state.time_elapsed + time_zero, printout=False)

    index(state)
    print(f"Spend {format_time(time)} on curiosity.")
    print(f"Bought {counter} researches")
    print(f"Eggs layed {format(layed0)} -> {format(state.eggs_layed[virtue_egg_index["curiosity"]])}")
    return

def humility(state, time=0):
    f = state.farm
    time_zero = state.time_elapsed
    layed0 = state.eggs_layed[virtue_egg_index["humility"]]

    if f.egg != "humility":
        shift(state, "humility")

    if f.pop < f.hab_size and f.ihr == 0:
        wait_active(state, t=min((f.hab_size-f.pop)/(f.ihr + f.manual_hatchery_rate),t), printout=False)
    wait_offline(state, time - state.time_elapsed + time_zero, printout=False)

    index(state)
    print(f"Spend {format_time(time)} on humility.")
    print(f"Eggs layed {format(layed0)} -> {format(state.eggs_layed[virtue_egg_index["humility"]])}")
    return

