import math
import re


def eggPrint(n):
    l = ['','K','M','B','T','q','Q','s','S','o','N','d','U','D','Td','qd','Qd','sd','Sd','od','Nd','V','uV','dV','tV','qV','QV','sV','SV','oV','NV']
    if n==0:
        print("0")
        return
    k = math.trunc(math.log(n,10)/3)
    print(f"{float(math.trunc(n/pow(10,3*(k-1)))/1000)}{l[k]}")

def format(n, round=False):
    try:    
        l = ['','K','M','B','T','q','Q','s','S','o','N','d','U','D','Td','qd','Qd','sd','Sd','od','Nd','V','uV','dV','tV','qV','QV','sV','SV','oV','NV']
        if n==0:
            return 0
        k = math.trunc(math.log(n,10)/3)
        if round: return (f"{int(math.trunc(n/pow(10,3*(k))))}{l[k]}")
        return (f"{float(math.trunc(n/pow(10,3*(k-1)))/1000)}{l[k]}")    
    except:
        print(f"{n} is a catastrophic input")
        return 0

def eggRead(s):
    l = ['','K','M','B','T','q','Q','s','S','o','N','d','U','D','Td','qd','Qd','sd','Sd','od','Nd','V','uV','dV','tV','qV','QV','sV','SV','oV','NV']
    pattern = r'([0-9]*\.?[0-9]+)([a-zA-Z]*)'
    match = re.match(pattern, s)
    if not match:
        raise ValueError(f"Invalid egg string: {s}")
    number = float(match.group(1))
    unit = match.group(2)
    if unit not in l:
        raise ValueError(f"Invalid suffix in egg string: {unit}")
    k = l.index(unit)
    return number * (10**(3*k))


def read_time(s): #out in seconds
    pattern = r'([0-9]*\.?[0-9]+)([a-zA-Z]*)'
    match = re.match(pattern, s)
    if not match:
        raise ValueError(f"Invalid time input: {s}")
    number = float(match.group(1))
    unit = match.group(2)
    if unit=="s" or unit=="sec" or unit=="":
        return number
    if unit=="min" or unit=="m":
        return number*60
    if unit=="h":
        return number*3600
    if unit=="d":
        return number*3600*24
    if unit=="y":
        return number*3600*24*365
    raise ValueError(f"Invalid time input: {s}")    

def format_time(time): #input in seconds
    if time<60:
        return f"{round(time,1)}s"
    elif time<3600:
        return f"{round(time/60,1)}min"
    elif time<3600*24:
        return f"{round(time/3600,1)}h"
    elif time<3600*24*365:
        return f"{round(time/(3600*24),1)}d"
    else:
        return f"{round(time/(3600*24*365),1)}y"