from farm import *
import re
import os, sys
import traceback
from methods import *
from prices import *
from simulation_commands import*
#TODO ER and Collectible setter



def simulation(egg="", te=-1, eggs_layed=[0,0,0,0,0], artifact_set=Artifact_set()):
    

    if egg=="":
        egg = set_egg()
    if te==-1:
        te = set_te()
    if te>0 and eggs_layed == [0,0,0,0,0]:
        eggs_layed = set_eggs_layed()

    f = Farm(egg=egg, 
                 ers=[15,20,20,20,20,10,10,10,20,100,20,12,20,140,20,20,30,10,20,5,60,10], 
                 colleggtibles=np.ones(10)*4, 
                 vehicles=[1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0], 
                 te=te, 
                 silos=1, 
                 habs=[1,0,0,0],
                 artifact_set=artifact_set,
                 video_doubler=True)
    state = State(f, time_elapsed=0, eggs_layed=eggs_layed, te_claimed=[0,0,0,0,0], shifts=0)
    claim_te(state)

    os.system('clear')
    index(state)
    refresh = False
    while True:
        #if refresh: update_index(state, refresh)
        refresh=False
        if True: #try:
            s = input()
            os.system('clear')
            index(state)
            if s=="help":
                help()
                continue
            
            parts = re.split(" ", s)

                
            if parts[0]=="leave" or parts[0]=="exit":
                break

            if parts[0]=="status":
                status(state)
                continue

            if parts[0]=="silo" or parts[0]=="silos":
                silo_status(state=state)
                continue
            if parts[0]=="hab" or parts[0]=="habs" or parts[0]=="habitats":
                hab_status(state=state)
                continue
            if parts[0]=="veh" or parts[0]=="vehicles" or parts[0]=="shipping" or parts[0]=="fleet":
                vehicle_status(state=state)
                continue
            if parts[0]=="cr" or parts[0]=="crs" or parts[0]=="research":
                cr_status(state=state)
                continue

            if len(parts)<2:
                print(f"Invalid command")
                continue

            if parts[0]=="run":
                run_chickens(state=state, number=int(parts[1]))
                refresh = True
                continue

            if parts[0]=="waitonline":
                wait_online(state=state, duration=read_time(parts[1]))
                refresh = True
                continue

            if parts[0]=="waitoffline" or parts[0]=="wait":
                wait_offline(state=state, duration=read_time(parts[1]))
                refresh = True
                continue

            if parts[0]=="waitcash":
                wait_time = (eggRead(parts[1])-state.farm.cash)/state.farm.bocks_per_second_away
                wait_offline(state=state, duration= wait_time)
                refresh = True
                continue

            if parts[0]=="waitactive":
                wait_active(state=state, duration=read_time(parts[1]))
                refresh = True
                continue

            if parts[0] == "shift":
                shift(state=state, new_egg=parts[1])
                refresh = True
                continue

            if parts[0] == "time":
                print(format(time_active(state=state, cash=eggRead(parts[1]))))
                refresh = True
                continue

            if parts[0] == "buy":
                if parts[1]=="silo":
                    buy_silo(state=state)
                    refresh = True
                    continue

                


            if parts[0] == "resilience":
                resilience(state=state, time=read_time(parts[1]))
                refresh = True
                continue                   

            if len(parts)<3:
                print(f"Invalid command")
                continue

            if parts[0]== "buy":
                if parts[1]=="hab":
                    if parts[2]=="all":
                        buy_hab_all(state=state)
                        refresh = True
                        continue
                    buy_hab(state=state, hab=int(parts[2]))
                    refresh = True
                    continue
                if parts[1]=="vehicle" or parts[1]=="veh":
                    if parts[2]=="all":
                        buy_vehicle_all(state=state)
                        refresh = True
                        continue
                    buy_vehicle(state=state, vehicle=int(parts[2]))
                    refresh = True
                    continue
                if parts[1]=="cr" or parts[1]=="crs" or parts[1]=="research":
                    if parts[2]=="all":
                        buy_cr_all(state=state)
                        refresh = True
                        continue
                    buy_cr(state=state, cr_index=int(parts[2]))
                    refresh = True
                    continue
"""        
        except Exception as e:
            traceback.print_exc()
            print(f"Invalid command: {s} (error: {e})")
            index(state)
            break
"""



