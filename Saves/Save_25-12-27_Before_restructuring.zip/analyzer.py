from farm import Farm
from simulation_commands import *
import re

egg = {
    "c": curiosity,
    "i": integrity,
    "k": kindness,
    "r": resilience,
    "h": humility
    }

def simulate_asc(s, times, eggs_layed=[0,0,0,0,0]):
    assert(bool(re.fullmatch(r"[cikrh]+", s)))
    te_owned = 0
    for i in range(5):
        te_owned += te_numbers(eggs_layed[i])
    f = Farm(egg=egg[s[0]].__name__, 
                te=te_owned, 
                #artifact_set=Artifact_set(),
                video_doubler=True)
    state = State(f, time_elapsed=0, eggs_layed=eggs_layed, shifts=0)

    for k in range(len(s)):
        egg[s[k]](state, times[k])
        virtue(state)