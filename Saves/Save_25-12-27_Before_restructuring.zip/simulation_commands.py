from farm import *
import re
import os, sys
from methods import *
from prices import *
import copy
import random
import shutil



virtue_egg_index = {
    "curiosity": 0,
    "kindness": 1,
    "resilience": 2,
    "humility": 3,
    "integrity": 4
}


class State:
    def __init__(self, farm, time_elapsed, eggs_layed, shifts):
        self.farm = farm
        self.time_elapsed = time_elapsed
        self.eggs_layed = eggs_layed
        self.shifts = shifts

        self.te_claimed = [0,0,0,0,0]
        for i in range(5):
            self.te_claimed[i] = te_numbers(self.eggs_layed[i])

def te_treshholds(n):
    treshholds = [0, 50e6, 1e9, 10e9, 70e9, 500e9, 2e13, 7e12, 20e12, 60e12, 150e12, 500e12, 1.5e15, 4e15, 10e15, 25e15, 50e15, 100e15]
    if n<17:
        return treshholds[n]
    return 1e17 + (n-17)*1e16*(n/2 - 4)

def te_numbers(eggs_layed):
    i=0
    while i<18:
        if te_treshholds(i)>eggs_layed:
            return i - 1
        i += 1
    return math.floor(quad_formula(a=0.5, b=12.5, c=68-(eggs_layed-1e17)/1e16))-1

def te_growth(state):
    sum = 0
    for i in range(5):
        sum += te_numbers(state.eggs_layed[i])-state.te_claimed[i]
    return sum
    
def research_available(state, cr_index):
    if state.farm.crs[cr_index] == max_crs[cr_index]:
        return False
    research_count = 0
    for i in range(len(state.farm.crs)):
        research_count += state.farm.crs[i]
    if cr_bounds[cr_names[cr_index][0]-1] > research_count:
        return False
    return True

def print_event(state, compact=True):
    l = []
    for e in state.farm.event_effects:
        if state.farm.event_effects[e] != 1:
            l.append(e)
    if len(l)==0:
        return ""
    if len(l)>1:
        if compact: return f"multiple events"
        else: 
            s = ""
            for e in l: s += f"{state.farm.event_effects[e]}x{e}, "
            s = s.removesuffix(", ")
            return s
    return f"{state.farm.event_effects[l[0]]}x{l[0]}"

def cr_priority(state, cr_index, time=0):
    f = state.farm
    earnings0 = f.earnings_pop(1)
    shipping0 = f.shipping_rate
    hab0 = f.hab_size
    veh0 = f.max_vehicle_number
    effect = 0

    f.crs[cr_index] += 1
    effect += ((f.earnings_pop(1)/earnings0)-1)*500
    #effect += (f.shipping_rate/shipping0-1)*min(f.laying_per_chick*f.pop/f.shipping_rate,1)*300
    #effect += (f.hab_size/hab0-1)*0
    if time>0.9: effect += (f.max_vehicle_number/veh0-1)*10000
    effect += 7
    f.crs[cr_index] -= 1
    return effect


def set_egg():
    os.system('clear')
    print("-----------------------------------------")
    print("| GnuWithFlu's Path of Virtue simulator |")
    print("-----------------------------------------")
    print()
    print("\033[34mWhich egg do you start on?\033[0m curiosity, kindness, resilience, humility or integrity?")

    while True:
        s = input()
        if (s=="curiosity" or s=="kindness" or s=="resilience" or s=="humility" or s=="integrity"): return s
        sys.stdout.write("\033[1A\r\033[K")

def set_te():
    os.system('clear')
    print("-----------------------------------------")
    print("| GnuWithFlu's Path of Virtue simulator |")
    print("-----------------------------------------")
    print()
    print("\033[34mHow many TE do you have?\033[0m")
    while True:
        s = input()
        sys.stdout.write("\033[1A\r\033[K")
        try:
            if int(s)<0:
                continue
            return int(s)
        except ValueError:
            continue

def set_eggs_layed():
    os.system('clear')
    print("-----------------------------------------")
    print("| GnuWithFlu's Path of Virtue simulator |")
    print("-----------------------------------------")
    print()
    print("\033[34mHow many eggs have you already layed on each farm?\033[0m")
    print("Please enter 5 numbers separated by spaces for CKRHI, e.g. \"14M 27B 13.2T 150M 0\"")
    while True:
        s = input()
        sys.stdout.write("\033[1A\r\033[K")

        try:
            parts = re.split(" ", s)
            if len(parts)!=5: continue
            return [format(parts[0]), format(parts[1]), format(parts[2]), format(parts[3]), format(parts[4])]
        except ValueError:
            continue

def help(state, s=""):
    print(f"\033[34mYou can enter the following commands:\033[0m")
    print(f"\033[32mhelp\033[0m: Show this list of commands")
    print(f"\033[32mstats\033[0m: Show some more stats")
    print(f"\033[32mvirtue\033[0m: Show eggs shipped and TE claimed")
    print(f"\033[32mcr/hab/veh/silo\033[0m: Show respective status")
    print(f"\033[32mrun <number>\033[0m: Increases your population as if you ran chickens")
    print(f"\033[32mwait <duration>\033[0m: Wait with closed the game")
    print(f"\033[32mwaitonline <duration>\033[0m: Wait online, doing nothing")
    print(f"\033[32mwaitactive <duration>\033[0m: Wait online, running chickens, catching drones and gifts")
    print(f"\033[32mtimeaway <cash>\033[0m: How long does it take to obtain that cash when away?")
    print(f"\033[32mtimeactive <cash>\033[0m: How long does it take to obtain that cash when activ?")
    print(f"\033[32mbuy <number>\033[0m: Buy cr, hab, veh or silo")
    print(f"\033[32mbuyall\033[0m: Buy everything you can afford")
    print(f"\033[32m<egg> <duration>\033[0m: Simulates you are on that farm")    
    print(f"\033[32mshift <egg>\033[0m: Shift to another egg")
    print(f"\033[32mprestige\033[0m: Leave the simulation")
    print()

def index(state, s=""):
    egg_name = "\033[34m" + state.farm.egg.capitalize() + " egg farm\033[31m"
    layed = "Layed: \033[32m" + str(format(state.eggs_layed[virtue_egg_index[state.farm.egg]])) + "/" +str(format(te_treshholds(te_numbers(state.eggs_layed[virtue_egg_index[state.farm.egg]])+1)))
    pop = "Pop: \033[32m" + str(format(int(state.farm.pop))) + "/" + str(format(int(state.farm.hab_size)))
    cash = "Cash: \033[32m" + str(format(state.farm.cash))
    laying = "Laying: \033[32m" + str(format(state.farm.laying_per_chick*state.farm.pop*60)) + "/min"
    shipping = "Shipping: \033[32m" + str(format(state.farm.shipping_rate*60)) + "/min"
    active = "Active: \033[32m" + str(format(state.farm.earnings_active)) + "/s"
    os.system('clear')
    print("-----------------------------------------")
    print("| GnuWithFlu's Path of Virtue simulator |")
    print("-----------------------------------------")
    print()
    print(f"{egg_name:<20} {print_event(state, compact=False):>22}\033[0m") 
    print(f"{"Time: \033[32m"}{format_time(state.time_elapsed):<15}\033[0m{layed:<20}\033[0m")
    print(f"Truth Eggs: \033[32m{format(state.farm.te, True)}+{te_growth(state):<5}\033[0m  Shifts: \033[32m{format(state.shifts, True)}\033[0m")
    print(f"{pop:<25}\033[0m {cash:<20}\033[0m")
    print(f"{laying:<26}\033[0m{shipping:<20}\033[0m")
    print(f"{active:<25}\033[0m Offline: \033[32m{format(state.farm.earnings_away)}/s\033[0m")
    print()

def status(state, s=""):
    print(f"\033[34m----- Status -----\033[0m")
    print(f"Farm Value: \033[32m{format(state.farm.farm_value)}\033[0m")
    print(f"Egg Value: \033[32m{format(state.farm.egg_value)}\033[0m")
    print(f"IHR: \033[32m{format(state.farm.ihr*60)}/min\033[0m")
    print(f"Elite Drone (max RCB): \033[32m{format(state.farm.elite_drone_value)}\033[0m")
    print(f"Events active: \033[32m{print_event(state, compact=False)}\033[0m")

    print()

def virtue(state, s=""):
    print(f"\033[34m----- Virtue Stats -----\033[0m")
    print(f"Egg         Layed     Goal      TE")
    print(f"Curiosity:  \033[32m{format(state.eggs_layed[0]):<9} {format(te_treshholds(te_numbers(state.eggs_layed[0])+1)):<9} {state.te_claimed[0]}+{te_numbers(state.eggs_layed[0])-state.te_claimed[0]}\033[0m")
    print(f"Kindness:   \033[32m{format(state.eggs_layed[1]):<9} {format(te_treshholds(te_numbers(state.eggs_layed[1])+1)):<9} {state.te_claimed[1]}+{te_numbers(state.eggs_layed[1])-state.te_claimed[1]}\033[0m")
    print(f"Resilience: \033[32m{format(state.eggs_layed[2]):<9} {format(te_treshholds(te_numbers(state.eggs_layed[2])+1)):<9} {state.te_claimed[2]}+{te_numbers(state.eggs_layed[2])-state.te_claimed[2]}\033[0m")
    print(f"Humility:   \033[32m{format(state.eggs_layed[3]):<9} {format(te_treshholds(te_numbers(state.eggs_layed[3])+1)):<9} {state.te_claimed[3]}+{te_numbers(state.eggs_layed[3])-state.te_claimed[3]}\033[0m")
    print(f"Integrity:  \033[32m{format(state.eggs_layed[4]):<9} {format(te_treshholds(te_numbers(state.eggs_layed[4])+1)):<9} {state.te_claimed[4]}+{te_numbers(state.eggs_layed[4])-state.te_claimed[4]}\033[0m")
    print()


def wait_online(state, t, printout=True):
    if isinstance(t, str): t=read_time(t)

    f = state.farm
    if t <= 0:
        if printout: print(f"Duration must be positive")
        return
    state.time_elapsed += t

    growth = f.ihr
    cash = 0
    layed = 0
    pop = f.pop
    pop0 = f.pop

    if growth == 0 or pop == f.hab_size:
        cash += f.earnings * t
        layed += min(f.pop * f.laying_per_chick, f.shipping_rate) * t
    else:
        t_hab = (f.hab_size - pop)/growth
        t_ship = (f.shipping_rate - f.laying_per_chick*pop)/growth
        if t_ship < 0: t_ship = 0

        # farm grows unrestricted
        if t_hab>=t and t_ship>=t: 
            pop += growth * t
            cash += f.earnings_pop((pop + f.pop)/2) * t
            layed += f.laying_per_chick * (pop + f.pop)/2 * t

        # shipblocked
        elif t_hab>=t_ship and t_ship<t:
            pop += growth * t_ship
            cash += f.earnings_pop((pop + f.pop)/2) * t_ship
            layed += f.laying_per_chick * (pop + f.pop)/2 * t_ship
            
            cash += f.earnings_pop(pop) * (t - t_ship)
            layed += f.shipping_rate * (t - t_ship)
            pop = min(pop+growth*(t-t_ship), f.hab_size)

        # habblocked
        elif t_hab<t and t_ship>=t_hab:
            pop = f.hab_size
            cash += f.earnings_pop((pop + f.pop)/2) * t_hab
            layed += f.laying_per_chick * (pop + f.pop)/2 * t_hab

            cash += f.earnings_pop(pop) * (t - t_hab)
            layed += f.laying_per_chick * pop * (t - t_hab)

    # update farm stats
    state.eggs_layed[virtue_egg_index[f.egg]] += layed
    f.cash += cash
    f.pop = pop

    if printout:
        index(state)
        print(f"Population: {format(pop0)} -> {format(pop)}")
        print(f"Cash: {format(f.cash-cash)} -> {format(f.cash)}")
        print()
    return    
        
def wait_offline(state, t, printout=True):
    if isinstance(t, str): t=read_time(t)

    f = state.farm
    if t < 0:
        if printout: print(f"Duration must be positive")
        return 0
    state.time_elapsed += t

    growth = f.ihr_away
    cash = 0
    layed = 0
    pop = f.pop
    pop0 = f.pop

    if growth == 0 or pop == f.hab_size:
        cash += f.earnings_away * t
        layed += min(f.pop * f.laying_per_chick, f.shipping_rate) * t
    else:
        t_hab = (f.hab_size - pop)/growth
        t_ship = (f.shipping_rate - f.laying_per_chick*pop)/(f.laying_per_chick*growth)
        if t_ship < 0: t_ship = 0
        
        # farm grows unrestricted
        if t_hab>=t and t_ship>=t: 
            pop += growth * t
            cash += f.earnings_pop_away((pop + f.pop)/2) * t
            layed += f.laying_per_chick * (pop + f.pop)/2 * t

        # shipblocked
        elif t_hab>=t_ship and t_ship<t:
            pop += growth * t_ship
            cash += f.earnings_pop_away((pop + f.pop)/2) * t_ship
            layed += f.laying_per_chick * (pop + f.pop)/2 * t_ship
            cash += f.earnings_pop_away(pop) * (t - t_ship)
            layed += f.shipping_rate * (t - t_ship)
            pop = min(pop+growth*(t-t_ship), f.hab_size)

        # habblocked
        elif t_hab<t and t_ship>=t_hab:
            pop = f.hab_size
            cash += f.earnings_pop_away((pop + f.pop)/2) * t_hab
            layed += f.laying_per_chick * (pop + f.pop)/2 * t_hab
            cash += f.earnings_pop_away(pop) * (t - t_hab)
            layed += f.laying_per_chick * pop * (t - t_hab)  
    
    # update farm stats
    state.eggs_layed[virtue_egg_index[f.egg]] += layed
    f.cash += cash
    f.pop = pop

    if printout:
        index(state)
        print(f"Population: {format(pop0)} -> {format(pop)}")
        print(f"Cash: {format(f.cash-cash)} -> {format(f.cash)}")
        print()
    return   

def layed_offline(state, t):
    if isinstance(t, str): t=read_time(t)

    f = state.farm
    if t <= 0:
        return 0

    growth = f.ihr_away
    layed = 0
    pop = f.pop
    pop0 = f.pop

    if growth == 0 or pop == f.hab_size:
        layed += min(f.pop * f.laying_per_chick, f.shipping_rate) * t
    else:
        t_hab = (f.hab_size - pop)/growth
        t_ship = (f.shipping_rate - f.laying_per_chick*pop)/(f.laying_per_chick*growth)
        if t_ship < 0: t_ship = 0
        
        # farm grows unrestricted
        if t_hab>=t and t_ship>=t: 
            pop += growth * t
            layed += f.laying_per_chick * (pop + f.pop)/2 * t

        # shipblocked
        elif t_hab>=t_ship and t_ship<t:
            pop += growth * t_ship
            layed += f.laying_per_chick * (pop + f.pop)/2 * t_ship
            layed += f.shipping_rate * (t - t_ship)

        # habblocked
        elif t_hab<t and t_ship>=t_hab:
            pop = f.hab_size
            layed += f.laying_per_chick * (pop + f.pop)/2 * t_hab
            layed += f.laying_per_chick * pop * (t - t_hab)  
    return layed

def time_cash_away(state, cash, printout=True): # leaves state unchanged!
    if isinstance(cash, str): cash = egg_read(cash)

    f = state.farm
    growth = f.ihr_away
    cash_to_go = cash - f.cash
    pop = f.pop

    if cash <= f.cash or (pop == 0 and growth == 0):
        return 0

    if growth == 0 or pop == f.hab_size:
        return cash_to_go / f.earnings_away
    else:
        
        t_hab = (f.hab_size - pop)/growth
        t_ship = (f.shipping_rate - f.laying_per_chick*pop)/(f.laying_per_chick*growth)
        if t_ship < 0: t_ship = 0
        cash_hab = f.earnings_pop_away(growth*t_hab/2) * t_hab
        cash_ship = f.earnings_pop_away(growth*t_ship/2) * t_ship

        # farm grows unrestricted
        if cash_hab>=cash_to_go and cash_ship>=cash_to_go: 
            return quad_formula(a=0.5*growth*f.earnings_pop_away(1), b=0.5*f.earnings_pop_away(f.pop), c=-cash_to_go)
        
        # shipblocked
        elif cash_hab>=cash_ship and cash_ship<cash_to_go:
            cash_to_go -= cash_ship
            pop += growth * t_ship
            return cash_to_go / f.earnings_pop_away(pop) + t_ship

        # habblocked
        elif cash_hab<cash_to_go and cash_ship>=cash_hab:
            cash_to_go -= cash_hab
            pop = f.hab_size
            return cash_to_go / f.earnings_pop_away(pop) + t_hab
        raise ValueError(f"Nothing works :o")

def time_layed(state, lay): # leaves state unchanged!
    if isinstance(lay, str): lay = egg_read(lay)

    f = state.farm
    growth = f.ihr_away
    lay_to_go = lay
    pop = f.pop

    if lay_to_go <= 0 or (pop == 0 and growth == 0):
        return 0

    if growth == 0 or pop == f.hab_size or f.shipping_rate <= f.laying_per_chick*pop:
        return lay_to_go / min(f.shipping_rate, f.laying_per_chick*pop)
    else:
        t_hab = (f.hab_size - pop)/growth
        t_ship = (f.shipping_rate - f.laying_per_chick*pop)/(f.laying_per_chick*growth)
        if t_ship < 0: t_ship = 0
        lay_hab = f.laying_per_chick *growth/2 * t_hab
        lay_ship = f.laying_per_chick *growth/2 * t_ship

        # farm grows unrestricted
        if lay_hab>=lay_to_go and lay_ship>=lay_to_go: 
            return lay_to_go / (f.laying_per_chick*growth)
        
        # shipblocked
        elif lay_hab>=lay_ship and lay_ship<lay_to_go:
            lay_to_go -= lay_ship
            return lay_to_go / f.shipping_rate + t_ship

        # habblocked
        elif lay_hab<lay_to_go and lay_ship>=lay_hab:
            lay_to_go -= lay_hab
            return lay_to_go / (f.laying_per_chick*f.hab_size) + t_hab
        raise ValueError(f"Nothing works :o")


def wait_active(state, t, printout=True):
    if isinstance(t, str): t=read_time(t)

    f = state.farm
    if t <= 0:
        if printout: print(f"Duration must be positive")
        return
    state.time_elapsed += t

    growth = f.ihr + f.manual_hatchery_rate
    cash = 0
    layed = 0
    pop = f.pop
    pop0 = f.pop

    if  pop == f.hab_size:
        cash += f.earnings_active * t
        layed += min(f.pop * f.laying_per_chick, f.shipping_rate) * t
    else:
        t_hab = (f.hab_size - pop)/growth
        t_ship = (f.shipping_rate - f.laying_per_chick*pop)/(f.laying_per_chick*growth)
        if t_ship < 0: t_ship = 0
        
        # farm grows unrestricted
        if t_hab>=t and t_ship>=t: 
            pop += growth * t
            cash += f.earnings_pop((pop + f.pop)/2) * f.effective_rcb * t
            cash += (f.gifts_and_drones(pop) + f.gifts_and_drones(f.pop))/2 * t
            layed += f.laying_per_chick * (pop + f.pop)/2 * t

        # shipblocked
        elif t_hab>=t and t_ship<t:
            pop += growth * t_ship
            cash += f.earnings_pop((pop + f.pop)/2) * f.effective_rcb * t_ship
            cash += (f.gifts_and_drones(pop) + f.gifts_and_drones(f.pop))/2 * t_ship
            layed += f.laying_per_chick * (pop + f.pop)/2 * t_ship

            cash += f.earnings_pop(pop) * f.effective_rcb* (t - t_ship)
            cash += (f.gifts_and_drones(pop) + f.gifts_and_drones(pop + growth * (t - t_ship)))/2 * (t - t_ship)
            layed += f.shipping_rate * (t - t_ship)
            pop += growth * (t - t_ship)

        # habblocked
        elif t_hab<t and t_ship>=t_hab:
            pop = f.hab_size
            cash += f.earnings_pop(pop + f.pop/2) * f.effective_rcb * t_hab
            cash += (f.gifts_and_drones(pop-1) + f.gifts_and_drones(f.pop))/2 * t_hab
            layed += f.laying_per_chick * (pop + f.pop)/2 * t_hab
            
            cash += f.earnings_pop(pop) * (t - t_hab)
            cash += f.gifts_and_drones(pop) * (t - t_hab)
            layed += f.laying_per_chick * pop * (t - t_hab)

        # shipblocked, then habblocked
        elif t_hab<t and t_ship<t_hab:
            pop += growth * t_ship
            cash += f.earnings_pop((pop + f.pop)/2) * f.effective_rcb * t_ship
            cash += (f.gifts_and_drones(pop) + f.gifts_and_drones(f.pop))/2 * t_ship
            layed += f.laying_per_chick * (pop + f.pop)/2 * t_ship

            cash += f.earnings_pop(pop) * f.effective_rcb * (t_hab - t_ship)
            cash += (f.gifts_and_drones(pop) + f.gifts_and_drones(f.hab_size-1))/2 * (t_hab - t_ship)
            layed += f.shipping_rate * (t_hab - t_ship)

            cash += f.earnings_pop(pop) * (t - t_hab)
            pop = f.hab_size
            cash += f.gifts_and_drones(pop) * (t - t_hab)
            layed += f.shipping_rate * (t - t_hab)   

    # update farm stats
    state.eggs_layed[virtue_egg_index[f.egg]] += layed
    f.cash += cash
    f.pop = pop

    if printout:
        index(state)
        print(f"Population: {format(pop0)} -> {format(pop)}")
        print(f"Cash: {format(f.cash-cash)} -> {format(f.cash)}")
        print()
    return    


def layed_active(state, t, printout=True):
    if isinstance(t, str): t=read_time(t)

    f = state.farm
    if t <= 0:
        if printout: print(f"Duration must be positive")
        return

    growth = f.ihr + f.manual_hatchery_rate
    cash = 0
    layed = 0
    pop = f.pop
    pop0 = f.pop

    if  pop == f.hab_size:
        return min(f.pop * f.laying_per_chick, f.shipping_rate) * t
    else:
        t_hab = (f.hab_size - pop)/growth
        t_ship = (f.shipping_rate - f.laying_per_chick*pop)/(f.laying_per_chick*growth)
        if t_ship < 0: t_ship = 0
        
        # farm grows unrestricted
        if t_hab>=t and t_ship>=t: 
            pop += growth * t
            layed = f.laying_per_chick * (pop + f.pop)/2 * t

        # shipblocked
        elif t_hab>=t_ship and t_ship<t:
            pop += growth * t_ship
            layed = f.laying_per_chick * (pop + f.pop)/2 * t_ship
            layed += f.shipping_rate * (t - t_ship)

        # habblocked
        elif t_hab<t and t_ship>=t_hab:
            pop = f.hab_size
            layed += f.laying_per_chick * (pop + f.pop)/2 * t_hab
            layed += f.laying_per_chick * pop * (t - t_hab)

    return layed

def time_cash_active(state, cash, printout=True): # leaves state unchanged!
    if isinstance(cash, str): cash = egg_read(cash)

    f = state.farm
    growth = f.ihr + f.manual_hatchery_rate
    cash_to_go = cash - f.cash
    pop = f.pop

    if cash <= f.cash or (pop == 0 and growth == 0):
        return 0

    if pop == f.hab_size: # That works
        if printout: print(f"Takes {format_time(cash_to_go / f.earnings_active)}")
        return cash_to_go / f.earnings_active
    else:
        t_hab = (f.hab_size - pop)/growth
        t_ship = (f.shipping_rate - f.laying_per_chick*pop)/(f.laying_per_chick*growth)
        if t_ship < 0: t_ship = 0
        if t_hab>=t_ship:
            cash_ship = (f.earnings_pop(pop + growth*t_ship/2) * f.effective_rcb + (f.gifts_and_drones(pop) + f.gifts_and_drones(min(pop+growth*t_ship,f.hab_size-1)))/2) * t_ship
            cash_hab = cash_ship + (f.earnings_pop(growth*t_ship) + f.gifts_and_drones(0.5*(pop+f.hab_size)))*(t_hab-t_ship)
        else: 
            cash_hab = (f.earnings_pop(pop + growth*t_hab/2) * f.effective_rcb + (f.gifts_and_drones(pop) + f.gifts_and_drones(f.hab_size-1))/2)  * t_hab
            cash_ship = cash_hab + 1


        # farm grows unrestricted (this works)
        if cash_hab>=cash_to_go and cash_ship>=cash_to_go:
            t = quad_formula(
                a=f.earnings_pop(1)*f.effective_rcb*growth + (f.gifts_and_drones(f.hab_size-1) - f.gifts_and_drones(0))/f.hab_size*growth,
                b=f.earnings_pop(f.pop)*f.effective_rcb + f.gifts_and_drones(f.pop) + f.gifts_and_drones(0) + (f.gifts_and_drones(f.hab_size-1) - f.gifts_and_drones(0))/f.hab_size*f.pop,
                c=-2*cash_to_go)

            if printout:
                print(f"Takes {format_time(t)}")  
            return t
        
        # shipblocked (a litle small sometimes dues to 0.6 part)
        elif cash_hab>=cash_to_go and cash_ship<cash_to_go:
            cash_to_go -= cash_ship
            pop += growth * t_ship
            t = quad_formula(
                a=(f.gifts_and_drones(f.hab_size-1) - f.gifts_and_drones(pop))/(f.hab_size-pop)*growth,
                b=2*f.earnings_pop(pop)*f.effective_rcb + f.gifts_and_drones(pop) + f.gifts_and_drones(pop) + (f.gifts_and_drones(f.hab_size-1) - f.gifts_and_drones(pop))/(f.hab_size-pop)*pop,
                c=-2*cash_to_go)
            if printout: print(f"Takes {format_time(t*1.2+t_ship)}")
            return t*1.2 + t_ship #factor to compensate

        # habblocked (yes, works)
        elif cash_hab<cash_to_go and cash_ship>=cash_hab:
            cash_to_go -= cash_hab
            pop = f.hab_size
            if printout: print(f"Takes {format_time(cash_to_go / (f.earnings_pop(pop)+f.gifts_and_drones(pop)) + t_hab)}")
            
            return cash_to_go / (f.earnings_pop(pop)+f.gifts_and_drones(pop)) + t_hab

        # shipblocked, then habblocked (a litle small sometimes dues to 0.6 part)
        elif cash_hab>=t_ship and cash_ship<cash_to_go:
            cash_to_go -= cash_ship
            pop += growth * t_ship
            cash_to_go -= (f.earnings_pop(pop) * f.effective_rcb + (f.gifts_and_drones((pop+f.hab_size)/2))) * (t_hab - t_ship)
            pop = f.hab_size
            if printout: print(f"Takes {format_time(cash_to_go / (f.earnings_pop(pop)+f.gifts_and_drones(pop))*1.2 + t_hab)}")

            return cash_to_go / (f.earnings_pop(pop)+f.gifts_and_drones(pop))*1.2 + t_hab
        raise ValueError(f"Nothing works :o")

def time_layed_active(state, lay): # leaves state unchanged!
    if isinstance(lay, str): lay = egg_read(lay)

    f = state.farm
    growth = f.ihr + f.manual_hatchery_rate
    lay_to_go = lay
    pop = f.pop

    if lay_to_go <= 0 or (pop == 0 and growth == 0):
        return 0

    if growth == 0 or pop == f.hab_size or f.shipping_rate <= f.laying_per_chick*pop:
        return lay_to_go / min(f.shipping_rate, f.laying_per_chick*pop)
    else:
        t_hab = (f.hab_size - pop)/growth
        t_ship = (f.shipping_rate - f.laying_per_chick*pop)/(f.laying_per_chick*growth)
        if t_ship < 0: t_ship = 0
        lay_hab = f.laying_per_chick *growth/2 * t_hab
        lay_ship = f.laying_per_chick *growth/2 * t_ship

        # farm grows unrestricted
        if lay_hab>=lay_to_go and lay_ship>=lay_to_go: 
            return lay_to_go / (pop + 0.5*f.laying_per_chick*growth)
        
        # shipblocked
        elif lay_hab>=lay_ship and lay_ship<lay_to_go:
            lay_to_go -= lay_ship
            return lay_to_go / f.shipping_rate + t_ship

        # habblocked
        elif lay_hab<lay_to_go and lay_ship>=lay_hab:
            lay_to_go -= lay_hab
            return lay_to_go / (f.laying_per_chick*f.hab_size) + t_hab
        raise ValueError(f"Nothing works :o")


def run_chickens(state, s, printout=True):
    if isinstance(s, str): number=egg_read(s)
    else: number = s
    population = state.farm.pop
    if number + population <= state.farm.hab_size:
        state.farm.pop += number
    else: state.farm.pop = state.farm.hab_size
    if printout:
        index(state)
        print(f"population increased from \033[32m{format(population)}\033[0m to \033[32m{format(state.farm.pop)}\033[0m")
        print()

def shift(state, new_egg, printout=True):
    if new_egg not in virtue_egg_index or new_egg==state.farm.egg:
        print("Invalid egg")
        return
    state.farm.egg = new_egg
    state.farm.cash = 0
    state.farm.pop = 0
    state.shifts += 1
    if printout:
        index(state)
        print(f"Shifted to {new_egg} egg farm")
        print()
    
def prestige(state, s):
    virtue(state)
    return

def silo_status(state, s=""):
    print(f"\033[34m----- Silos -----\033[0m")
    print(f"You own \033[32m{state.farm.silos}\033[0m silos")
    print(f"Max away time: \033[32m{state.farm.max_away_time/60}h\033[0m")

    if state.farm.silos == 10:
        print(f"Silos are maxed")
        print()

        return
    print(f"Upgrade cost: \033[32m{format(silo_price[state.farm.silos])}\033[0m")
    print()

def hab_status(state, s=""):
    print(f"\033[34m----- Habitats -----\033[0m")
    print(f"Habs: \033[32m{state.farm.habs[0]} {state.farm.habs[1]} {state.farm.habs[2]} {state.farm.habs[3]}\033[0m")
    print(f"Hab size: \033[32m{format(state.farm.hab_size)}\033[0m")

    for i in range (4):
        if state.farm.habs[i] == 19:
            print(f"Hab \033[32m{i}\033[0m is maxed")
        else: 
            same_habs = 0
            for j in range(4):
                if state.farm.habs[j] == state.farm.habs[i]+1: same_habs+=1
            print(f"Upgrade cost {i}: \033[32m{format(hab_prices[state.farm.habs[i]][same_habs] * (1-0.05*state.farm.ers[5]) * state.farm.coll_effect("flame") * state.farm.event("hab"))}\033[0m")
    print()

def vehicle_status(state, s=""):
    print(f"\033[34m----- Vehicles -----\033[0m")
    print(f"Vehicles:", end='')
    for i in range(state.farm.max_vehicle_number):
        print(f" \033[32m{int(state.farm.vehicles[i])}\033[0m", end='')
    print()
    print(f"Shipping capacity: \033[32m{format(state.farm.shipping_rate*60)}/min\033[0m")

    for i in range(state.farm.max_vehicle_number):
        if state.farm.vehicles[i] > 12 and state.farm.vehicles[i] < 18 + state.farm.crs[50] :
            print(f"Upgrade cost {i}: \033[32m{format(vehicle_prices[12][state.farm.vehicles[i]-12] * (1-0.05*state.farm.ers[6]) * state.farm.coll_effect("lithium") * state.farm.event("veh"))}\033[0m")
        else: 
            same_vehicles = 0
            for j in range(state.farm.max_vehicle_number):
                if state.farm.vehicles[j] == state.farm.vehicles[i]+1: same_vehicles+=1
            print(f"Upgrade cost {i}: \033[32m{format(vehicle_prices[int(state.farm.vehicles[i])][same_vehicles] * (1-0.05*state.farm.ers[6]) * state.farm.coll_effect("lithium") * state.farm.event("veh"))}\033[0m")
    print()

def cr_status(state, s=""):
    print(f"\033[34m----- Research -----\033[0m")
    for i in range(len(state.farm.crs)):
        if research_available(state=state, cr_index=i):
            print(f"{i} \033[31m{cr_names[i][1]}\033[0m ({cr_names[i][2]}) Level \033[32m{int(state.farm.crs[i])}/{max_crs[i]}\033[0m costs \033[32m{format(cr_prices[i][int(state.farm.crs[i])] * state.farm.artf.cr_cost * (1-0.05*state.farm.ers[7]) * state.farm.coll_effect("waterballoon") * state.farm.event("crs"))}\033[0m" )
    research_count = 0
    for i in range(len(state.farm.crs)):
        research_count += state.farm.crs[i]
    for i in range(len(cr_bounds)-1):
        if cr_bounds[i] > research_count:
            print(f"Next tier unlocked in \033[32m{int(cr_bounds[i] - research_count)}\033[0m researches")
            print()
            return
    print()

def buy(state, s):
    f = state.farm
    if f.egg == "resilience":
        buy_silo(state)
    elif f.egg == "integrity":
        buy_hab(state, int(s))
    elif f.egg == "kindness":
        buy_vehicle(state, int(s))
    elif f.egg == "curiosity":
        buy_cr(state, int(s))
    return

def buy_all(state, s=""):
    f = state.farm
    if f.egg == "resilience":
        buy_silo_all(state)
    elif f.egg == "integrity":
        buy_hab_all(state)
    elif f.egg == "kindness":
        buy_vehicle_all(state)
    elif f.egg == "curiosity":
        buy_cr_all(state)
    return

def buy_silo(state, printout=True):
    f = state.farm
    if f.egg != "resilience":
        print(f"You cant buy silos from {f.egg} egg farm!")
        return False
    if f.cash < silo_price[f.silos]:
        print(f"Not enough cash!")
        return False
    if f.silos == 10:
        print(f"Already maxed silos!")
        return False
    
    f.cash -= silo_price[f.silos]
    f.silos += 1
    if printout:
        index(state)
        print(f"Now you own {f.silos} silos!")
        print()
    return True

def buy_silo_all(state):
    f = state.farm
    counter=0
    while f.cash>silo_price[f.silo]:
        counter+=1
        buy_silo(state)
    index(state)
    print(f"Bought {counter-1} habs!")
    print()
    return

def buy_hab(state, hab, printout=True):
    f = state.farm
    if hab<0 or hab>3:
        print(f"Invalid hab: {hab}")
        return False
    if f.egg != "integrity":
        print(f"You cant buy habs from {f.egg} egg farm!")
        return False
        
    if f.habs[hab] == 19:
        print(f"Hab {hab} is maxed")
        return False

    same_habs = 0
    for j in range(4):
        if f.habs[j] == f.habs[hab]+1: same_habs+=1
    upgrade_cost = hab_prices[f.habs[hab]][same_habs] * (1-0.05*f.ers[5]) * f.coll_effect("flame") * f.event("hab")
 
    if f.cash<upgrade_cost:
        print(f"Not enough cash!")
        return False
    
    f.cash -= upgrade_cost
    f.habs[hab] += 1
    if printout:
        index(state)
        print(f"Upgraded hab {hab} from {f.habs[hab]-1} to {f.habs[hab]}!")
        print()
    return True

def buy_hab_all(state):
    f = state.farm
    counter=0
    while True:
        counter+=1
        min_price = 1e34
        min_index = -1

        for i in range(len(f.habs)):
            if f.habs[i]==19:
                continue
            same_habs = 0
            for j in range(4):
                if f.habs[j] == f.habs[i]+1: same_habs+=1
            upgrade_cost = hab_prices[f.habs[i]][same_habs] * (1-0.05*f.ers[5]) * f.coll_effect("flame") * f.event("hab")
            if upgrade_cost < min_price:
                min_price = upgrade_cost
                min_index = i

        if min_index==-1 or f.cash<min_price: 
            if(counter==1):
                print("No hab bought :(")
            else:
                index(state)
                print(f"Bought {counter-1} habs!")
            print()
            break
        if not buy_hab(state, min_index, printout=False): break

def buy_vehicle(state, vehicle, printout=True):
    f = state.farm
    if vehicle<0 or vehicle>f.max_vehicle_number:
        print(f"Invalid vehicle: {vehicle}")
        return False
    if f.egg != "kindness":
        print(f"You cant buy vehicles from {f.egg} egg farm!")
        return False

    if f.vehicles[vehicle]>12:
        upgrade_cost = vehicle_prices[12][f.vehicles[vehicle]] * (1-0.05*f.ers[6]) * f.coll_effect("lithium") * f.event("veh")
    else:
        same_vehicles = 0
        for j in range(f.max_vehicle_number):
            if f.vehicles[j] == f.vehicles[vehicle]+1: same_vehicles+=1
        upgrade_cost = vehicle_prices[int(f.vehicles[vehicle])][same_vehicles] * (1-0.05*f.ers[6]) * f.coll_effect("lithium") * f.event("veh")

    if f.cash<upgrade_cost:
        print(f"Not enough cash!")
        return False
    
    if f.vehicles[vehicle] == 17 + f.crs[50]:
        print(f"Vehicle {vehicle} is maxed")
        return False
    
    f.cash -= upgrade_cost
    f.vehicles[vehicle] += 1
    if printout:
        index(state)
        print(f"Upgraded vehicle {vehicle} from {int(f.vehicles[vehicle]-1)} to {int(f.vehicles[vehicle])}!")
        print()
    return True

def buy_vehicle_all(state):
    f = state.farm
    counter=0
    while True:
        counter+=1
        min_price = 1e28
        min_index = -1

        for i in range(f.max_vehicle_number):
            if f.vehicles[i]<22:
                same_vehicles = 0
                for j in range(f.max_vehicle_number):
                    if f.vehicles[j] == f.vehicles[i]+1:
                        same_vehicles += 1
                upgrade_cost = vehicle_prices[int(f.vehicles[i])][same_vehicles] * (1-0.05*f.ers[6]) * f.coll_effect("lithium") * f.event("veh")
                if upgrade_cost < min_price:
                    min_price = upgrade_cost
                    min_index = i

        if min_index==-1 or f.cash<min_price: 
            if(counter==1):
                print("No vehicle bought :(")
            else:
                index(state)
                print(f"Bought {counter-1} vehicles!")
            print()
            break
        if not buy_vehicle(state, min_index, printout=False):
            break

def buy_cr(state, cr_index, printout=True):
    f = state.farm
    if f.egg != "curiosity":
        print(f"You cant buy research from {f.egg} egg farm!")
        return False
    if not research_available(state=state, cr_index=cr_index):
        print(f"Research not available")
        return False
    upgrade_cost = cr_prices[cr_index][int(f.crs[cr_index])] * f.artf.cr_cost * (1-0.05*f.ers[7]) * f.coll_effect("waterballoon") * f.event("crs")

    if f.cash<upgrade_cost:
        print(f"Not enough cash!")
        return False
    
    f.cash -= upgrade_cost
    f.crs[cr_index] += 1
    if printout:
        index(state)
        print(f"Researched {cr_names[cr_index][1]} to level {int(f.crs[cr_index])}/{max_crs[cr_index]}!")
        print()
    return True

def buy_cr_all(state):
    f = state.farm
    counter=0
    while True:
        counter+=1
        min_price = 1e55
        min_index = -1
        for i in range(len(f.crs)):
            if research_available(state=state, cr_index=i):
                upgrade_cost = cr_prices[i][int(f.crs[i])] * f.artf.cr_cost * (1-0.05*f.ers[7]) * f.coll_effect("waterballoon") * f.event("crs")
                if upgrade_cost < min_price:
                    min_price = upgrade_cost
                    min_index = i

        if min_index==-1 or f.cash<min_price: 
            if(counter==1):
                print("No research bought :(")
            else:
                index(state)
                print(f"Bought {counter-1} researches!")
            print()
            break
        if not buy_cr(state, min_index, printout=False): break

def event(state, s):
    f=state.farm
    pattern = r'([a-z]+)([0-9+].?[0-9]*)'
    match = re.match(pattern, s)
    if not match:
        print("No events active")
        f.reset_events()
        index(state)
        return
    e = match.group(1)
    x = match.group(2)    
    if e in f.event_effects:
        f.set_event(e,x)
        index(state)
        print(f"Activated {e} x {x} event")
    else:
        f.reset_events()
        index(state)
        print("No events active")
    

def resilience(state, s):
    if s.endswith("te"):
        mode_time = False
        s = s.removesuffix("te")
        lay = te_treshholds(int(s))
        if lay < state.eggs_layed[virtue_egg_index["resilience"]]:
            return
    else:
        if isinstance(s, str): time=read_time(s)
        else: time = s
        mode_time = True

    f = state.farm
    if f.egg != "resilinence":
        shift(state, "resilience")
        
    time_zero = state.time_elapsed
    counter = 0
    layed0 = state.eggs_layed[virtue_egg_index["resilience"]]

    
    def cond():
        if mode_time: 
            return state.time_elapsed-time_zero<time
        return state.eggs_layed[virtue_egg_index["resilience"]]<lay
    
    def enough(t):
        if mode_time:
            return state.time_elapsed - time_zero + t < time
        return state.eggs_layed[virtue_egg_index[f.egg]] + layed_offline(state, t) < lay

    def time_max():
        if mode_time:
            return time-state.time_elapsed + time_zero,
        return time_layed_active(state, lay-state.eggs_layed[virtue_egg_index[f.egg]])
    
    while cond():
        if not mode_time: time = (lay - layed0) / min(f.laying_per_chick*f.hab_size, f.shipping_rate)
        if f.cash > silo_price[f.silos]:
            buy_silo(state, printout=False)
            counter += 1
            continue
        if f.pop < f.hab_size and f.ihr == 0:
            wait_active(state, t=min((f.hab_size-f.pop)/(f.ihr + f.manual_hatchery_rate), time/10, time_max()), printout=False)      
            continue      
        if enough(time_cash_away(state, silo_price[f.silos]-f.cash)):
            if f.earnings_active>f.earnings_away:
                wait_active(state, 1.001*time_cash_active(state, silo_price[f.silos], False), printout=False)
            else:
                wait_offline(state, 1.001*time_cash_away(state, silo_price[f.silos], False), printout=False)

            if not buy_silo(state, printout=False):
                break
            counter += 1
            continue
        break
    if mode_time: wait_offline(state, time - state.time_elapsed + time_zero, printout=False)
    else:
        if f.earnings_active>f.earnings_away:
            wait_active(state, time_layed_active(state, lay-state.eggs_layed[virtue_egg_index["resilience"]]), printout=False)
        else:   
            wait_offline(state, time_layed(state, lay-state.eggs_layed[virtue_egg_index["resilience"]]), printout=False)
  
    index(state)
    print(f"Spent {format_time(state.time_elapsed-time_zero)} on resilience.")
    print(f"Bought {counter} silos")
    print(f"Eggs layed {format(layed0)} -> {format(state.eggs_layed[virtue_egg_index["resilience"]])}")  
    return

def kindness(state, s):
    if s.endswith("te"):
        mode_time = False
        s = s.removesuffix("te")
        lay = te_treshholds(int(s))
        if lay < state.eggs_layed[virtue_egg_index["kindness"]]:
            return
    else:
        if isinstance(s, str): time=read_time(s)
        else: time = s
        mode_time = True

    f = state.farm
    if f.egg != "kindness":
        shift(state, "kindness")
        
    time_zero = state.time_elapsed
    counter = 0
    layed0 = state.eggs_layed[virtue_egg_index["kindness"]]

    def cond():
        if mode_time: 
            return state.time_elapsed-time_zero<time
        return state.eggs_layed[virtue_egg_index["kindness"]]<lay

    def enough(t):
        if mode_time:
            return state.time_elapsed - time_zero + t < time
        return state.eggs_layed[virtue_egg_index[f.egg]] + layed_offline(state, t) < lay

    def time_max():
        if mode_time:
            return time-state.time_elapsed + time_zero,
        return time_layed_active(state, lay-state.eggs_layed[virtue_egg_index[f.egg]])

    while cond():
        if not mode_time: time = (lay - layed0) / min(f.laying_per_chick*f.hab_size, f.shipping_rate)

        min_price = 1e28
        min_index = -1

        for i in range(f.max_vehicle_number):
            if f.vehicles[i]<22:
                same_vehicles = 0
                for j in range(f.max_vehicle_number):
                    if f.vehicles[j] == f.vehicles[i]+1:
                        same_vehicles += 1
                upgrade_cost = vehicle_prices[int(f.vehicles[i])][same_vehicles] * (1-0.05*f.ers[6]) * f.coll_effect("lithium") * f.event("veh")
                if upgrade_cost < min_price:
                    min_price = upgrade_cost
                    min_index = i

        if f.cash >= min_price:
            if not buy_vehicle(state, min_index, printout=False):
                print(f"You should not see this")
                break
            counter += 1
            continue
        
        if f.pop < f.hab_size and f.ihr == 0:
            wait_active(state, t=min((f.hab_size-f.pop)/(f.ihr + f.manual_hatchery_rate), time/10, time_max()), printout=False)      
            continue  
      
        if enough(time_cash_away(state, min_price-f.cash)):
            if f.earnings_active>f.earnings_away:
                wait_active(state, 1.001*time_cash_active(state, min_price, False), printout=False)
            else:
                wait_offline(state, 1.001*time_cash_away(state, min_price, False), printout=False)

            if not buy_vehicle(state, min_index, printout=False):
                print(f"You should not see this at all")
                break            
            counter += 1
            continue
        if mode_time: wait_offline(state, time - state.time_elapsed + time_zero, printout=False)
        else:
            if f.earnings_active>f.earnings_away:
                wait_active(state, time_layed_active(state, lay-state.eggs_layed[virtue_egg_index["kindness"]]), printout=False)
            else:
                wait_offline(state, time_layed(state, lay-state.eggs_layed[virtue_egg_index["kindness"]]), printout=False)
  
    index(state)
    print(f"Spent {format_time(state.time_elapsed-time_zero)} on kindness.")
    print(f"Bought {counter} vehicles")
    print(f"Eggs layed {format(layed0)} -> {format(state.eggs_layed[virtue_egg_index["kindness"]])}")  
    return

def integrity(state, s):
    if s.endswith("te"):
        mode_time = False
        s = s.removesuffix("te")
        lay = te_treshholds(int(s))
        if lay < state.eggs_layed[virtue_egg_index["integrity"]]:
            return
    else:
        if isinstance(s, str): time=read_time(s)
        else: time = s
        mode_time = True
        
    f = state.farm
    if f.egg != "integrity":
        shift(state, "integrity")
        
    time_zero = state.time_elapsed
    counter = 0
    layed0 = state.eggs_layed[virtue_egg_index["integrity"]]
    
    def cond():
        if mode_time: 
            return state.time_elapsed-time_zero<time
        return state.eggs_layed[virtue_egg_index["integrity"]]<lay

    def enough(t):
        if mode_time:
            return state.time_elapsed - time_zero + t < time
        return state.eggs_layed[virtue_egg_index[f.egg]] + layed_offline(state, t) < lay

    def time_max():
        if mode_time:
            return time-state.time_elapsed + time_zero,
        return time_layed_active(state, lay-state.eggs_layed[virtue_egg_index[f.egg]])

    while cond():
        if not mode_time: time = (lay - layed0) / min(f.laying_per_chick*f.hab_size, f.shipping_rate)

        min_price = 1e28
        min_index = -1

        for i in range(len(f.habs)):
            if f.habs[i]==19:
                continue
            same_habs = 0
            for j in range(4):
                if f.habs[j] == f.habs[i]+1: same_habs+=1
            upgrade_cost = hab_prices[f.habs[i]][same_habs] * (1-0.05*f.ers[5]) * f.coll_effect("flame") * f.event("hab")
            if upgrade_cost < min_price:
                min_price = upgrade_cost
                min_index = i

        if f.cash >= min_price:
            if not buy_hab(state, min_index, printout=False):
                print(f"You should not see this")
                break
            counter += 1
            continue
        
        if f.pop < f.hab_size and f.ihr == 0:
            wait_active(state, t=min((f.hab_size-f.pop)/(f.ihr + f.manual_hatchery_rate), time/10, time_max()), printout=False)      
            continue  
      
        if enough(time_cash_away(state, min_price)):
            if f.earnings_active>f.earnings_away:
                wait_active(state, 1.001*time_cash_active(state, min_price, False), printout=False)
            else:
                wait_offline(state, 1.001*time_cash_away(state, min_price, False), printout=False)

            if not buy_hab(state, min_index, printout=False):
                print(f"You should not see this at all")
                break            
            counter += 1
            continue
        if mode_time:
            wait_offline(state, time - state.time_elapsed + time_zero, printout=False)
        else:
            if f.earnings_active>f.earnings_away:
                wait_active(state, time_layed_active(state, lay-state.eggs_layed[virtue_egg_index["integrity"]]), printout=False)
            else:
                wait_offline(state, time_layed(state, lay-state.eggs_layed[virtue_egg_index["integrity"]]), printout=False)
          
    index(state)
    print(f"Spent {format_time(state.time_elapsed-time_zero)} on integrity.")
    print(f"Bought {counter} habs")
    print(f"Eggs layed {format(layed0)} -> {format(state.eggs_layed[virtue_egg_index["integrity"]])}")    
    return



def curiosity(state, s):
    if s.endswith("te"):
        mode_time = False
        s = s.removesuffix("te")
        lay = te_treshholds(int(s))
        if lay < state.eggs_layed[virtue_egg_index["curiosity"]]:
            return        
    else:
        if isinstance(s, str): time=read_time(s)
        else: time = s
        mode_time = True

    f = state.farm
    if f.egg != "curiosity":
        shift(state, "curiosity")
        
    time_zero = state.time_elapsed
    counter = 0
    layed0 = state.eggs_layed[virtue_egg_index["curiosity"]]

    def cond():
        if mode_time: 
            return state.time_elapsed-time_zero<time
        return state.eggs_layed[virtue_egg_index["curiosity"]]<lay

    def enough(t):
        if mode_time:
            return state.time_elapsed - time_zero + t < time
        return state.eggs_layed[virtue_egg_index[f.egg]] + layed_offline(state, t) < lay

    def time_max():
        if mode_time:
            return time-state.time_elapsed + time_zero,
        return time_layed_active(state, lay-state.eggs_layed[virtue_egg_index[f.egg]])

    while cond():
        if not mode_time: time = (lay - layed0) / min(f.laying_per_chick*f.hab_size, f.shipping_rate)
        assert(time>0)
        min_price = 1e28
        min_price_eff = 1e28
        min_index = -1

        for i in range(len(f.crs)):
            if research_available(state=state, cr_index=i):
                upgrade_cost = cr_prices[i][int(f.crs[i])] * f.artf.cr_cost * (1-0.05*f.ers[7]) * f.coll_effect("waterballoon") * f.event("crs")
                if upgrade_cost / cr_priority(state, i, (state.time_elapsed-time_zero)/time)< min_price_eff and enough(time_cash_away(state, upgrade_cost-f.cash)):
                    min_price_eff = upgrade_cost / cr_priority(state, i, (state.time_elapsed-time_zero)/time)
                    min_price = upgrade_cost
                    min_index = i

        if f.cash >= min_price:
            if not buy_cr(state, min_index, printout=False):
                print(f"You should not see this")
                break
            counter += 1
            continue
        
        if f.pop < f.hab_size and f.ihr == 0:
            wait_active(state, t=min((f.hab_size-f.pop)/(f.ihr + f.manual_hatchery_rate), time/10, time_max()), printout=False)      
            continue  

        if enough(time_cash_away(state, min_price-f.cash)):
            if f.earnings_active>f.earnings_away:
                wait_active(state, 1.001*time_cash_active(state, min_price, False), printout=False)
            else:
                wait_offline(state, 1.001*time_cash_away(state, min_price, False), printout=False)

            if not buy_cr(state, min_index, printout=False):
                print(f"You should not see this at all")
                break            
            counter += 1
            continue
        index(state)
        if mode_time: wait_active(state, time - state.time_elapsed + time_zero, printout=False)
        else:
            if f.earnings_active>f.earnings_away:
                wait_active(state, time_layed_active(state, lay-state.eggs_layed[virtue_egg_index["curiosity"]]), printout=False)
            else:
                wait_offline(state, time_layed(state, lay-state.eggs_layed[virtue_egg_index["curiosity"]]), printout=False)
    
    index(state)
    print(f"Spent {format_time(state.time_elapsed-time_zero)} on curiosity.")
    print(f"Bought {counter} researches")
    print(f"Eggs layed {format(layed0)} -> {format(state.eggs_layed[virtue_egg_index["curiosity"]])}")
    return

def humility(state, s):
    if s.endswith("te"):
        mode_time = False
        s = s.removesuffix("te")
        lay = te_treshholds(int(s))
        if lay < state.eggs_layed[virtue_egg_index["humility"]]:
            return
    else:
        if isinstance(s, str): time=read_time(s)
        else: time = s
        mode_time = True

    f = state.farm
    time_zero = state.time_elapsed
    layed0 = state.eggs_layed[virtue_egg_index["humility"]]
    if not mode_time: time = (lay - layed0) / min(f.laying_per_chick*f.hab_size, f.shipping_rate)

    if f.egg != "humility":
        shift(state, "humility")

    def time_max():
        if mode_time:
            return time-state.time_elapsed + time_zero,
        return time_layed_active(state, lay-state.eggs_layed[virtue_egg_index[f.egg]])

    if f.pop < f.hab_size and f.ihr == 0:
        wait_active(state, min((f.hab_size-f.pop)/(f.ihr + f.manual_hatchery_rate),time_max()), printout=False)
    if mode_time: wait_offline(state, time - state.time_elapsed + time_zero, printout=False)
    else:
        if f.earnings_active>f.earnings_away:
            wait_active(state, time_layed_active(state, lay-state.eggs_layed[virtue_egg_index["humility"]]), printout=False)
        else:
            wait_offline(state, time_layed(state, lay-state.eggs_layed[virtue_egg_index["humility"]]), printout=False)
   
    index(state)
    print(f"Spent {format_time(state.time_elapsed-time_zero)} on humility.")
    print(f"Eggs layed {format(layed0)} -> {format(state.eggs_layed[virtue_egg_index["humility"]])}")
    return




def test_rs_order_func(state):
    rs_time=9.29e+31

    try: os.remove("crs_order_tmp.txt") 
    except: pass
    f = state.farm
    while True:
        available_list = []
        run_chickens(state, f.hab_size,printout=False)
        for i in range(len(f.crs)):
            if research_available(state, i):
                available_list.append(i)
        if len(available_list)==0:
            #index(state)

            if state.time_elapsed<3*rs_time:
                rs_time = state.time_elapsed
                print(f"You won the lottery! {(rs_time)}")
                shutil.copy("crs_order_tmp.txt", "crs_order_fin.txt")
            return (state.time_elapsed)

        min_price = 1e100
        min_price_eff = 1e100
        min_index = -1
        for i in range(len(f.crs)):
            if research_available(state=state, cr_index=i):
                upgrade_cost = cr_prices[i][int(f.crs[i])] * f.artf.cr_cost * (1-0.05*f.ers[7]) * f.coll_effect("waterballoon") * f.event("crs")
                if upgrade_cost / cr_priority(state, i) < min_price_eff:
                    min_price_eff = upgrade_cost / cr_priority(state, i)
                    min_price = upgrade_cost
                    min_index = i
        if min_index == -1:
            cr_status(state)
            return
        next = min_index
        with open("crs_order_tmp.txt", "a") as fi:
            fi.write(f"{next}\n")
        upgrade_cost = cr_prices[next][int(f.crs[next])] * f.artf.cr_cost * (1-0.05*f.ers[7]) * f.coll_effect("waterballoon") * f.event("crs")
        wait_offline(state,1.001*time_cash_away(state,upgrade_cost),printout=False)
        buy_cr(state, next, printout=False)
