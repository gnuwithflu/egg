import numpy as np
import math
from artifact import*

class Farm:
    egg_specs = { # coefficient, value
        "": [0,0],
        "edible": [2,0.25],
        "superfood": [3,1.25],
        "medical": [4,6.25],
        "rocket fuel": [5,30],
        "super material": [6,150],
        "fusion": [7,700],
        "quantum": [8,3000],
        "crispr": [9,12_500],
        "tachyon": [10,50_000],
        "graviton": [11,175_000],
        "dilithium": [12,525_000],
        "prodigy": [13,1.5e6],
        "terraform": [14,10e6],
        "antimatter": [15,1e9],
        "dark matter": [16,100e9],
        "ai": [17,1e12],
        "nubula": [18,15e12],
        "universe": [19,100e12],
        "enlightment": [6,1e-7],

        "curiosity": [6,1],
        "kindness": [6,1],
        "resilience": [6,1],
        "humility": [6,1],
        "integrity": [6,1],

        "carbon fibre": [27,500],
        "chocolate": [27,5],
        "easter": [27,0.05],
        "firework": [27,4.99],
        "flane retardant": [27,50],
        "lithium": [27,100],
        "pumpkin": [27,0.99],
        "silicon": [27,50],
        "waterballoon": [27,0.1],
        "wood": [27,2],
        }
    # main eggs, virtue eggs, colleggtibles (carbon fibre, chocolate, easter, firework, flame retardant, lithium, pumpkin, silicon, waterballoon, wood)
    #egg_coeffs = [0,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,6,6,6,6,6,6,27,27,27,27,27,27,27,27,27,27]
    #egg_values = [0,0.25, 1.25, 6.25, 30, 150, 700, 3000, 12_500, 50_000, 175_000, 525_000, 1.5e6, 10e6, 1e9, 1e11, 1e12, 15e12, 100e12, 1e-7, 1, 1, 1, 1, 1, 500, 5, 0.05, 4.99, 50, 100, 0.99, 50, 0.2, 2]
    max_crs = [50,40,15,25,8,10,30,10,1,10,30,2,25,50,1,1,50,35,10,10,40,2,15,30,2,50,30,60,2,50,5,30,20,100,250,20,25,7,25,100,5,30,50,150,25,50,3,50,25,100,5,25,500,1,25,10]
    max_ers = [15,20,20,20,20,10,10,10,20,100,20,12,20,140,20,20,30,10,20,5,60,10]
    # carbon fibre, chocolate, easter, firework, flame retardant, lithium, pumpkin, silicon, waterballoon, wood
    coll_effects = [[1,1.01,1.02,1.03,1.05],[1,1.25,1.5,2,3],[1,1.01,1.02,1.03,1.05],[1,1.01,1.02,1.03,1.05],[1,0.99,0.95,0.88,0.75],[1,0.98,0.96,0.93,0.9],[1,1.01,1.02,1.03,1.05],[1,1.01,1.02,1.03,1.05],[1,0.99,0.98,0.97,0.95],[1,1.1,1.25,1.5,2]]
    vehicle_capacities = [0,5000,15_000,50_000,100_000,250_000,500_000,1e6,5e6,15e6,30e6,50e6,50e6,100e6,150e6,200e6,250e6,300e6,350e6,400e6,450e6,500e6]
    hab_capacities = [0,250,500,1000,2000,5000,10_000,20_000,50_000,100_000,200_000,500_000,1e6,2e6,5e6,10e6,25e6,50e6,100e6,600e6]

    @property
    def max_vehicle_number(self):
        return int(4+self.crs[11]+self.crs[21]+self.crs[24]+self.crs[28]+self.crs[40])


    def __init__(self, egg, crs=np.zeros(56), ers=np.zeros(19), silos=1, habs=[1,0,0,0], vehicles=[1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0], se=0, pe=0, te=0, colleggtibles=np.zeros(10), pop=0, artifact_set=Artifact_set(), video_doubler=False, cash=0):
        self.egg = egg
        self.crs = crs
        self.ers = ers
        self.silos = silos
        self.habs = habs
        self.vehicles = vehicles
        self.se = se
        self.pe = pe
        self.te = te
        self.colleggtibles = colleggtibles
        self.pop = pop
        self.artifact_set = artifact_set
        self.video_doubler = video_doubler
        self.cash = cash
        
        if self.egg not in self.egg_specs:
            raise KeyError(f"Unknown egg key: {self.egg}")
        for i in range(len(self.crs)):
            if self.crs[i] > self.max_crs[i]: raise Exception(f"{self.crs[i]} exceeds maximum CR{i} level")
        for i in range(len(self.ers)):
            if self.ers[i] > self.max_ers[i]: raise Exception(f"{self.ers[i]} exceeds maximum ER{i} level")
        if self.silos > 10: raise Exception("Number of silos exceeds maximum")
        for i in range(len(self.colleggtibles)):
            if self.colleggtibles[i] > 4: raise Exception(f"Colleggtible {i} level exceeds maximum")
        for i in range(len(self.vehicles)):
            if(i>self.max_vehicle_number):
                if self.vehicles[i] != 0: raise Exception(f"Vehicle {i} not unlocked")
            if self.vehicles[i] > 16 + self.crs[50]: raise Exception(f"Vehicle {i} exceeds maximum level")
        for i in range(len(self.habs)):
            if self.habs[i] > 19: raise Exception(f"Hab {i} exceeds maximum level")

        
    def on_enlightment(self):
        if (self.egg=="elightment"): return True
        else: return False

    def on_virtue(self):
        if (self.egg=="curiosity" or self.egg=="kindness" or self.egg=="resillence" or self.egg=="humility" or self.egg=="integrity"): return True
        else: return False




    @property
    def egg_value(self):
        # egg value is just the bare value times a ton of common research
        return self.artifact_set.egg_value * self.egg_specs[self.egg][1] * (1+0.25*self.crs[1]) * (1+0.25*self.crs[6]) * (2**self.crs[8]) * (3**self.crs[15]) * (1+0.25*self.crs[17]) * (1+0.15*self.crs[23]) * (1+0.15*self.crs[27]) * (2**self.crs[30]) * (1+0.1*self.crs[33]) * (2**self.crs[37]) * (1+0.25*self.crs[39]) * (1+0.25*self.crs[42]) * (1+0.1*self.crs[45]) * (10**self.crs[46]) * (1+0.05*self.crs[49]) * (1+0.01*self.crs[52]) * (10**self.crs[53])
    
    @property
    def laying_per_chick(self):
        #laying rate per chicken is 2 times a factor from epic research times
        return 2*self.artifact_set.laying * (1+0.05*self.ers[15]) * self.coll_effects[7][int(self.colleggtibles[7])] * (1+0.1*self.crs[0]) * (1+0.05*self.crs[16]) * (1+0.15*self.crs[23]) * (1+0.10*self.crs[35]) * (1+0.02*self.crs[47]) * (1+0.1*self.crs[55])
    @property
    def laying_per_chick_naked(self):
        #laying rate per chicken is 2 times a factor from epic research times
        return 2*(1+0.05*self.ers[15]) * (1+0.1*self.crs[0]) * (1+0.05*self.crs[16]) * (1+0.15*self.crs[23]) * (1+0.10*self.crs[35]) * (1+0.02*self.crs[47]) * (1+0.1*self.crs[55])
  
    @property
    def shipping_rate(self):
        # shipping rate is vehicle capacity times a factor from epic research, two colleggtibles and some common research
        total_capacity = 0
        for i in range(len(self.vehicles)):
            if(self.vehicles[i]>7):
                if(self.vehicles[i]>11):
                    total_capacity += self.vehicle_capacities[int(self.vehicles[i])]* (1+0.05*self.crs[36]) * (1+0.05*self.crs[54]) 
                else:
                    total_capacity += self.vehicle_capacities[int(self.vehicles[i])]* (1+0.1*self.crs[36])
            else: 
                total_capacity += self.vehicle_capacities[int(self.vehicles[i])]
        return total_capacity * self.artifact_set.shipping * (1+0.05*self.ers[16]) * self.coll_effects[0][int(self.colleggtibles[0])] * self.coll_effects[6][int(self.colleggtibles[6])] * (1+0.05*self.crs[10]) * (1+0.1*self.crs[20]) * (1+0.05*self.crs[26]) * (1+0.05*self.crs[29]) * (1+0.05*self.crs[32]) * (1+0.05*self.crs[44]) * (1+0.05*self.crs[51]) 
    
    @property
    def shipping_rate_naked(self):
        # shipping rate is vehicle capacity times a factor from epic research, two colleggtibles and some common research
        total_capacity = 0
        for i in range(len(self.vehicles)):
            if(self.vehicles[i]>7):
                if(self.vehicles[i]>11):
                    total_capacity += self.vehicle_capacities[int(self.vehicles[i])]* (1+0.05*self.crs[36]) * (1+0.05*self.crs[54]) 
                else:
                    total_capacity += self.vehicle_capacities[int(self.vehicles[i])]* (1+0.1*self.crs[36])
            else: 
                total_capacity += self.vehicle_capacities[int(self.vehicles[i])]
        return total_capacity * (1+0.05*self.ers[16]) * (1+0.05*self.crs[10]) * (1+0.1*self.crs[20]) * (1+0.05*self.crs[26]) * (1+0.05*self.crs[29]) * (1+0.05*self.crs[32]) * (1+0.05*self.crs[44]) * (1+0.05*self.crs[51]) 

    @property
    def ihr(self):
        # ihr is calculated from cr, er and the easter collegtible, as well as TE
        total_ihr = (1+0.05*self.ers[4]) * self.coll_effects[2][int(self.colleggtibles[2])] *(2*self.crs[5] + 5*self.crs[9] + 10*self.crs[22] + 25*self.crs[31] + 5*self.crs[34] + 50*self.crs[41])
        if (self.on_virtue()): total_ihr = total_ihr * (1.1**self.te)
        else: total_ihr = total_ihr * (1.01**self.te)
        return total_ihr * 4 * self.artifact_set.ihr # assuming max internal hatchery sharing or 4 habs!!

    def ihr_naked(self):
        # ihr is calculated from cr, er and the easter collegtible, as well as TE
        total_ihr = (1+0.05*self.ers[4]) *(2*self.crs[5] + 5*self.crs[9] + 10*self.crs[22] + 25*self.crs[31] + 5*self.crs[34] + 50*self.crs[41])
        return total_ihr * 4 # assuming max internal hatchery sharing or 4 habs!!

    @property
    def eb(self): #in percent change!
        if self.on_virtue(): return 100*(1.1**self.te -1)
        else: 
            return ((10+1*self.ers[13]+self.artifact_set.se_bonus) * self.se * (1.05 + 0.01*self.ers[19] + self.artifact_set.pe_effect)**self.pe * 1.01**self.te -1)
    @property
    def eb_naked(self): #in percent change!
        if self.on_virtue(): return 100*(1.1**self.te -1)
        else: 
            return ((10+1*self.ers[13]) * self.se * (1.05 + 0.01*self.ers[19])**self.pe * 1.01**self.te -1)


    @property
    def max_rcb(self):
        # base rcb is 5, increased by cr and er
        return 5 + self.artifact_set.max_rcb + 2*self.ers[9] + 0.2*self.crs[13] + 0.5*self.crs[25] + 2*self.crs[43]
    

    @property
    def max_away_time(self):
        return (60+6*self.ers[2])*self.silos
    
    @property
    def hab_size(self):
        total_capacity = 0
        for i in range(len(self.habs)):
            if (self.habs[i]==19): total_capacity += self.hab_capacities[int(self.habs[i])] * (1+0.02*self.crs[48])
            else: total_capacity += self.hab_capacities[int(self.habs[i])]
        return round(total_capacity * self.artifact_set.hab_capacity * (1+0.05*self.crs[4]) * (1+0.05*self.crs[18]) * (1+0.02*self.crs[38]))
    
    @property
    def farm_value(self): # All without colleggtible effects
        return (500 * self.artifact_set.farm_value # Lens
                * (1+0.05*self.ers[3]) # Accounting Tricks
                * self.egg_specs[self.egg][0] # Egg Coefficient
                * self.laying_per_chick/self.coll_effects[7][int(self.colleggtibles[7])]/self.artifact_set.laying # Laying Rate per chicken
                * (1+self.eb/100) # Earning Bonus
                * self.egg_value/self.artifact_set.egg_value # Egg value
                * (self.max_rcb-self.artifact_set.max_rcb-4)**(0.25) # Max Running Chicken Bonus
                * (0.2*self.pop
                   + 0.8*math.floor(self.pop*min(1, self.shipping_rate_naked/(self.laying_per_chick_naked*(self.pop+1e-18))))
                   + (self.hab_size-self.pop)**(0.6)
                   + ((1+0.05*self.ers[4]) *(2*self.crs[5] + 5*self.crs[9] + 10*self.crs[22] + 25*self.crs[31] + 5*self.crs[34] + 50*self.crs[41]))*self.max_away_time)
        )

    @property
    def ihr_away(self):
        return self.ihr * (1+0.1*self.ers[12])
    
    @property
    def rcb_per_chicken(self):
        return 1 + 0.001*self.crs[3] + 0.001*self.ers[8]

    @property
    def bocks_per_second(self):
        if(self.laying_per_chick*self.pop < self.shipping_rate):
            return ((1+int(self.video_doubler)) * self.laying_per_chick/60*self.pop*self.egg_value*self.coll_effects[3][int(self.colleggtibles[3])]*(1+self.eb/100))
        else:
            return (1+int(self.video_doubler)) * self.shipping_rate*self.egg_value/60*self.coll_effects[3][int(self.colleggtibles[3])]*(1+self.eb/100)

    def bocks_per_second_pop(self, population):
        if(self.laying_per_chick*population < self.shipping_rate):
            return ((1+int(self.video_doubler)) * self.laying_per_chick/60*population*self.egg_value*self.coll_effects[3][int(self.colleggtibles[3])]*(1+self.eb/100))
        else:
            return (1+int(self.video_doubler)) * self.shipping_rate*self.self.egg_value/60*self.coll_effects[3][int(self.colleggtibles[3])]*(1+self.eb/100)

    @property
    def bocks_per_second_away(self):
        return self.bocks_per_second * self.artifact_set.away_earnings * self.coll_effects[1][int(self.colleggtibles[1])] * self.coll_effects[9][int(self.colleggtibles[9])]
    
    def bocks_per_second_pop_away(self,population):
        return self.bocks_per_second_pop(population) * self.artifact_set.away_earnings * self.coll_effects[1][int(self.colleggtibles[1])] * self.coll_effects[9][int(self.colleggtibles[9])]

    @property
    def bocks_per_second_active(self): # RCB, drones, boxes
        # online earnings running chickens
        earnings = self.bocks_per_second
        if self.pop < self.hab_size:
            earnings *= min(self.max_rcb,self.manual_hatchery_rate*self.rcb_per_chicken)

        # gift boxes and video gifts (differ on contract farms)
        if self.pop <= 100 or self.on_virtue:
            gifts = self.farm_value * (0.01 * 0.3578 / 325 + 0.03 * 0.1351 / 325
                + 0.01 * 0.0868 / 285 + 0.03 * 0.4208 / 285)
        else:
            gifts = self.farm_value * (0.025 * 0.3578 / 325 + 0.075 * 0.1351 / 325
                + 0.025 * 0.0868 / 285 + 0.075 * 0.4208 / 285)

        # drones
        m = (1 + 0.1*self.ers[10])/100
        drones = (142/3600 * self.farm_value * (0.0001*(1-10*m) + 0.0005*7*m + 0.0025*3*m) 
                + 12/3600 * self.farm_value * 0.05)

        drones *= (1 - 0.3 * self.artifact_set.drone_gold_chance/self.artifact_set.drone_cash_chance)

        if self.pop <=100 or self.on_virtue:
            drones = drones / 2.5

        if self.pop < self.hab_size:
            drones *= (self.max_rcb)**0.5

        if self.on_virtue:
            drones *= 0.66

        return earnings + gifts + drones

    @property
    def gifts_and_drones_multiplier(self): # factored out fv
        # gift boxes and video gifts (differ on contract farms)
        gifts = (0.025 * 0.3578 / 325 + 0.075 * 0.1351 / 325
                + 0.025 * 0.0868 / 285 + 0.075 * 0.4208 / 285)

        # drones
        m = (1 + 0.1*self.ers[10])/100
        drones = (142/3600 *  (0.0001*(1-10*m) + 0.0005*7*m + 0.0025*3*m) 
                + 12/3600 * 0.05)

        drones *= (1 - 0.3 * self.artifact_set.drone_gold_chance/self.artifact_set.drone_cash_chance)


        if self.pop < self.hab_size:
            drones *= (self.max_rcb)**0.5

        if self.on_virtue:
            drones *= 0.66

        return gifts + drones

    @property
    def elite_drone_value(self):
        value = self.farm_value * 0.05
        
        if self.pop <=100 or self.on_virtue:
            value /= 2.5

        if self.pop < self.hab_size:
            value *= (self.max_rcb)**0.5

        return value

    @property
    def hatchery_capacity(self):
        return 250 + 10 * self.crs[7] + 50 * self.crs[14] + 10 * self.crs[19]

    @property
    def hatchery_refill(self):
        return 3 * (1 + 0.1 * self.crs[2]) * (1 + 0.05 * self.crs[12]) * (1 + 0.1 * self.ers[1])

    @property
    def hatchery_output(self):
        return 3 + 2*self.ers[0] + self.artifact_set.hold_to_hatch

    @property
    def manual_hatchery_rate(self):
        return 1/(1/self.hatchery_output + 1/self.hatchery_refill)

    def no_block_integral(self, p1, p2):
        if p2==p1:return 0
        return (500 * self.artifact_set.farm_value # Lens
                * (1+0.05*self.ers[3]) # Accounting Tricks
                * self.egg_specs[self.egg][0] # Egg Coefficient
                * self.laying_per_chick/self.coll_effects[7][int(self.colleggtibles[7])] # Laying Rate per chicken
                * (1+self.eb/100) # Earning Bonus
                * self.egg_value # Egg value
                * (self.max_rcb-4)**(0.25) # Max Running Chicken Bonus
                * (0.5 * (p2**2 - p1**2)
                - 5/8 * (self.hab_size-p2)**(1.6) + 5/8 * (self.hab_size-p1)**(1.6)
                + (p2-p1) * ((1+0.05*self.ers[4]) *(2*self.crs[5] + 5*self.crs[9] + 10*self.crs[22] + 25*self.crs[31] + 5*self.crs[34] + 50*self.crs[41]))*self.max_away_time)
        )/(p2-p1)

    def shipblocked_integral(state, p1, p2):
        if p2==p1:return 0
        return (500 * self.artifact_set.farm_value # Lens
            * (1+0.05*self.ers[3]) # Accounting Tricks
            * self.egg_specs[self.egg][0] # Egg Coefficient
            * self.laying_per_chick/self.coll_effects[7][int(self.colleggtibles[7])] # Laying Rate per chicken
            * (1+self.eb/100) # Earning Bonus
            * self.egg_value # Egg value
            * (self.max_rcb-4)**(0.25) # Max Running Chicken Bonus
            * (0.2*0.5 * (p2**2 - p1**2)
            + 0.8*(self.shipping_rate/self.laying_per_chick)*(p2-p1)
            - 5/8 * (self.hab_size-p2)**(1.6) + 5/8 * (self.hab_size-p1)**(1.6)
            + (p2-p1) * ((1+0.05*self.ers[4]) *(2*self.crs[5] + 5*self.crs[9] + 10*self.crs[22] + 25*self.crs[31] + 5*self.crs[34] + 50*self.crs[41]))*self.max_away_time)
        )/(p2-p1)


            