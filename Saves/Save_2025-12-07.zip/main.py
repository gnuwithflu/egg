# TODO: how does ihr habs multiplied when internal hatchery sharing is not purchased?
# TODO: find exact laying rate formula. There is probably some rounding going on, but where? Does over 1 per mille FV
# TODO: test earnings when shipping capped
# TODO: enlightment on artifacts

import numpy as np
from farm import Farm
from methods import eggPrint,eggRead
from artifact import *
from simulator import simulation



def main():
    set = Artifact_set(a1=Artifact(type="totem", level=4, rarity=3, stone1=Stone(type="lunar",level=3), stone2=Stone(type="lunar",level=3),stone3=Stone(type="lunar",level=3)),
            a2=Artifact(type="necklace", level=4, rarity=2, stone1=Stone(type="lunar",level=3), stone2=Stone(type="lunar",level=3)),
            a3=Artifact(type="ankh", level=3, rarity=1, stone1=Stone(type="lunar",level=3)),
            a4=Artifact(type="gusset", level=2, rarity=2, stone1=Stone(type="lunar",level=3), stone2=Stone(type="lunar",level=3)),    
    )
    set2 = Artifact_set(a1=Artifact(type="ankh", level=4, rarity=1),
            #a2=Artifact(type="book", level=4, rarity=0),
            a3=Artifact(type="necklace", level=4, rarity=3, stone1=Stone(type="prophecy",level=4), stone2=Stone(type="prophecy",level=4), stone3=Stone(type="prophecy",level=4)),
            a4=Artifact(type="cube", level=4, rarity=3, stone1=Stone(type="prophecy",level=4),stone2=Stone(type="prophecy",level=4),stone3=Stone(type="prophecy",level=4)),    
    )

    #simulation(egg="curiosity", te=49, eggs_layed=[1,0,0,0,0], artifact_set=set)
    simulation(egg="resilience", te=0, eggs_layed=[1,0,0,0,0])
"""
    crs1 =  [50,40,15,25,8,10,30,10,1,10,30,2,25,50,1,1,50,35,10,10,40,2,15,30,2,50,30,60,2,50,5,30,20,100,250,20,25,7,25,100,5,30,50,150,25,50,3,50,25,100,5,25,500,1,25,10]
    ers1 = [15,20,20,20,20,10,10,10,20,100,20,12,20,140,20,20,30,10,20,5,60,10]
    coll1 = np.ones(10)*4
    vehicles1 = np.zeros(17)*21
    vehicles1[0]=1
    habs1 = [1,0,0,0] #[19,19,19,19]

    f = Farm(egg="edible", ers=ers1, colleggtibles=coll1, habs=habs1, vehicles=vehicles1, se=504.136e18, pe=173, te=49, silos=1, pop=100, artifact_set=set2, video_doubler=True)
    eggPrint(f.bocks_per_second)
"""
if __name__ == "__main__":
    main() 